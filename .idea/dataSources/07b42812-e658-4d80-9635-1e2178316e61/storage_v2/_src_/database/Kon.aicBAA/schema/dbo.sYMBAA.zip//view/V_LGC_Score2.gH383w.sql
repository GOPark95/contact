CREATE VIEW V_LGC_Score2 AS 
SELECT D.IDKEY,
			JSON_VALUE(D.DATJSON, '$.Q123.Q119') AS AQ01,
			JSON_VALUE(D.DATJSON, '$.Q123.Q120') AS AQ02,
			JSON_VALUE(D.DATJSON, '$.Q123.Q121') AS AQ03,
			JSON_VALUE(D.DATJSON, '$.Q123.Q122') AS AQ04,
			SL.level_cd, SL.level_nm,
			V.SQ, SUBSTRING(B.[key], 1, CASE WHEN CHARINDEX('_', B.[key]) = 0 THEN 100 ELSE CHARINDEX('_', B.[key]) END -1) AS QMID, 
			case when S.charsu= 2 and B.[key] in ('Q1','Q2','Q3','Q4','Q5','Q7') and JSON_VALUE(D.DATJSON, '$.Q123.Q6') = '6' AND s.score_type =100 then S.score*1.2
			     when S.charsu= 2 and B.[key] in ('Q30','Q31','Q32_1','Q32_2','Q32_3') and JSON_VALUE(D.DATJSON, '$.Q123.Q33') = '3' AND s.score_type =100 then S.score*2
			     when S.charsu= 2 and B.[key] in ('Q78','Q80_1','Q80_2','Q80_3','Q80_4','Q80_5','Q80_6') and JSON_VALUE(D.DATJSON, '$.Q123.Q78') = '3' AND s.score_type =100 then S.score*2.4
			     when S.charsu= 2 and B.[key] in ('Q78','Q79_1','Q79_2','Q79_3','Q79_4','Q79_5','Q79_6') and JSON_VALUE(D.DATJSON, '$.Q123.Q79_6') = '6' AND s.score_type =100 then S.score*1.5
			else S.score end as score,
            case when S.charsu= 2 and B.[key] in ('Q1','Q2','Q3','Q4','Q5','Q7') and JSON_VALUE(D.DATJSON, '$.Q123.Q6') = '6' then 225
            	 when S.charsu= 2 and B.[key] in ('Q30','Q31','Q32_1','Q32_2','Q32_3') and JSON_VALUE(D.DATJSON, '$.Q123.Q33') = '3' then 105
            	 when S.charsu= 2 and B.[key] in ('Q79_1','Q79_2','Q79_3','Q79_4','Q79_5','Q79_6') and JSON_VALUE(D.DATJSON, '$.Q123.Q78') = '3' then 0
            	 when S.charsu= 2 and B.[key] in ('Q78','Q80_1','Q80_2','Q80_3','Q80_4','Q80_5','Q80_6') and JSON_VALUE(D.DATJSON, '$.Q123.Q78') = '3' then 50
            	 when S.charsu= 2 and B.[key] in ('Q78','Q80_1','Q80_2','Q80_3','Q80_4','Q80_5','Q80_6') and JSON_VALUE(D.DATJSON, '$.Q123.Q79_6') = '6' then 80
            else SL.max_score end as max_score,
			B.[key] AS QSID, B.value AS QVAL, SL.weight, S.score_type, S.charsu 
FROM kon.dbo.[DATA] D WITH(NOLOCK)
CROSS APPLY OPENJSON(DATJSON) A
CROSS APPLY OPENJSON(A.value) B
LEFT JOIN (
	SELECT PKEY, QID, JSON_VALUE(QUESTIONJSON, '$.variable') AS SQ
	FROM kon.dbo.QUESTION 
) V ON D.PKEY = V.PKEY AND SUBSTRING(B.[key], 1, CASE WHEN CHARINDEX('_', B.[key]) = 0 THEN 100 ELSE CHARINDEX('_', B.[key]) END -1) = V.QID COLLATE Korean_Wansung_CI_AS
LEFT JOIN (
	SELECT IDKEY, 'Q84_1' AS QID, Q84_1 AS Ans, charsu
	FROM WP_LGC_Score_op
	UNION ALL
	SELECT IDKEY, 'Q91_'+Q91 AS QID, Q91 AS Ans, charsu
	FROM WP_LGC_Score_op 
) SO ON D.IDKEY = SO.IDKEY AND B.[key] = SO.QID COLLATE Korean_Wansung_CI_AS AND SO.charsu = '2'
LEFT JOIN WP_LGC_Score S ON B.[key] = S.QID COLLATE Korean_Wansung_CI_AS AND S.charsu = '2' AND CASE WHEN B.[key] IN ('Q84_1', 'Q91_1', 'Q91_2') THEN SO.Ans ELSE B.value END = S.Ans
LEFT JOIN WP_LGC_Score_lev SL ON B.[key] = SL.QID COLLATE Korean_Wansung_CI_AS AND SL.charsu = '2'
WHERE D.PKEY = '2102027_C'
AND D.SURVEY_TYPE <> 'TEST' AND D.Status = '10' 
AND B.[key] IS NOT NULL
AND LEFT(V.SQ, 2) <> 'AQ' AND SUBSTRING(B.[key], 1, CASE WHEN CHARINDEX('_', B.[key]) = 0 THEN 100 ELSE CHARINDEX('_', B.[key]) END -1) <> 'Q124'
AND S.score IS NOT NULL 
AND (B.[key] != 'Q6' OR (B.[key] = 'Q6' AND B.value != '6')) 
AND (B.[key] != 'Q33' OR (B.[key] = 'Q33' AND B.value != '3')) 
AND (B.[key] != 'Q78' OR (B.[key] = 'Q78' AND B.value != '3')) 
AND (B.[key] != 'Q79_6' OR (B.[key] = 'Q79_6' AND B.value != '6'))
go

