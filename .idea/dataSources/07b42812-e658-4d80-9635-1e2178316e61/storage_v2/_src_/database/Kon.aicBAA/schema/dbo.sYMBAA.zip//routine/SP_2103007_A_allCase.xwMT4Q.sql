CREATE PROCEDURE [dbo].[SP_2103007_A_allCase]
    @IN_PKEY varchar(20)      -- 프로젝트 ID
	, @IN_INDEX varchar(100) -- @index
	, @gender nvarchar(64)  -- @index


AS 
BEGIN

declare 
 @json nvarchar(max) 
 
SET NOCOUNT ON
 
------KON DATA JSON형태로 가져오기-------
 set @json=( select * 
 from ( 
 select IDKEY, Status,DAT , survey_date 
 from ( 
 select IDKEY, DATJSON, Status, survey_date 
 from DATA with (nolock) 
 where PKEY = @IN_PKEY and Status='10' and SURVEY_TYPE != 'TEST'
 ) IA CROSS APPLY( 
 select DISTINCT '{' + STUFF(( 
 SELECT ',' + SUBSTRING(value,2, LEN(value)-2) 
 FROM OPENJSON(IA.DATJSON) where [value] <> '{}' 
 FOR XML PATH('') 
 ),1,1,' ') + '}' AS DAT 
 ) DAT 
 ) a FOR JSON AUTO) 
 
--------테이블 집계(카운트)--------
 select 
 USERNAME
 ,'case' as [index_value] 
 ,count([index]) as [index] -- index base
,count([3_29_male] ) as [3_29_male] 
 ,count([3_29_female]) as [3_29_female]
 ,count([3_30_male] ) as [3_30_male] 
 ,count([3_30_female]) as [3_30_female]
 ,count([3_31_male] ) as [3_31_male] 
 ,count([3_31_female]) as [3_31_female]
 ,count([4_1_male] 	) as [4_1_male] 
 ,count([4_1_female]) as [4_1_female]
 ,count([4_2_male] 	) as [4_2_male] 
 ,count([4_2_female]) as [4_2_female]
 ,count([4_3_male] 	) as [4_3_male] 
 ,count([4_3_female]) as [4_3_female]
 ,count([4_4_male] 	) as [4_4_male] 
 ,count([4_4_female]) as [4_4_female]
 ,count([4_5_male] 	) as [4_5_male] 
 ,count([4_5_female]) as [4_5_female]
 ,count([4_6_male] 	) as [4_6_male] 
 ,count([4_6_female]) as [4_6_female]
 ,count([4_7_male] 	) as [4_7_male] 
 ,count([4_7_female]) as [4_7_female]
 ,count([4_8_male] 	) as [4_8_male] 
 ,count([4_8_female]) as [4_8_female]
 ,count([4_9_male] 	) as [4_9_male] 
 ,count([4_9_female]) as [4_9_female]
 from( 
 select
 idKey
 ,JSON_VALUE(j_value,'$.'+@IN_INDEX) as [index] 
,case when JSON_VALUE(j_value,'$.'+@gender) = 1 and convert(char(10),j_date,23) = '2021-03-29' then JSON_VALUE(j_value,'$.'+@gender) end as [3_29_male] 
 ,case when JSON_VALUE(j_value,'$.'+@gender) = 2 and convert(char(10),j_date,23) = '2021-03-29' then JSON_VALUE(j_value,'$.'+@gender) end as [3_29_female] 
 ,case when JSON_VALUE(j_value,'$.'+@gender) = 1 and convert(char(10),j_date,23) = '2021-03-30' then JSON_VALUE(j_value,'$.'+@gender) end as [3_30_male] 
 ,case when JSON_VALUE(j_value,'$.'+@gender) = 2 and convert(char(10),j_date,23) = '2021-03-30' then JSON_VALUE(j_value,'$.'+@gender) end as [3_30_female] 
 ,case when JSON_VALUE(j_value,'$.'+@gender) = 1 and convert(char(10),j_date,23) = '2021-03-31' then JSON_VALUE(j_value,'$.'+@gender) end as [3_31_male] 
 ,case when JSON_VALUE(j_value,'$.'+@gender) = 2 and convert(char(10),j_date,23) = '2021-03-31' then JSON_VALUE(j_value,'$.'+@gender) end as [3_31_female] 
 ,case when JSON_VALUE(j_value,'$.'+@gender) = 1 and convert(char(10),j_date,23) = '2021-04-01' then JSON_VALUE(j_value,'$.'+@gender) end as [4_1_male] 
 ,case when JSON_VALUE(j_value,'$.'+@gender) = 2 and convert(char(10),j_date,23) = '2021-04-01' then JSON_VALUE(j_value,'$.'+@gender) end as [4_1_female] 
 ,case when JSON_VALUE(j_value,'$.'+@gender) = 1 and convert(char(10),j_date,23) = '2021-04-02' then JSON_VALUE(j_value,'$.'+@gender) end as [4_2_male] 
 ,case when JSON_VALUE(j_value,'$.'+@gender) = 2 and convert(char(10),j_date,23) = '2021-04-02' then JSON_VALUE(j_value,'$.'+@gender) end as [4_2_female] 
 ,case when JSON_VALUE(j_value,'$.'+@gender) = 1 and convert(char(10),j_date,23) = '2021-04-03' then JSON_VALUE(j_value,'$.'+@gender) end as [4_3_male] 
 ,case when JSON_VALUE(j_value,'$.'+@gender) = 2 and convert(char(10),j_date,23) = '2021-04-03' then JSON_VALUE(j_value,'$.'+@gender) end as [4_3_female] 
 ,case when JSON_VALUE(j_value,'$.'+@gender) = 1 and convert(char(10),j_date,23) = '2021-04-04' then JSON_VALUE(j_value,'$.'+@gender) end as [4_4_male] 
 ,case when JSON_VALUE(j_value,'$.'+@gender) = 2 and convert(char(10),j_date,23) = '2021-04-04' then JSON_VALUE(j_value,'$.'+@gender) end as [4_4_female] 
 ,case when JSON_VALUE(j_value,'$.'+@gender) = 1 and convert(char(10),j_date,23) = '2021-04-05' then JSON_VALUE(j_value,'$.'+@gender) end as [4_5_male] 
 ,case when JSON_VALUE(j_value,'$.'+@gender) = 2 and convert(char(10),j_date,23) = '2021-04-05' then JSON_VALUE(j_value,'$.'+@gender) end as [4_5_female] 
 ,case when JSON_VALUE(j_value,'$.'+@gender) = 1 and convert(char(10),j_date,23) = '2021-04-06' then JSON_VALUE(j_value,'$.'+@gender) end as [4_6_male] 
 ,case when JSON_VALUE(j_value,'$.'+@gender) = 2 and convert(char(10),j_date,23) = '2021-04-06' then JSON_VALUE(j_value,'$.'+@gender) end as [4_6_female] 
 ,case when JSON_VALUE(j_value,'$.'+@gender) = 1 and convert(char(10),j_date,23) = '2021-04-07' then JSON_VALUE(j_value,'$.'+@gender) end as [4_7_male] 
 ,case when JSON_VALUE(j_value,'$.'+@gender) = 2 and convert(char(10),j_date,23) = '2021-04-07' then JSON_VALUE(j_value,'$.'+@gender) end as [4_7_female] 
 ,case when JSON_VALUE(j_value,'$.'+@gender) = 1 and convert(char(10),j_date,23) = '2021-04-08' then JSON_VALUE(j_value,'$.'+@gender) end as [4_8_male] 
 ,case when JSON_VALUE(j_value,'$.'+@gender) = 2 and convert(char(10),j_date,23) = '2021-04-08' then JSON_VALUE(j_value,'$.'+@gender) end as [4_8_female] 
 ,case when JSON_VALUE(j_value,'$.'+@gender) = 1 and convert(char(10),j_date,23) = '2021-04-09' then JSON_VALUE(j_value,'$.'+@gender) end as [4_9_male] 
 ,case when JSON_VALUE(j_value,'$.'+@gender) = 2 and convert(char(10),j_date,23) = '2021-04-09' then JSON_VALUE(j_value,'$.'+@gender) end as [4_9_female] 

 from( 
	 select
		dbo.SPLIT(JSON_VALUE([value],'$.IDKEY'),'_',1) as idKey
		 ,JSON_VALUE([value],'$.DAT') as j_value
		 ,JSON_VALUE(JSON_VALUE([value],'$.survey_date'),'$.INDEX') as j_date
	from OPENJSON(@json) 
 ) in_a 
 where JSON_VALUE(j_value,'$.'+@IN_INDEX) is not null and convert(char(10),j_date,23) >= '2021-03-29'
 group by JSON_VALUE(j_value,'$.'+@IN_INDEX),j_value,idKey,j_date
 )out_a 
  right join (
        SELECT c.PKEY,c.USERID,m.USERNAME FROM KON.DBO.KON_CAPI_ASSIGN_TB C inner join
    KON.DBO.KON_CAPI_TB M ON C.USERID = M.USERID WHERE C.PKEY = @IN_PKEY
) out_b on idKey = USERID
 group by USERID,USERNAME 
 --FOR JSON AUTO 
 
 SET NOCOUNT OFF;  

END
go

