CREATE VIEW NCRC_POINT_VIEW
	AS
	SELECT IDKEY,
	CASE CAST(ISNULL(A1,0) AS INT) + CAST(ISNULL(A2,0) AS INT) WHEN 0 THEN 0
																								 WHEN 2 THEN 2
																								 WHEN 3 THEN 3
																								 WHEN 4 THEN 4
																								 WHEN 5 THEN 5 END AS S_A,
	CASE CAST(ISNULL(B1,0) AS INT)  WHEN 0 THEN 0
													 WHEN 3 THEN 3
													 WHEN 4 THEN 4
													 WHEN 5 THEN 5 END AS S_B,
	CASE CAST(ISNULL(C1,0) AS INT) + CAST(ISNULL(C2,0) AS INT) WHEN 0 THEN 0
																								 WHEN 1 THEN 1
																								 WHEN 2 THEN 3
																								 WHEN 3 THEN 5 END AS S_C,
	CASE CAST(ISNULL(D1,0) AS INT) + CAST(ISNULL(D2,0) AS INT) WHEN 1 THEN 1
																								 WHEN 2 THEN 2
																								 WHEN 3 THEN 3
																								 WHEN 4 THEN 4
																								 WHEN 5 THEN 5 END AS S_D,
	CASE CAST(ISNULL(E1,0) AS INT) + CAST(ISNULL(E2,0) AS INT) WHEN 0 THEN 0
																								 WHEN 1 THEN 1
																								 WHEN 2 THEN 2 END AS S_E,
	CASE WHEN CAST(ISNULL(F1,0) AS INT) + CAST(ISNULL(F2,0) AS INT) + CAST(ISNULL(F3,0) AS INT) = 0 THEN 1
			WHEN CAST(ISNULL(F1,0) AS INT) + CAST(ISNULL(F2,0) AS INT) + CAST(ISNULL(F3,0) AS INT) = 1 THEN 2
			WHEN CAST(ISNULL(F1,0) AS INT) + CAST(ISNULL(F2,0) AS INT) + CAST(ISNULL(F3,0) AS INT) BETWEEN 2 AND 3 THEN 3
			WHEN CAST(ISNULL(F1,0) AS INT) + CAST(ISNULL(F2,0) AS INT) + CAST(ISNULL(F3,0) AS INT) BETWEEN 4 AND 5 THEN 4
			WHEN CAST(ISNULL(F1,0) AS INT) + CAST(ISNULL(F2,0) AS INT) + CAST(ISNULL(F3,0) AS INT) BETWEEN 6 AND 7 THEN 5
			WHEN CAST(ISNULL(F1,0) AS INT) + CAST(ISNULL(F2,0) AS INT) + CAST(ISNULL(F3,0) AS INT) >= 8 THEN 6 END S_F,
	CASE CAST(ISNULL(G1,0) AS INT) + CAST(ISNULL(G2,0) AS INT) WHEN 2 THEN 1
																								 WHEN 3 THEN 3
																								 WHEN 4 THEN 5 END AS S_G,
	CASE CAST(ISNULL(H1,0) AS INT) + CAST(ISNULL(H2,0) AS INT) WHEN 0 THEN 0
																								 WHEN 1 THEN 1
																								 WHEN 2 THEN 3
																								 WHEN 3 THEN 5
																								 WHEN 4 THEN 7 END AS S_H,
	CASE CAST(ISNULL(I1,0) AS INT) + CAST(ISNULL(I2,0) AS INT) WHEN 0 THEN 0
																								 WHEN 1 THEN 1
																								 WHEN 2 THEN 2
																								 WHEN 3 THEN 3 END AS S_I,
	CASE WHEN CAST(ISNULL(J1,0) AS INT) + CAST(ISNULL(J2,0) AS INT) = 2 THEN 4
			WHEN CAST(ISNULL(J1,0) AS INT) + CAST(ISNULL(J2,0) AS INT) = 3 THEN 5
			WHEN CAST(ISNULL(J1,0) AS INT) + CAST(ISNULL(J2,0) AS INT) = 4 THEN 6
			WHEN CAST(ISNULL(J1,0) AS INT) + CAST(ISNULL(J2,0) AS INT) >= 5 THEN 7 END S_J,
	CASE CAST(ISNULL(K1,0) AS INT) WHEN 0 THEN 0
													 WHEN 1 THEN 3
													 WHEN 2 THEN 5 END AS S_K,
	CAST(ISNULL(L1,0) AS INT) AS S_L,
	CAST(ISNULL(M1,0) AS INT) AS S_M																			 
	FROM 
	(
		SELECT IDKEY,
		CASE JSON_VALUE(DATJSON, '$.Q40."Q20"') WHEN '1' THEN '0'
																	  WHEN '2' THEN '2'
																	  WHEN '3' THEN '3' END AS A1,
		CASE JSON_VALUE(DATJSON, '$.Q40."Q21"') WHEN '1' THEN '0'
																	  WHEN '2' THEN '2' END AS A2,
		CASE JSON_VALUE(DATJSON, '$.Q41."Q22"') WHEN '1' THEN '0'
																	  WHEN '2' THEN '3'
																	  WHEN '3' THEN '4'															  
																	  WHEN '4' THEN '5' END AS B1,
		CASE JSON_VALUE(DATJSON, '$.Q42."Q23"') WHEN '1' THEN '0'
																	  WHEN '2' THEN '1' END AS C1,
		CASE JSON_VALUE(DATJSON, '$.Q42."Q24"') WHEN '1' THEN '0'
																	  WHEN '2' THEN '1'
																	  WHEN '3' THEN '2' END AS C2,
		CASE JSON_VALUE(DATJSON, '$.Q43."Q25"') WHEN '1' THEN '0'
																	  WHEN '2' THEN '1'
																	  WHEN '3' THEN '2' END AS D1,
		CASE JSON_VALUE(DATJSON, '$.Q43."Q26"') WHEN '1' THEN '0'
																	  WHEN '2' THEN '2' END AS D2,
		CASE JSON_VALUE(DATJSON, '$.Q56."Q55_1"') WHEN '1' THEN '1'
																	     WHEN '2' THEN '0' END AS E1,
		CASE JSON_VALUE(DATJSON, '$.Q56."Q55_2"') WHEN '1' THEN '1'
																	     WHEN '2' THEN '0' END AS E2,
		CASE JSON_VALUE(DATJSON, '$.Q45."Q28_1"') WHEN '1' THEN '0'
																	     WHEN '2' THEN '1'
																	     WHEN '3' THEN '2'															  
																	     WHEN '4' THEN '3' END AS F1,
		CASE JSON_VALUE(DATJSON, '$.Q45."Q28_2"') WHEN '1' THEN '0'
																	     WHEN '2' THEN '1'
																	     WHEN '3' THEN '2'															  
																	     WHEN '4' THEN '3' END AS F2,
		CASE JSON_VALUE(DATJSON, '$.Q45."Q28_3"') WHEN '1' THEN '0'
																	     WHEN '2' THEN '1'
																	     WHEN '3' THEN '2'															  
																	     WHEN '4' THEN '3' END AS F3,
		CASE JSON_VALUE(DATJSON, '$.Q46."Q29"') WHEN '1' THEN '1'
																	  WHEN '2' THEN '2' END AS G1,
		CASE JSON_VALUE(DATJSON, '$.Q46."Q30"') WHEN '1' THEN '1'
																	  WHEN '2' THEN '2' END AS G2,
		CASE JSON_VALUE(DATJSON, '$.Q47."Q31"') WHEN '1' THEN '0'
																	  WHEN '2' THEN '1'
																	  WHEN '3' THEN '2' END AS H1,
		CASE JSON_VALUE(DATJSON, '$.Q47."Q32"') WHEN '1' THEN '0'
																	  WHEN '2' THEN '2' END AS H2,
		CASE JSON_VALUE(DATJSON, '$.Q48."Q33"') WHEN '1' THEN '0'
																	  WHEN '2' THEN '1'
																	  WHEN '3' THEN '2' END AS I1,
		CASE JSON_VALUE(DATJSON, '$.Q48."Q34"') WHEN '1' THEN '0'
																	  WHEN '2' THEN '1' END AS I2,
		CASE JSON_VALUE(DATJSON, '$.Q49."Q35"') WHEN '1' THEN '1'
																	  WHEN '2' THEN '2'
																	  WHEN '3' THEN '3' END AS J1,
		CASE JSON_VALUE(DATJSON, '$.Q49."Q36"') WHEN '1' THEN '1'
																	  WHEN '2' THEN '2'
																	  WHEN '3' THEN '3' END AS J2,
		CASE JSON_VALUE(DATJSON, '$.Q50."Q37"') WHEN '1' THEN '0'
																	  WHEN '2' THEN '1'
																	  WHEN '3' THEN '2' END AS K1,
		CASE JSON_VALUE(DATJSON, '$.Q51."Q38_1"') WHEN '' THEN '0' 
																		  ELSE '10' END AS L1,
		CASE WHEN CAST(JSON_VALUE(DATJSON, '$.Q52."Q39_1"') AS FLOAT) < 3 THEN '1'
		 		WHEN CAST(JSON_VALUE(DATJSON, '$.Q52."Q39_1"') AS FLOAT) BETWEEN 3 AND 3.5 THEN '2'
		 		WHEN CAST(JSON_VALUE(DATJSON, '$.Q52."Q39_1"') AS FLOAT) BETWEEN 3.6 AND 3.9 THEN '3'
		 		WHEN CAST(JSON_VALUE(DATJSON, '$.Q52."Q39_1"') AS FLOAT) BETWEEN 4 AND 4.5 THEN '4'
		 		WHEN CAST(JSON_VALUE(DATJSON, '$.Q52."Q39_1"') AS FLOAT) BETWEEN 4.6 AND 5 THEN '5'  END AS M1
		FROM kon.dbo.data 
		WHERE pkey = '2008045_A' 
		AND SURVEY_TYPE not in ('TEST','')
		AND status = '10'
	) DAT
go

