CREATE PROCEDURE [dbo].[question_label]
	-- 문항 ID의 코드 - 라벨 가져옴
	@PKEY varchar(20), -- 프로젝트 ID
	@QARR varchar(100) -- 문항ID 목록
AS
BEGIN
	DECLARE @json NVARCHAR(MAX) 
	 set @json = (SELECT LINFO from kon.dbo.[STRUCTURE] with(nolock) where PKEY = @PKEY  ) 
	 set @json = ( select DISTINCT '{' + STUFF(( 
	 				            SELECT ',' + SUBSTRING(value,2, LEN(value)-2)  
	                             FROM OPENJSON(@json) where [key] in ( select VAL1 collate Korean_Wansung_CI_AS from [dbo].[FN_SPLIT](@QARR,',') ) 
							    FOR XML PATH('')
					 ),1,1,' ') + '}' ) 
	select [key],[value] from OPENJSON(@json) FOR JSON PATH
END
go

