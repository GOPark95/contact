CREATE VIEW dbo.V_RUS_CPART2
AS
SELECT IDKEY, Status, SURVEY_TYPE, A0, C01, C1, C2, C3, C4, C5, C6, C7, C8, C9, C10, C11, C12, C13, C1_1, C2_1, C3_1, C4_1, C5_1, C7_1, C8_1, C10_1
FROM    (SELECT IDKEY, Status, SURVEY_TYPE, JSON_VALUE(DATJSON, '$.Q1.Q1') AS A0, JSON_VALUE(DATJSON, '$.Q102.Q102') AS C01, JSON_VALUE(DATJSON, '$.Q104.Q104') AS C1, JSON_VALUE(DATJSON, '$.Q106.Q106') AS C2, 
                        JSON_VALUE(DATJSON, '$.Q108.Q108') AS C3, JSON_VALUE(DATJSON, '$.Q110.Q110') AS C4, JSON_VALUE(DATJSON, '$.Q112.Q112') AS C5, JSON_VALUE(DATJSON, '$.Q114.Q114') AS C6, JSON_VALUE(DATJSON, '$.Q116.Q116') 
                        AS C7, JSON_VALUE(DATJSON, '$.Q118.Q118') AS C8, JSON_VALUE(DATJSON, '$.Q120.Q120') AS C9, JSON_VALUE(DATJSON, '$.Q121.Q121') AS C10, JSON_VALUE(DATJSON, '$.Q125.Q125') AS C11, JSON_VALUE(DATJSON, 
                        '$.Q126.Q126') AS C12, JSON_VALUE(DATJSON, '$.Q127.Q127') AS C13, JSON_VALUE(DATJSON, '$.Q105.Q105') AS C1_1, JSON_VALUE(DATJSON, '$.Q107.Q107') AS C2_1, JSON_VALUE(DATJSON, '$.Q109.Q109') AS C3_1, 
                        JSON_VALUE(DATJSON, '$.Q111.Q111') AS C4_1, JSON_VALUE(DATJSON, '$.Q113.Q113') AS C5_1, JSON_VALUE(DATJSON, '$.Q117.Q117') AS C7_1, JSON_VALUE(DATJSON, '$.Q119.Q119') AS C8_1, JSON_VALUE(DATJSON, 
                        '$.Q122.Q122') AS C10_1
            FROM    dbo.DATA
            WHERE  (PKEY = '2107010_A')
            UNION ALL
            SELECT IDKEY, Status, SURVEY_TYPE, JSON_VALUE(DATJSON, '$.Q1.Q1') AS A0, JSON_VALUE(DATJSON, '$.Q129.Q129') AS C01, JSON_VALUE(DATJSON, '$.Q131.Q131') AS C1, JSON_VALUE(DATJSON, '$.Q133.Q133') AS C2, 
                        JSON_VALUE(DATJSON, '$.Q135.Q135') AS C3, JSON_VALUE(DATJSON, '$.Q137.Q137') AS C4, JSON_VALUE(DATJSON, '$.Q139.Q139') AS C5, JSON_VALUE(DATJSON, '$.Q141.Q141') AS C6, JSON_VALUE(DATJSON, '$.Q143.Q143') 
                        AS C7, JSON_VALUE(DATJSON, '$.Q145.Q145') AS C8, JSON_VALUE(DATJSON, '$.Q146.Q146') AS C9, JSON_VALUE(DATJSON, '$.Q148.Q148') AS C10, JSON_VALUE(DATJSON, '$.Q152.Q152') AS C11, JSON_VALUE(DATJSON, 
                        '$.Q153.Q153') AS C12, JSON_VALUE(DATJSON, '$.Q154.Q154') AS C13, JSON_VALUE(DATJSON, '$.Q132.Q132') AS C1_1, JSON_VALUE(DATJSON, '$.Q134.Q134') AS C2_1, JSON_VALUE(DATJSON, '$.Q136.Q136') AS C3_1, 
                        JSON_VALUE(DATJSON, '$.Q138.Q138') AS C4_1, JSON_VALUE(DATJSON, '$.Q140.Q140') AS C5_1, JSON_VALUE(DATJSON, '$.Q144.Q144') AS C7_1, JSON_VALUE(DATJSON, '$.Q147.Q147') AS C8_1, JSON_VALUE(DATJSON, 
                        '$.Q149.Q149') AS C10_1
            FROM    dbo.DATA AS DATA_2
            WHERE (PKEY = '2107010_A')
            UNION ALL
            SELECT IDKEY, Status, SURVEY_TYPE, JSON_VALUE(DATJSON, '$.Q1.Q1') AS A0, JSON_VALUE(DATJSON, '$.Q156.Q156') AS C01, JSON_VALUE(DATJSON, '$.Q158.Q158') AS C1, JSON_VALUE(DATJSON, '$.Q160.Q160') AS C2, 
                        JSON_VALUE(DATJSON, '$.Q162.Q162') AS C3, JSON_VALUE(DATJSON, '$.Q164.Q164') AS C4, JSON_VALUE(DATJSON, '$.Q166.Q166') AS C5, JSON_VALUE(DATJSON, '$.Q168.Q168') AS C6, JSON_VALUE(DATJSON, '$.Q170.Q170') 
                        AS C7, JSON_VALUE(DATJSON, '$.Q172.Q172') AS C8, JSON_VALUE(DATJSON, '$.Q174.Q174') AS C9, JSON_VALUE(DATJSON, '$.Q175.Q175') AS C10, JSON_VALUE(DATJSON, '$.Q179.Q179') AS C11, JSON_VALUE(DATJSON, 
                        '$.Q180.Q180') AS C12, JSON_VALUE(DATJSON, '$.Q181.Q181') AS C13, JSON_VALUE(DATJSON, '$.Q159.Q159') AS C1_1, JSON_VALUE(DATJSON, '$.Q161.Q161') AS C2_1, JSON_VALUE(DATJSON, '$.Q163.Q163') AS C3_1, 
                        JSON_VALUE(DATJSON, '$.Q165.Q165') AS C4_1, JSON_VALUE(DATJSON, '$.Q167.Q167') AS C5_1, JSON_VALUE(DATJSON, '$.Q171.Q171') AS C7_1, JSON_VALUE(DATJSON, '$.Q173.Q173') AS C8_1, JSON_VALUE(DATJSON, 
                        '$.Q176.Q176') AS C10_1
            FROM    dbo.DATA AS DATA_1
            WHERE (PKEY = '2107010_A')) AS DAT
WHERE (Status = '10') AND (SURVEY_TYPE <> 'TEST')
go

exec sp_addextendedproperty 'MS_DiagramPane1', N'[0E232FF0-B466-11cf-A24F-00AA00A3EFFF, 1.00]
Begin DesignProperties = 
   Begin PaneConfigurations = 
      Begin PaneConfiguration = 0
         NumPanes = 4
         Configuration = "(H (1[40] 4[20] 2[20] 3) )"
      End
      Begin PaneConfiguration = 1
         NumPanes = 3
         Configuration = "(H (1 [50] 4 [25] 3))"
      End
      Begin PaneConfiguration = 2
         NumPanes = 3
         Configuration = "(H (1 [50] 2 [25] 3))"
      End
      Begin PaneConfiguration = 3
         NumPanes = 3
         Configuration = "(H (4 [30] 2 [40] 3))"
      End
      Begin PaneConfiguration = 4
         NumPanes = 2
         Configuration = "(H (1 [56] 3))"
      End
      Begin PaneConfiguration = 5
         NumPanes = 2
         Configuration = "(H (2 [66] 3))"
      End
      Begin PaneConfiguration = 6
         NumPanes = 2
         Configuration = "(H (4 [50] 3))"
      End
      Begin PaneConfiguration = 7
         NumPanes = 1
         Configuration = "(V (3))"
      End
      Begin PaneConfiguration = 8
         NumPanes = 3
         Configuration = "(H (1[56] 4[18] 2) )"
      End
      Begin PaneConfiguration = 9
         NumPanes = 2
         Configuration = "(H (1 [75] 4))"
      End
      Begin PaneConfiguration = 10
         NumPanes = 2
         Configuration = "(H (1[66] 2) )"
      End
      Begin PaneConfiguration = 11
         NumPanes = 2
         Configuration = "(H (4 [60] 2))"
      End
      Begin PaneConfiguration = 12
         NumPanes = 1
         Configuration = "(H (1) )"
      End
      Begin PaneConfiguration = 13
         NumPanes = 1
         Configuration = "(V (4))"
      End
      Begin PaneConfiguration = 14
         NumPanes = 1
         Configuration = "(V (2))"
      End
      ActivePaneConfig = 0
   End
   Begin DiagramPane = 
      Begin Origin = 
         Top = -192
         Left = 0
      End
      Begin Tables = 
         Begin Table = "DAT"
            Begin Extent = 
               Top = 199
               Left = 48
               Bottom = 362
               Right = 236
            End
            DisplayFlags = 280
            TopColumn = 0
         End
      End
   End
   Begin SQLPane = 
   End
   Begin DataPane = 
      Begin ParameterDefaults = ""
      End
   End
   Begin CriteriaPane = 
      Begin ColumnWidths = 11
         Column = 1440
         Alias = 900
         Table = 1176
         Output = 720
         Append = 1400
         NewValue = 1170
         SortType = 1356
         SortOrder = 1416
         GroupBy = 1350
         Filter = 1356
         Or = 1350
         Or = 1350
         Or = 1350
      End
   End
End
', 'SCHEMA', 'dbo', 'VIEW', 'V_RUS_CPART2'
go

exec sp_addextendedproperty 'MS_DiagramPaneCount', 1, 'SCHEMA', 'dbo', 'VIEW', 'V_RUS_CPART2'
go

