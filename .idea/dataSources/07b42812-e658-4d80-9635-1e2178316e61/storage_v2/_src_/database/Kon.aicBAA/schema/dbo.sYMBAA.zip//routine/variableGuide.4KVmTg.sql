 CREATE FUNCTION variableGuide(@PKEY varchar(20))
 RETURNS NVARCHAR(MAX)
AS
BEGIN
   RETURN (
	   		select 
			QID, 
			JSON_VALUE(QUESTIONJSON,'$.variable') as variable, 
			JSON_VALUE(QUESTIONJSON,'$.explain') as explain, 
			JSON_VALUE(QUESTIONJSON,'$.qtype') as qtype , 
			JSON_VALUE(QUESTIONJSON,'$.title') as title , 
			JSON_QUERY(QUESTIONJSON,'$.dataset') as dataset 
			from kon.dbo.QUESTION WHERE PKEY = @PKEY order by Qorder
			FOR JSON PATH 
        )
END

 go

