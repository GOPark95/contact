CREATE FUNCTION [dbo].[FN_TO_QTYPE] (
	@QID varchar(20),
	@PKEY varchar(30)
)
RETURNS VARCHAR(30)
AS 
BEGIN DECLARE
	@QTYPE VARCHAR(30)
	IF @QID = '' OR @PKEY = ''
		BEGIN 
			set @QID = ''
		END 
	ELSE 
		BEGIN 
			select @QTYPE = (select JSON_VALUE(QUESTIONJSON, '$.qtype') as qtype  from QUESTION  where PKEY = @PKEY and QID = @QID )	
		END
	RETURN @QTYPE
END;
go

