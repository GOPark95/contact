    CREATE PROCEDURE [dbo].[get_list_with_dat]
    
		-- 리스트 정보 
		@PKEY NVARCHAR(30), -- 프로젝트 ID,
		@DAT_CD NVARCHAR(2), -- '1'-> 데이터 포함,  
		@TIME_CD NVARCHAR(2), -- '1'-> 마지막 시간 포함,  
		@JSON_CD NVARCHAR(2) -- '1' --> JSON 형식으로 출력
	AS
	BEGIN
		-- execute dbo.get_list_with_dat '2011023_B','1','1','' => 데이터, 시간 포함 TABLE 출력
		-- execute dbo.get_list_with_dat '2011023_B','','','1' => 데이터, 시간 미포함 JSON 출력
	   	   DECLARE @SQL_COMMAND NVARCHAR(500)
		   DECLARE @dat_column NVARCHAR(150)
		   DECLARE @time_column NVARCHAR(150)
		   
 		   	IF @DAT_CD = '1'
			   	BEGIN 
				   	set @dat_column = ' CASE WHEN B.DATJSON is not null THEN B.DATJSON ELSE ''-'' END as dat_json, '
			   	END
		    ELSE 
			   	BEGIN 
				   	set @dat_column = ''
			   	END	
		   	
		   IF @TIME_CD = '1'
		   	BEGIN 
			   	set @time_column = ' CASE WHEN B.survey_date is not null THEN dbo.FN_LAST_TIME(B.survey_date) ELSE ''-'' END as survey_date, '
		   	END	
		   ELSE 
		   	BEGIN 
			   	set @time_column = ''
		   	END	
		   	
		   SET @SQL_COMMAND = ' select A.IDKEY, dbo.FN_TO_QLABEL(ISNULL(B.PAGENAME,''''),@PKEY ) as page, ISNULL(B.Status,'''') as Status ,'
		   SET @SQL_COMMAND = @SQL_COMMAND + @dat_column + @time_column
		   SET @SQL_COMMAND = @SQL_COMMAND + ' USER_INFO_JSON '
		   SET @SQL_COMMAND = @SQL_COMMAND + ' from KON_LIST_TB A '
		   SET @SQL_COMMAND = @SQL_COMMAND + ' left join [DATA] B on A.IDKEY = B.IDKEY AND A.PKEY_CD  = B.PKEY '
		   SET @SQL_COMMAND = @SQL_COMMAND + ' where pkey_cd = @PKEY AND B.SURVEY_TYPE != ''TEST'' '
		   
		   IF @JSON_CD = '1'
		    set @SQL_COMMAND = @SQL_COMMAND + ' FOR JSON PATH'
		   
		   EXECUTE sp_executesql @SQL_COMMAND, 
		  			N'@PKEY varchar(20), @DAT_CD nvarchar(2), @TIME_CD nvarchar(2), @JSON_CD nvarchar(2)', 
		  			@PKEY = @PKEY, @DAT_CD = @DAT_CD, @TIME_CD = @TIME_CD, @JSON_CD = @JSON_CD;
	END;
    go

