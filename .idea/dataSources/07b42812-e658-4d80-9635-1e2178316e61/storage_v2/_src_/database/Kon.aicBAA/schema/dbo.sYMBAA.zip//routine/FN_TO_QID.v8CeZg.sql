CREATE FUNCTION [dbo].[FN_TO_QID] (
	@QLABEL varchar(20),
	@PKEY varchar(30)
)
RETURNS VARCHAR(30)
AS 
BEGIN DECLARE
	@QID VARCHAR(30)
	IF @QLABEL = '' OR @PKEY = ''
		BEGIN 
			set @QID = ''
		END 
	ELSE 
		BEGIN 
			select @QID = (select QID  from QUESTION  where PKEY = @PKEY and JSON_VALUE(QUESTIONJSON, '$.variable') = @QLABEL )	
		END
	RETURN @QID
END;
go

