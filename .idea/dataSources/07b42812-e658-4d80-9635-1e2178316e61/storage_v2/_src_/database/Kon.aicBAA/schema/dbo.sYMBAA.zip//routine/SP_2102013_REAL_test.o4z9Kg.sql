CREATE PROCEDURE [dbo].[SP_2102013_REAL_test]
    @IN_PKEY varchar(20)      -- 프로젝트 ID
	, @IN_INDEX varchar(100) -- @index
AS 
BEGIN

declare 
 @json nvarchar(max) 
 ,@gender nvarchar(64) 
 ,@age nvarchar(64) 
 
SET NOCOUNT ON

 
 -------Banner 변수-------
 set @gender = 'Q1' 
 set @age = 'Q2_1' 
 
 ------KON DATA JSON형태로 가져오기-------
 set @json=( select * 
 from ( 
 select IDKEY, Status,DAT 
 from ( 
 select IDKEY, DATJSON, Status, survey_date 
 from DATA with (nolock) 
 where PKEY = @IN_PKEY and Status='10' and SURVEY_TYPE = 'CAPI'
 ) IA CROSS APPLY( 
 select DISTINCT '{' + STUFF(( 
 SELECT ',' + SUBSTRING(value,2, LEN(value)-2) 
 FROM OPENJSON(IA.DATJSON) where [value] <> '{}' 
 FOR XML PATH('') 
 ),1,1,' ') + '}' AS DAT 
 ) DAT 
 ) a FOR JSON AUTO) 
 
 --------KON 변수 Label JSON형태로 가져오기-------
 declare 
 @label_json nvarchar(max) 
 ,@label_out_json nvarchar(max) 
 ,@index_label nvarchar(64) 
 
 set @index_label = (SELECT top(1) VAL1 FROM DBO.FN_SPLIT(@IN_INDEX,'_')) 
 set @label_json=(select [QUESTIONJSON] FROM [Kon].[dbo].[QUESTION] where PKEY=@IN_PKEY and QID = @index_label) 
 set @label_out_json = (select j_value	from(select JSON_QUERY([value],'$.single') as  j_value from OPENJSON(@label_json) where [key] = 'dataset') in_a) 
 
 if @label_out_json is null 
 begin 
 set @label_out_json = (select j_value	from(select JSON_QUERY([value],'$.scale') as  j_value from OPENJSON(@label_json) where [key] = 'dataset') in_a) 
 end 

 --------분모 테이블 집계(카운트)--------
 Declare @total_table Table( 
 [index_value]  nvarchar(8) 
 --,[index] float
 --,[male] float
 --,[female] float
 --,[age_20] float
 --,[age_30] float
 --,[age_40] float
 ,[index] numeric(16,13) 
 ,[index_n] int
 ,[male] numeric(16,13)
 ,[male_n] int
 ,[female] numeric(16,13)
 ,[female_n] int
 ,[age_20] numeric(16,13)
 ,[age_20_n] int
 ,[age_30] numeric(16,13)
 ,[age_30_n] int
 ,[age_40] numeric(16,13)
 ,[age_40_n] int
 ,[age_50] numeric(16,13)
 ,[age_50_n] int
 ) 
 insert into @total_table 
 select 
 'total' as [index_value] 
 ,count([index]) as [index] -- index base 
 ,count([index]) as [index_n] -- index base 
 ,count([male]) as [male] -- banner1_1 base 
 ,count([male]) as [male_n] -- banner1_1 base
 ,count([female]) as [female] -- banner1_2 base 
 ,count([female]) as [female_n] -- banner1_2 base 
 ,count([age_20]) as [age_20] -- banner1_2 base 
 ,count([age_20]) as [age_20_n] -- banner1_2 base 
 ,count([age_30]) as [age_30] -- banner1_2 base 
 ,count([age_30]) as [age_30_n] -- banner1_2 base 
 ,count([age_40]) as [age_40] -- banner1_2 base 
 ,count([age_40]) as [age_40_n] -- banner1_2 base 
 ,count([age_50]) as [age_50] -- banner1_2 base 
 ,count([age_50]) as [age_50_n] -- banner1_2 base 
 from( 
 select 
 JSON_VALUE(j_value,'$.'+@IN_INDEX) as [index] 
 ,case when JSON_VALUE(j_value,'$.'+@gender) = 1 then JSON_VALUE(j_value,'$.'+@gender) end as [male] 
 ,case when JSON_VALUE(j_value,'$.'+@gender) = 2 then JSON_VALUE(j_value,'$.'+@gender) end as [female] 
 ,case when JSON_VALUE(j_value,'$.'+@age) >=19 and JSON_VALUE(j_value,'$.'+@age) <30 then 20 end as [age_20] 
 ,case when JSON_VALUE(j_value,'$.'+@age) >29 and JSON_VALUE(j_value,'$.'+@age) <40 then 30 end as [age_30] 
 ,case when JSON_VALUE(j_value,'$.'+@age) >39 and JSON_VALUE(j_value,'$.'+@age) <50 then 40 end as [age_40] 
 ,case when JSON_VALUE(j_value,'$.'+@age) >49 and JSON_VALUE(j_value,'$.'+@age) <60 then 50 end as [age_50] 
 
 from( 
 select JSON_VALUE([value],'$.IDKEY') as idKey,JSON_VALUE([value],'$.DAT') as j_value from OPENJSON(@json) 
 ) in_a 
 where JSON_VALUE(j_value,'$.'+@IN_INDEX) is not null
 group by JSON_VALUE(j_value,'$.'+@IN_INDEX),j_value,idKey 
 )out_a 
 
 
 
 select * 
 from 
 ( 
 --------결과 테이블에 분모 테이블 얹기--------
 select * from @total_table 
 
 union all 
 
 --------분자/분모--------
 select 
 a_case.[index_value] as [index_value] -- index value 
,CAST(case when a_total.[index]=0 then 0 else cast(a_case.[index] as numeric(16,13) )*100/cast(a_total.[index] as numeric(16,13) ) end AS nvarchar)  as [index]                      
,a_case.[index] as [index_n]
,CAST(case when a_total.[male]=0 then 0 else cast(a_case.[male] as numeric(16,13) )*100/cast(a_total.[male] as numeric(16,13) ) end AS nvarchar) as [male] -- banner1_1 base         
,a_case.[male] as [male_n]
,CAST(case when a_total.[female]=0 then 0 else cast(a_case.[female] as numeric(16,13) )*100/cast(a_total.[female] as numeric(16,13) ) end AS nvarchar) as [female] -- banner1_2 base 
,a_case.[female] as [female_n]
,CAST(case when a_total.[age_20]=0 then 0 else cast(a_case.[age_20] as numeric(16,13) )*100/cast(a_total.[age_20] as numeric(16,13) ) end AS nvarchar) as [age_20] -- banner1_2 base 
,a_case.[age_20] as [age_20_n]
,CAST(case when a_total.[age_30]=0 then 0 else cast(a_case.[age_30] as numeric(16,13) )*100/cast(a_total.[age_30] as numeric(16,13) ) end AS nvarchar) as [age_30] -- banner1_2 base 
,a_case.[age_30] as [age_30_n]
,CAST(case when a_total.[age_40]=0 then 0 else cast(a_case.[age_40] as numeric(16,13) )*100/cast(a_total.[age_40] as numeric(16,13) ) end AS nvarchar) as [age_40] -- banner1_2 base 
,a_case.[age_40] as [age_40_n]
,CAST(case when a_total.[age_50]=0 then 0 else cast(a_case.[age_50] as numeric(16,13) )*100/cast(a_total.[age_50] as numeric(16,13) ) end AS nvarchar) as [age_50] -- banner1_2 base 
,a_case.[age_50] as [age_50_n]
 --------분자 테이블과 분모 테이블 조인--------
 from @total_table a_total right join 
 (
 --------분자 테이블 집계(카운트)--------
	 select 
	 out_b.label_value as [index_value] -- index value 
	 ,count([index]) as [index] -- index base 
	 ,count([male]) as [male] -- banner1_1 base 
	 ,count([female]) as [female] -- banner1_2 base 
	 ,count([age_20]) as [age_20] -- banner1_2 base 
	 ,count([age_30]) as [age_30] -- banner1_2 base 
	 ,count([age_40]) as [age_40] -- banner1_2 base 
	 ,count([age_50]) as [age_50] -- banner1_2 base 
	 from( 
	 select 
	 JSON_VALUE(j_value,'$.'+@IN_INDEX) as [index] 
	 ,case when JSON_VALUE(j_value,'$.'+@gender) = 1 then JSON_VALUE(j_value,'$.'+@gender) end as [male] 
	 ,case when JSON_VALUE(j_value,'$.'+@gender) = 2 then JSON_VALUE(j_value,'$.'+@gender) end as [female] 
	 ,case when JSON_VALUE(j_value,'$.'+@age) >= 19 and JSON_VALUE(j_value,'$.'+@age) <30 then 20 end as [age_20] 
	 ,case when JSON_VALUE(j_value,'$.'+@age) >29 and JSON_VALUE(j_value,'$.'+@age) <40 then 30 end as [age_30] 
	 ,case when JSON_VALUE(j_value,'$.'+@age) >39 and JSON_VALUE(j_value,'$.'+@age) <50 then 40 end as [age_40] 
	,case when JSON_VALUE(j_value,'$.'+@age) >49 and JSON_VALUE(j_value,'$.'+@age) <60 then 50 end as [age_50] 
	 from( 
	 select JSON_VALUE([value],'$.IDKEY') as idKey,JSON_VALUE([value],'$.DAT') as j_value from OPENJSON(@json) 
	 ) in_a 
	 where JSON_VALUE(j_value,'$.'+@IN_INDEX) is not null
	 group by JSON_VALUE(j_value,'$.'+@IN_INDEX),j_value,idKey 
 )out_a 
 --------분자 테이블과 Label조인--------
 right join (select JSON_VALUE([value],'$.value') as label_value from OPENJSON(@label_out_json)) out_b on out_a.[index] = out_b.label_value 
 group by out_b.label_value 
 ) a_case on 1=1 
 ) super_a 
 --FOR JSON AUTO 
 
 SET NOCOUNT OFF;  

END
go

