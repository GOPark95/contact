CREATE VIEW dbo.V_RUS_APART
AS
SELECT  IDKEY, Status, SURVEY_TYPE, A0, A1, A2, A3, A4, A5, A6, A7, A8, A10, A11, A12, A13, A14, A15, A16, A17, A1_1, A5_1, A6_1, A7_1, A10_1, A11_1, A12_1
FROM     (SELECT  IDKEY, Status, SURVEY_TYPE, ISNULL(JSON_VALUE(DATJSON, '$.Q4.Q4'), '') AS A0, ISNULL(JSON_VALUE(DATJSON, '$.Q9.Q8'), '') AS A1, ISNULL(JSON_VALUE(DATJSON, 
                               '$.Q10.Q10'), '') AS A2, ISNULL(JSON_VALUE(DATJSON, '$.Q11.Q11'), '') AS A3, ISNULL(JSON_VALUE(DATJSON, '$.Q12.Q12'), '') AS A4, ISNULL(JSON_VALUE(DATJSON, 
                               '$.Q15.Q14'), '') AS A5, ISNULL(JSON_VALUE(DATJSON, '$.Q17.Q16'), '') AS A6, ISNULL(JSON_VALUE(DATJSON, '$.Q19.Q18'), '') AS A7, ISNULL(JSON_VALUE(DATJSON, 
                               '$.Q20.Q20'), '') AS A8, ISNULL(JSON_VALUE(DATJSON, '$.Q23.Q22'), '') AS A10, ISNULL(JSON_VALUE(DATJSON, '$.Q25.Q24'), '') AS A11, ISNULL(JSON_VALUE(DATJSON, 
                               '$.Q27.Q26'), '') AS A12, ISNULL(JSON_VALUE(DATJSON, '$.Q28.Q28'), '') AS A13, ISNULL(JSON_VALUE(DATJSON, '$.Q30.Q30'), '') AS A14, ISNULL(JSON_VALUE(DATJSON, 
                               '$.Q31.Q31'), '') AS A15, ISNULL(JSON_VALUE(DATJSON, '$.Q32.Q32'), '') AS A16, ISNULL(JSON_VALUE(DATJSON, '$.Q33.Q33'), '') AS A17, ISNULL(JSON_VALUE(DATJSON, 
                               '$.Q9.Q9'), '') AS A1_1, ISNULL(JSON_VALUE(DATJSON, '$.Q15.Q15'), '') AS A5_1, ISNULL(JSON_VALUE(DATJSON, '$.Q17.Q17'), '') AS A6_1, ISNULL(JSON_VALUE(DATJSON, 
                               '$.Q19.Q19'), '') AS A7_1, ISNULL(JSON_VALUE(DATJSON, '$.Q23.Q23'), '') AS A10_1, ISNULL(JSON_VALUE(DATJSON, '$.Q25.Q25'), '') AS A11_1, ISNULL(JSON_VALUE(DATJSON, 
                               '$.Q27.Q27'), '') AS A12_1
                FROM     dbo.DATA AS DA1 WITH (NOLOCK)
                WHERE  (PKEY = '2208024_A')
                UNION ALL
                SELECT  IDKEY, Status, SURVEY_TYPE, ISNULL(JSON_VALUE(DATJSON, '$.Q36.Q36'), '') AS A0, ISNULL(JSON_VALUE(DATJSON, '$.Q41.Q40'), '') AS A1, ISNULL(JSON_VALUE(DATJSON, 
                               '$.Q42.Q42'), '') AS A2, ISNULL(JSON_VALUE(DATJSON, '$.Q43.Q43'), '') AS A3, ISNULL(JSON_VALUE(DATJSON, '$.Q44.Q44'), '') AS A4, ISNULL(JSON_VALUE(DATJSON, 
                               '$.Q47.Q46'), '') AS A5, ISNULL(JSON_VALUE(DATJSON, '$.Q49.Q48'), '') AS A6, ISNULL(JSON_VALUE(DATJSON, '$.Q51.Q50'), '') AS A7, ISNULL(JSON_VALUE(DATJSON, 
                               '$.Q52.Q52'), '') AS A8, ISNULL(JSON_VALUE(DATJSON, '$.Q55.Q54'), '') AS A10, ISNULL(JSON_VALUE(DATJSON, '$.Q57.Q56'), '') AS A11, ISNULL(JSON_VALUE(DATJSON, 
                               '$.Q59.Q58'), '') AS A12, ISNULL(JSON_VALUE(DATJSON, '$.Q60.Q60'), '') AS A13, ISNULL(JSON_VALUE(DATJSON, '$.Q62.Q62'), '') AS A14, ISNULL(JSON_VALUE(DATJSON, 
                               '$.Q63.Q63'), '') AS A15, ISNULL(JSON_VALUE(DATJSON, '$.Q64.Q64'), '') AS A16, ISNULL(JSON_VALUE(DATJSON, '$.Q65.Q65'), '') AS A17, ISNULL(JSON_VALUE(DATJSON, 
                               '$.Q41.Q41'), '') AS A1_1, ISNULL(JSON_VALUE(DATJSON, '$.Q47.Q47'), '') AS A5_1, ISNULL(JSON_VALUE(DATJSON, '$.Q49.Q49'), '') AS A6_1, ISNULL(JSON_VALUE(DATJSON, 
                               '$.Q51.Q51'), '') AS A7_1, ISNULL(JSON_VALUE(DATJSON, '$.Q55.Q55'), '') AS A10_1, ISNULL(JSON_VALUE(DATJSON, '$.Q57.Q57'), '') AS A11_1, ISNULL(JSON_VALUE(DATJSON, 
                               '$.Q59.Q59'), '') AS A12_1
                FROM     dbo.DATA AS DA2 WITH (NOLOCK)
                WHERE  (PKEY = '2208024_A')
                UNION ALL
                SELECT  IDKEY, Status, SURVEY_TYPE, ISNULL(JSON_VALUE(DATJSON, '$.Q68.Q68'), '') AS A0, ISNULL(JSON_VALUE(DATJSON, '$.Q73.Q72'), '') AS A1, ISNULL(JSON_VALUE(DATJSON, 
                               '$.Q74.Q74'), '') AS A2, ISNULL(JSON_VALUE(DATJSON, '$.Q75.Q75'), '') AS A3, ISNULL(JSON_VALUE(DATJSON, '$.Q76.Q76'), '') AS A4, ISNULL(JSON_VALUE(DATJSON, 
                               '$.Q79.Q78'), '') AS A5, ISNULL(JSON_VALUE(DATJSON, '$.Q81.Q80'), '') AS A6, ISNULL(JSON_VALUE(DATJSON, '$.Q83.Q82'), '') AS A7, ISNULL(JSON_VALUE(DATJSON, 
                               '$.Q84.Q84'), '') AS A8, ISNULL(JSON_VALUE(DATJSON, '$.Q87.Q86'), '') AS A10, ISNULL(JSON_VALUE(DATJSON, '$.Q89.Q88'), '') AS A11, ISNULL(JSON_VALUE(DATJSON, 
                               '$.Q91.Q90'), '') AS A12, ISNULL(JSON_VALUE(DATJSON, '$.Q92.Q92'), '') AS A13, ISNULL(JSON_VALUE(DATJSON, '$.Q94.Q94'), '') AS A14, ISNULL(JSON_VALUE(DATJSON, 
                               '$.Q95.Q95'), '') AS A15, ISNULL(JSON_VALUE(DATJSON, '$.Q96.Q96'), '') AS A16, ISNULL(JSON_VALUE(DATJSON, '$.Q97.Q97'), '') AS A17, ISNULL(JSON_VALUE(DATJSON, 
                               '$.Q73.Q73'), '') AS A1_1, ISNULL(JSON_VALUE(DATJSON, '$.Q79.Q79'), '') AS A5_1, ISNULL(JSON_VALUE(DATJSON, '$.Q81.Q81'), '') AS A6_1, ISNULL(JSON_VALUE(DATJSON, 
                               '$.Q83.Q83'), '') AS A7_1, ISNULL(JSON_VALUE(DATJSON, '$.Q87.Q87'), '') AS A10_1, ISNULL(JSON_VALUE(DATJSON, '$.Q89.Q89'), '') AS A11_1, ISNULL(JSON_VALUE(DATJSON, 
                               '$.Q91.Q91'), '') AS A12_1
                FROM     dbo.DATA AS DA3 WITH (NOLOCK)
                WHERE  (PKEY = '2208024_A')) AS OUT_A
WHERE  (Status = '10')
go

exec sp_addextendedproperty 'MS_DiagramPane1', N'[0E232FF0-B466-11cf-A24F-00AA00A3EFFF, 1.00]
Begin DesignProperties = 
   Begin PaneConfigurations = 
      Begin PaneConfiguration = 0
         NumPanes = 4
         Configuration = "(H (1[40] 4[20] 2[20] 3) )"
      End
      Begin PaneConfiguration = 1
         NumPanes = 3
         Configuration = "(H (1 [50] 4 [25] 3))"
      End
      Begin PaneConfiguration = 2
         NumPanes = 3
         Configuration = "(H (1 [50] 2 [25] 3))"
      End
      Begin PaneConfiguration = 3
         NumPanes = 3
         Configuration = "(H (4 [30] 2 [40] 3))"
      End
      Begin PaneConfiguration = 4
         NumPanes = 2
         Configuration = "(H (1 [56] 3))"
      End
      Begin PaneConfiguration = 5
         NumPanes = 2
         Configuration = "(H (2 [66] 3))"
      End
      Begin PaneConfiguration = 6
         NumPanes = 2
         Configuration = "(H (4 [50] 3))"
      End
      Begin PaneConfiguration = 7
         NumPanes = 1
         Configuration = "(V (3))"
      End
      Begin PaneConfiguration = 8
         NumPanes = 3
         Configuration = "(H (1[56] 4[18] 2) )"
      End
      Begin PaneConfiguration = 9
         NumPanes = 2
         Configuration = "(H (1 [75] 4))"
      End
      Begin PaneConfiguration = 10
         NumPanes = 2
         Configuration = "(H (1[66] 2) )"
      End
      Begin PaneConfiguration = 11
         NumPanes = 2
         Configuration = "(H (4 [60] 2))"
      End
      Begin PaneConfiguration = 12
         NumPanes = 1
         Configuration = "(H (1) )"
      End
      Begin PaneConfiguration = 13
         NumPanes = 1
         Configuration = "(V (4))"
      End
      Begin PaneConfiguration = 14
         NumPanes = 1
         Configuration = "(V (2))"
      End
      ActivePaneConfig = 0
   End
   Begin DiagramPane = 
      Begin Origin = 
         Top = 0
         Left = 0
      End
      Begin Tables = 
         Begin Table = "OUT_A"
            Begin Extent = 
               Top = 6
               Left = 38
               Bottom = 136
               Right = 201
            End
            DisplayFlags = 280
            TopColumn = 0
         End
      End
   End
   Begin SQLPane = 
   End
   Begin DataPane = 
      Begin ParameterDefaults = ""
      End
   End
   Begin CriteriaPane = 
      Begin ColumnWidths = 11
         Column = 1440
         Alias = 900
         Table = 1170
         Output = 720
         Append = 1400
         NewValue = 1170
         SortType = 1350
         SortOrder = 1410
         GroupBy = 1350
         Filter = 1350
         Or = 1350
         Or = 1350
         Or = 1350
      End
   End
End
', 'SCHEMA', 'dbo', 'VIEW', 'V_RUS_APART'
go

exec sp_addextendedproperty 'MS_DiagramPaneCount', 1, 'SCHEMA', 'dbo', 'VIEW', 'V_RUS_APART'
go

