CREATE VIEW V_LGC_Score4 AS 
SELECT *
FROM (
	SELECT D.IDKEY,
			JSON_VALUE(D.DATJSON, '$.Q123.Q119') AS AQ01,
			JSON_VALUE(D.DATJSON, '$.Q123.Q120') AS AQ02,
			JSON_VALUE(D.DATJSON, '$.Q123.Q121') AS AQ03,
			JSON_VALUE(D.DATJSON, '$.Q123.Q122') AS AQ04,
			SL.level_cd, SL.level_nm,
			V.SQ, SUBSTRING(B.[key], 1, CASE WHEN CHARINDEX('_', B.[key]) = 0 THEN 100 ELSE CHARINDEX('_', B.[key]) END -1) AS QMID, 
			case when S.charsu= 4 and B.[key] in ('Q1','Q2','Q3','Q4','Q5','Q7') and JSON_VALUE(D.DATJSON, '$.Q123.Q6') = '6' AND s.score_type =100 then S.score*1.2
				 when S.charsu= 4 and B.[key] in ('Q34_1','Q34_2','Q34_3','Q34_4','Q34_5','Q36') and JSON_VALUE(D.DATJSON, '$.Q123.Q33') = '3' then NULL
			     when S.charsu= 4 and B.[key] in ('Q30','Q31','Q32_1','Q32_2','Q32_3','Q33','Q34_1','Q34_2','Q34_3','Q34_4','Q34_5','Q36') and JSON_VALUE(D.DATJSON, '$.Q123.Q33') = '3' AND s.score_type =100 then S.score*2
			     when S.charsu= 4 and B.[key] in ('Q72') and JSON_VALUE(D.DATJSON, '$.Q123.Q71') = '3' then NULL
			     when S.charsu= 4 and B.[key] in ('Q37','Q39_1','Q39_2','Q39_3','Q39_4','Q39_5','Q39_6','Q39_7','Q40','Q38','Q41') and JSON_VALUE(D.DATJSON, '$.Q123.Q40') = '4' AND s.score_type =100 then S.score * (cast(215 as float)/185)
			     when S.charsu= 4 and B.[key] in ('Q42','Q43_1','Q43_2','Q43_3','Q44_1','Q44_2','Q44_3','Q45','Q46','Q47','Q48','Q49_1','Q49_2','Q49_3','Q51','Q127','Q52','Q53_1','Q53_2','Q53_3','Q53_4','Q53_5','Q53_6','Q53_7','Q53_8','Q54','Q115','Q116','Q117','Q118','Q125','Q55','Q56_1','Q56_2','Q56_3','Q57_1','Q57_2','Q57_3','Q57_4','Q57_5','Q58','Q59','Q60','Q61_1','Q61_2','Q61_3','Q62_1','Q62_2','Q62_3','Q63','Q64_1','Q64_2','Q64_3','Q64_4','Q64_5','Q64_6','Q64_7','Q65_1','Q65_2','Q65_3','Q65_4','Q65_5','Q66_1','Q66_2','Q66_3','Q67_1','Q67_2','Q67_3','Q67_4','Q67_5','Q124','Q68','Q69','Q70','Q71','Q72','Q73','Q74','Q75_1','Q75_2','Q75_3','Q75_4','Q75_5','Q76_1','Q76_2','Q76_3','Q76_4','Q76_5','Q76_6','Q76_7','Q76_8','Q77_1','Q77_2','Q77_3','Q77_4','Q77_5','Q77_6','Q77_7','Q77_8') and JSON_VALUE(D.DATJSON, '$.Q123.Q124') = '1' AND s.score_type =100 then S.score * (cast(1100 as float)/960)
			     when S.charsu= 4 and B.[key] in ('Q42','Q43_1','Q43_2','Q43_3','Q44_1','Q44_2','Q44_3','Q45','Q46','Q47','Q48','Q49_1','Q49_2','Q49_3','Q51','Q127','Q52','Q53_1','Q53_2','Q53_3','Q53_4','Q53_5','Q53_6','Q53_7','Q53_8','Q54','Q115','Q116','Q117','Q118','Q125','Q55','Q56_1','Q56_2','Q56_3','Q57_1','Q57_2','Q57_3','Q57_4','Q57_5','Q58','Q59','Q60','Q61_1','Q61_2','Q61_3','Q62_1','Q62_2','Q62_3','Q63','Q64_1','Q64_2','Q64_3','Q64_4','Q64_5','Q64_6','Q64_7','Q65_1','Q65_2','Q65_3','Q65_4','Q65_5','Q66_1','Q66_2','Q66_3','Q67_1','Q67_2','Q67_3','Q67_4','Q67_5','Q124','Q68','Q69','Q70','Q71','Q72','Q73','Q74','Q75_1','Q75_2','Q75_3','Q75_4','Q75_5','Q76_1','Q76_2','Q76_3','Q76_4','Q76_5','Q76_6','Q76_7','Q76_8','Q77_1','Q77_2','Q77_3','Q77_4','Q77_5','Q77_6','Q77_7','Q77_8') and JSON_VALUE(D.DATJSON, '$.Q123.Q71') = '3' AND s.score_type =100 then S.score * (cast(1100 as float)/1080)
			     when S.charsu= 4 and B.[key] in ('Q78','Q79_1','Q79_2','Q79_3','Q79_4','Q80_1','Q80_2','Q80_3','Q80_4','Q80_5','Q80_6') and JSON_VALUE(D.DATJSON, '$.Q123.Q78') = '3' AND s.score_type =100 then S.score*2.4
			else S.score end as score,
            case when S.charsu= 4 and B.[key] in ('Q1','Q2','Q3','Q4','Q5','Q7') and JSON_VALUE(D.DATJSON, '$.Q123.Q6') = '6' then 225
            	 when S.charsu= 4 and B.[key] in ('Q30','Q31','Q32_1','Q32_2','Q32_3','Q33','Q34_1','Q34_2','Q34_3','Q34_4','Q34_5','Q36') and JSON_VALUE(D.DATJSON, '$.Q123.Q33') = '3' then 105
            	 when S.charsu= 4 and B.[key] in ('Q37','Q39_1','Q39_2','Q39_3','Q39_4','Q39_5','Q39_6','Q39_7','Q40','Q38','Q41') and JSON_VALUE(D.DATJSON, '$.Q123.Q40') = '4' then 185
            	 when S.charsu= 4 and B.[key] in ('Q42','Q43_1','Q43_2','Q43_3','Q44_1','Q44_2','Q44_3','Q45','Q46','Q47','Q48','Q49_1','Q49_2','Q49_3','Q51','Q127','Q52','Q53_1','Q53_2','Q53_3','Q53_4','Q53_5','Q53_6','Q53_7','Q53_8','Q54','Q115','Q116','Q117','Q118','Q125','Q55','Q56_1','Q56_2','Q56_3','Q57_1','Q57_2','Q57_3','Q57_4','Q57_5','Q58','Q59','Q60','Q61_1','Q61_2','Q61_3','Q62_1','Q62_2','Q62_3','Q63','Q64_1','Q64_2','Q64_3','Q64_4','Q64_5','Q64_6','Q64_7','Q65_1','Q65_2','Q65_3','Q65_4','Q65_5','Q66_1','Q66_2','Q66_3','Q67_1','Q67_2','Q67_3','Q67_4','Q67_5','Q124','Q68','Q69','Q70','Q71','Q72','Q73','Q74','Q75_1','Q75_2','Q75_3','Q75_4','Q75_5','Q76_1','Q76_2','Q76_3','Q76_4','Q76_5','Q76_6','Q76_7','Q76_8','Q77_1','Q77_2','Q77_3','Q77_4','Q77_5','Q77_6','Q77_7','Q77_8') and JSON_VALUE(D.DATJSON, '$.Q123.Q124') = '1' then 960
            	 when S.charsu= 4 and B.[key] in ('Q42','Q43_1','Q43_2','Q43_3','Q44_1','Q44_2','Q44_3','Q45','Q46','Q47','Q48','Q49_1','Q49_2','Q49_3','Q51','Q127','Q52','Q53_1','Q53_2','Q53_3','Q53_4','Q53_5','Q53_6','Q53_7','Q53_8','Q54','Q115','Q116','Q117','Q118','Q125','Q55','Q56_1','Q56_2','Q56_3','Q57_1','Q57_2','Q57_3','Q57_4','Q57_5','Q58','Q59','Q60','Q61_1','Q61_2','Q61_3','Q62_1','Q62_2','Q62_3','Q63','Q64_1','Q64_2','Q64_3','Q64_4','Q64_5','Q64_6','Q64_7','Q65_1','Q65_2','Q65_3','Q65_4','Q65_5','Q66_1','Q66_2','Q66_3','Q67_1','Q67_2','Q67_3','Q67_4','Q67_5','Q124','Q68','Q69','Q70','Q71','Q72','Q73','Q74','Q75_1','Q75_2','Q75_3','Q75_4','Q75_5','Q76_1','Q76_2','Q76_3','Q76_4','Q76_5','Q76_6','Q76_7','Q76_8','Q77_1','Q77_2','Q77_3','Q77_4','Q77_5','Q77_6','Q77_7','Q77_8') and JSON_VALUE(D.DATJSON, '$.Q123.Q71') = '3' then 1080
            	 when S.charsu= 4 and B.[key] in ('Q78','Q79_1','Q79_2','Q79_3','Q79_4','Q80_1','Q80_2','Q80_3','Q80_4','Q80_5','Q80_6') and JSON_VALUE(D.DATJSON, '$.Q123.Q78') = '3' then 50
            else SL.max_score end as max_score,
			B.[key] AS QSID, B.value AS QVAL, SL.weight, S.score_type, S.charsu
	FROM kon.dbo.[DATA] D WITH(NOLOCK)
	CROSS APPLY OPENJSON(DATJSON) A
	CROSS APPLY OPENJSON(A.value) B
	LEFT JOIN (
		SELECT PKEY, QID, JSON_VALUE(QUESTIONJSON, '$.variable') AS SQ
		FROM kon.dbo.QUESTION 
	) V ON D.PKEY = V.PKEY AND SUBSTRING(B.[key], 1, CASE WHEN CHARINDEX('_', B.[key]) = 0 THEN 100 ELSE CHARINDEX('_', B.[key]) END -1) = V.QID COLLATE Korean_Wansung_CI_AS
	LEFT JOIN (
		SELECT IDKEY, 'Q86_1' AS QID, Q84_1 AS Ans, charsu
		FROM WP_LGC_Score_op
		WHERE charsu = '4'
		UNION ALL
		SELECT IDKEY, 'Q89_'+Q91 AS QID, Q91 AS Ans, charsu
		FROM WP_LGC_Score_op 
		WHERE charsu = '4'
	) SO ON D.IDKEY = SO.IDKEY AND B.[key] = SO.QID COLLATE Korean_Wansung_CI_AS AND SO.charsu = '4'
	LEFT JOIN WP_LGC_Score S ON B.[key] = S.QID COLLATE Korean_Wansung_CI_AS AND S.charsu = '4' AND CASE WHEN B.[key] IN ('Q86_1', 'Q89_1', 'Q89_2') THEN SO.Ans ELSE B.value END = S.Ans
	LEFT JOIN WP_LGC_Score_lev SL ON B.[key] = SL.QID COLLATE Korean_Wansung_CI_AS AND SL.charsu = '4'
	WHERE D.PKEY = '2304027_A'
	AND D.SURVEY_TYPE <> 'TEST' AND D.Status = '10' 
	AND B.[key] IS NOT NULL
	AND LEFT(V.SQ, 2) <> 'AQ' AND SUBSTRING(B.[key], 1, CASE WHEN CHARINDEX('_', B.[key]) = 0 THEN 100 ELSE CHARINDEX('_', B.[key]) END -1) <> 'Q124'
	AND S.score IS NOT NULL AND (B.[key] != 'Q6' OR (B.[key] = 'Q6' AND B.value != '6'))
) TT
WHERE score IS NOT NULL
go

