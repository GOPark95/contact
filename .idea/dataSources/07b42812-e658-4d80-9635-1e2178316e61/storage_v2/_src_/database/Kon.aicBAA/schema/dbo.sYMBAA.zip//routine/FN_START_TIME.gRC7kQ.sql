CREATE FUNCTION [dbo].[FN_START_TIME] (
	@time_json nvarchar(max)
)
RETURNS VARCHAR(30)
AS 
BEGIN DECLARE
	@last_time VARCHAR(30)
	select @last_time = (select top 1 value from OPENJSON(@time_json) order by value asc)
	RETURN @last_time
END;
go

