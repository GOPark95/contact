/****** SSMS의 SelectTopNRows 명령 스크립트 ******/
CREATE VIEW dbo.V_BANG_APART_N
AS
SELECT  IDKEY, Status, SURVEY_TYPE, A0, A01_1, A01_2, A02, A03_1, A03_2, A04, A05_1, A05_2, A06_1, A06_2, A07_1, A07_2, A08_1, A08_2, A09_1, A09_2, A10, A11_1, A11_2, A12, A13, A14, 
               A15
FROM     (SELECT  IDKEY, Status, SURVEY_TYPE, ISNULL(JSON_VALUE(DATJSON, '$.Q1.Q1'), '') AS A0, ISNULL(JSON_VALUE(DATJSON, '$.Q5.Q4'), '') AS A01_1, ISNULL(JSON_VALUE(DATJSON, 
                               '$.Q5.Q5'), '') AS A01_2, ISNULL(JSON_VALUE(DATJSON, '$.Q6.Q6'), '') AS A02, ISNULL(JSON_VALUE(DATJSON, '$.Q8.Q7'), '') AS A03_1, ISNULL(JSON_VALUE(DATJSON, '$.Q8.Q8'), 
                               '') AS A03_2, ISNULL(JSON_VALUE(DATJSON, '$.Q9.Q9'), '') AS A04, ISNULL(JSON_VALUE(DATJSON, '$.Q11.Q10'), '') AS A05_1, ISNULL(JSON_VALUE(DATJSON, '$.Q11.Q11'), '') 
                               AS A05_2, ISNULL(JSON_VALUE(DATJSON, '$.Q13.Q12'), '') AS A06_1, ISNULL(JSON_VALUE(DATJSON, '$.Q13.Q13'), '') AS A06_2, ISNULL(JSON_VALUE(DATJSON, '$.Q15.Q14'), '') 
                               AS A07_1, ISNULL(JSON_VALUE(DATJSON, '$.Q15.Q15'), '') AS A07_2, ISNULL(JSON_VALUE(DATJSON, '$.Q17.Q16'), '') AS A08_1, ISNULL(JSON_VALUE(DATJSON, '$.Q17.Q17'), '') 
                               AS A08_2, ISNULL(JSON_VALUE(DATJSON, '$.Q19.Q18'), '') AS A09_1, ISNULL(JSON_VALUE(DATJSON, '$.Q19.Q19'), '') AS A09_2, ISNULL(JSON_VALUE(DATJSON, '$.Q21.Q21'), '') 
                               AS A10, ISNULL(JSON_VALUE(DATJSON, '$.Q23.Q22'), '') AS A11_1, ISNULL(JSON_VALUE(DATJSON, '$.Q23.Q23'), '') AS A11_2, ISNULL(JSON_VALUE(DATJSON, '$.Q24.Q24'), '') 
                               AS A12, ISNULL(JSON_VALUE(DATJSON, '$.Q25.Q25'), '') AS A13, ISNULL(JSON_VALUE(DATJSON, '$.Q26.Q26'), '') AS A14, ISNULL(JSON_VALUE(DATJSON, '$.Q27.Q27'), '') 
                               AS A15
                FROM     dbo.DATA AS DA1 WITH (NOLOCK)
                WHERE  (PKEY = '2208008_A')
                UNION ALL
                SELECT  IDKEY, Status, SURVEY_TYPE, ISNULL(JSON_VALUE(DATJSON, '$.Q32.Q32'), '') AS A0, ISNULL(JSON_VALUE(DATJSON, '$.Q36.Q35'), '') AS A01_1, ISNULL(JSON_VALUE(DATJSON, 
                               '$.Q36.Q36'), '') AS A01_2, ISNULL(JSON_VALUE(DATJSON, '$.Q37.Q37'), '') AS A02, ISNULL(JSON_VALUE(DATJSON, '$.Q39.Q38'), '') AS A03_1, ISNULL(JSON_VALUE(DATJSON, 
                               '$.Q39.Q39'), '') AS A03_2, ISNULL(JSON_VALUE(DATJSON, '$.Q40.Q40'), '') AS A04, ISNULL(JSON_VALUE(DATJSON, '$.Q42.Q41'), '') AS A05_1, ISNULL(JSON_VALUE(DATJSON, 
                               '$.Q42.Q42'), '') AS A05_2, ISNULL(JSON_VALUE(DATJSON, '$.Q44.Q43'), '') AS A06_1, ISNULL(JSON_VALUE(DATJSON, '$.Q44.Q44'), '') AS A06_2, ISNULL(JSON_VALUE(DATJSON, 
                               '$.Q46.Q45'), '') AS A07_1, ISNULL(JSON_VALUE(DATJSON, '$.Q46.Q46'), '') AS A07_2, ISNULL(JSON_VALUE(DATJSON, '$.Q48.Q47'), '') AS A08_1, ISNULL(JSON_VALUE(DATJSON, 
                               '$.Q48.Q48'), '') AS A08_2, ISNULL(JSON_VALUE(DATJSON, '$.Q50.Q49'), '') AS A09_1, ISNULL(JSON_VALUE(DATJSON, '$.Q50.Q50'), '') AS A09_2, ISNULL(JSON_VALUE(DATJSON, 
                               '$.Q52.Q52'), '') AS A10, ISNULL(JSON_VALUE(DATJSON, '$.Q54.Q53'), '') AS A11_1, ISNULL(JSON_VALUE(DATJSON, '$.Q54.Q54'), '') AS A11_2, ISNULL(JSON_VALUE(DATJSON, 
                               '$.Q55.Q55'), '') AS A12, ISNULL(JSON_VALUE(DATJSON, '$.Q56.Q56'), '') AS A13, ISNULL(JSON_VALUE(DATJSON, '$.Q57.Q57'), '') AS A14, ISNULL(JSON_VALUE(DATJSON, 
                               '$.Q58.Q58'), '') AS A15
                FROM     dbo.DATA AS DA2 WITH (NOLOCK)
                WHERE  (PKEY = '2208008_A')) AS OUT_A
WHERE  (Status = '10')
go

exec sp_addextendedproperty 'MS_DiagramPane1', N'[0E232FF0-B466-11cf-A24F-00AA00A3EFFF, 1.00]
Begin DesignProperties = 
   Begin PaneConfigurations = 
      Begin PaneConfiguration = 0
         NumPanes = 4
         Configuration = "(H (1[40] 4[20] 2[20] 3) )"
      End
      Begin PaneConfiguration = 1
         NumPanes = 3
         Configuration = "(H (1 [50] 4 [25] 3))"
      End
      Begin PaneConfiguration = 2
         NumPanes = 3
         Configuration = "(H (1 [50] 2 [25] 3))"
      End
      Begin PaneConfiguration = 3
         NumPanes = 3
         Configuration = "(H (4 [30] 2 [40] 3))"
      End
      Begin PaneConfiguration = 4
         NumPanes = 2
         Configuration = "(H (1 [56] 3))"
      End
      Begin PaneConfiguration = 5
         NumPanes = 2
         Configuration = "(H (2 [66] 3))"
      End
      Begin PaneConfiguration = 6
         NumPanes = 2
         Configuration = "(H (4 [50] 3))"
      End
      Begin PaneConfiguration = 7
         NumPanes = 1
         Configuration = "(V (3))"
      End
      Begin PaneConfiguration = 8
         NumPanes = 3
         Configuration = "(H (1[56] 4[18] 2) )"
      End
      Begin PaneConfiguration = 9
         NumPanes = 2
         Configuration = "(H (1 [75] 4))"
      End
      Begin PaneConfiguration = 10
         NumPanes = 2
         Configuration = "(H (1[66] 2) )"
      End
      Begin PaneConfiguration = 11
         NumPanes = 2
         Configuration = "(H (4 [60] 2))"
      End
      Begin PaneConfiguration = 12
         NumPanes = 1
         Configuration = "(H (1) )"
      End
      Begin PaneConfiguration = 13
         NumPanes = 1
         Configuration = "(V (4))"
      End
      Begin PaneConfiguration = 14
         NumPanes = 1
         Configuration = "(V (2))"
      End
      ActivePaneConfig = 0
   End
   Begin DiagramPane = 
      Begin Origin = 
         Top = 0
         Left = 0
      End
      Begin Tables = 
         Begin Table = "OUT_A"
            Begin Extent = 
               Top = 6
               Left = 38
               Bottom = 136
               Right = 201
            End
            DisplayFlags = 280
            TopColumn = 0
         End
      End
   End
   Begin SQLPane = 
   End
   Begin DataPane = 
      Begin ParameterDefaults = ""
      End
   End
   Begin CriteriaPane = 
      Begin ColumnWidths = 11
         Column = 1440
         Alias = 900
         Table = 1170
         Output = 720
         Append = 1400
         NewValue = 1170
         SortType = 1350
         SortOrder = 1410
         GroupBy = 1350
         Filter = 1350
         Or = 1350
         Or = 1350
         Or = 1350
      End
   End
End
', 'SCHEMA', 'dbo', 'VIEW', 'V_BANG_APART_N'
go

exec sp_addextendedproperty 'MS_DiagramPaneCount', 1, 'SCHEMA', 'dbo', 'VIEW', 'V_BANG_APART_N'
go

