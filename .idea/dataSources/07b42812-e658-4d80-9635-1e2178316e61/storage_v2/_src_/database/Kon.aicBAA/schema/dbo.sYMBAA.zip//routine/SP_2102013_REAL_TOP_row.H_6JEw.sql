CREATE PROCEDURE [dbo].[SP_2102013_REAL_TOP_row]
    @IN_PKEY varchar(20)      -- 프로젝트 ID
	, @IN_INDEX varchar(100) -- @index
	, @IN_GENDER varchar(100) -- @IN_GENDER
	, @IN_AGE varchar(100) -- @IN_AGE
AS 
BEGIN 
	
declare 
 @json nvarchar(max) 
 ,@index nvarchar(64) 
 ,@gender nvarchar(64) 
 ,@age nvarchar(64) 
 ,@store nvarchar(64) 
 
SET NOCOUNT ON

 
 -------Banner 변수-------
 set @index = @IN_INDEX
 set @gender = @IN_GENDER
 set @age = @IN_AGE 
 
 ------KON DATA JSON형태로 가져오기-------

 set @json=( select * 
 from ( 
 select IDKEY, Status,DAT 
 from ( 
 select IDKEY, DATJSON, Status, survey_date 
 from DATA with (nolock) 
 where PKEY = @IN_PKEY and Status='10' and survey_type = 'CAPI' 
 ) IA CROSS APPLY( 
 select DISTINCT '{' + STUFF(( 
 SELECT ',' + SUBSTRING(value,2, LEN(value)-2) 
 FROM OPENJSON(IA.DATJSON) where [value] <> '{}' 
 FOR XML PATH('') 
 ),1,1,' ') + '}' AS DAT 
 ) DAT 
 ) a FOR JSON AUTO) 
 
 
 declare 
 @label_json nvarchar(max) 
 ,@label_out_json nvarchar(max) 
 ,@index_label nvarchar(64) 
  
 set @index_label = (SELECT top(1) VAL1 FROM DBO.FN_SPLIT(@index,'_')) 
 set @label_json=(select [QUESTIONJSON] FROM [Kon].[dbo].[QUESTION] where PKEY=@IN_PKEY and QID = @index_label) 
 set @label_out_json = (select j_value	from(select JSON_QUERY([value],'$.single') as  j_value from OPENJSON(@label_json) where [key] = 'dataset') in_a) 
  
 select json_value(tabB.USER_INFO_JSON, '$.code') as 'code' 
 ,json_value(tabB.USER_INFO_JSON, '$.name') as 'name'	 
 ,tabA.[m_age_20] as 'm_age_20' 
 ,tabA.[m_age_30] as 'm_age_30' 
 ,tabA.[m_age_40] as 'm_age_40' 
 ,tabA.[male] as 'male' 
 ,tabA.[f_age_20] as 'f_age_20' 
 ,tabA.[f_age_30] as 'f_age_30' 
 ,tabA.[f_age_40] as 'f_age_40' 
 ,tabA.[female] as 'female' 
 ,tabA.[index] as 'total' 
 from( 
 select 
 out_b.label_value as [index_value] -- index value 
 ,count([index]) as [index] -- index base 
 ,count([male]) as [male] -- banner1_1 base 
 ,count([m_age_20]) as [m_age_20] -- banner1_2 base 
 ,count([m_age_30]) as [m_age_30] -- banner1_2 base 
 ,count([m_age_40]) as [m_age_40] -- banner1_2 base 
 ,count([female]) as [female] -- banner1_2 base 
 ,count([f_age_20]) as [f_age_20] -- banner1_2 base 
 ,count([f_age_30]) as [f_age_30] -- banner1_2 base 
 ,count([f_age_40]) as [f_age_40] -- banner1_2 base 
 from( 
 select 
 JSON_VALUE(j_value,'$.'+@index) as [index] 
 ,case when JSON_VALUE(j_value,'$.'+@gender) = 1 then JSON_VALUE(j_value,'$.'+@gender) end as [male] 
 ,case when JSON_VALUE(j_value,'$.'+@age) >19 and JSON_VALUE(j_value,'$.'+@age) <30 and JSON_VALUE(j_value,'$.'+@gender) = 1 then 20 end as [m_age_20] 
 ,case when JSON_VALUE(j_value,'$.'+@age) >29 and JSON_VALUE(j_value,'$.'+@age) <40 and JSON_VALUE(j_value,'$.'+@gender) = 1 then 30 end as [m_age_30] 
 ,case when JSON_VALUE(j_value,'$.'+@age) >39 and JSON_VALUE(j_value,'$.'+@age) <50 and JSON_VALUE(j_value,'$.'+@gender) = 1 then 40 end as [m_age_40] 
 ,case when JSON_VALUE(j_value,'$.'+@gender) = 2 then JSON_VALUE(j_value,'$.'+@gender) end as [female] 
 ,case when JSON_VALUE(j_value,'$.'+@age) >19 and JSON_VALUE(j_value,'$.'+@age) <30 and JSON_VALUE(j_value,'$.'+@gender) = 2 then 20 end as [f_age_20] 
 ,case when JSON_VALUE(j_value,'$.'+@age) >29 and JSON_VALUE(j_value,'$.'+@age) <40 and JSON_VALUE(j_value,'$.'+@gender) = 2 then 30 end as [f_age_30] 
 ,case when JSON_VALUE(j_value,'$.'+@age) >39 and JSON_VALUE(j_value,'$.'+@age) <50 and JSON_VALUE(j_value,'$.'+@gender) = 2 then 40 end as [f_age_40] 
  
 from( 
 select JSON_VALUE([value],'$.IDKEY') as idKey,JSON_VALUE([value],'$.DAT') as j_value from OPENJSON(@json) 
 ) in_a 
 where JSON_VALUE(j_value,'$.'+@index) is not null 
 group by JSON_VALUE(j_value,'$.'+@index),j_value,idKey 
 )out_a 
 right join (select JSON_VALUE([value],'$.value') as label_value from OPENJSON(@label_out_json)) out_b on out_a.[index] = out_b.label_value 
 group by out_b.label_value 
 )tabA  
 right join(select * from KON_LIST_TB where PKEY_CD = @IN_PKEY ) tabB on tabA.[index_value] = tabB.IDKEY 
 order by cast(tabA.[index_value] as int) 
 -- FOR JSON AUTO 
 
 SET NOCOUNT OFF;  

END
go

