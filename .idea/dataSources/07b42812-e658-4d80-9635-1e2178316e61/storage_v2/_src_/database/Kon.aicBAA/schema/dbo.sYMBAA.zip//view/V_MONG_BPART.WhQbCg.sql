CREATE VIEW dbo.V_MONG_BPART
AS
SELECT  IDKEY, Status, SURVEY_TYPE, A0, B0, B1, B2, B3, B4, B5, B6, B7, B8, B9, B10, B11, B12, B13, B14, B15, B16, B1_1, B2_1, B4_1, B5_1, B6_1, B10_1, B11_1
FROM     (SELECT  IDKEY, Status, SURVEY_TYPE, ISNULL(JSON_VALUE(DATJSON, '$.Q1.Q1'), '') AS A0, ISNULL(JSON_VALUE(DATJSON, '$.Q9.Q9'), '') AS B0, ISNULL(JSON_VALUE(DATJSON, 
                               '$.Q11.Q11'), '') AS B1, ISNULL(JSON_VALUE(DATJSON, '$.Q13.Q13'), '') AS B2, ISNULL(JSON_VALUE(DATJSON, '$.Q15.Q15'), '') AS B3, ISNULL(JSON_VALUE(DATJSON, 
                               '$.Q16.Q16'), '') AS B4, ISNULL(JSON_VALUE(DATJSON, '$.Q18.Q18'), '') AS B5, ISNULL(JSON_VALUE(DATJSON, '$.Q20.Q20'), '') AS B6, ISNULL(JSON_VALUE(DATJSON, 
                               '$.Q22.Q22'), '') AS B7, ISNULL(JSON_VALUE(DATJSON, '$.Q23.Q23'), '') AS B8, ISNULL(JSON_VALUE(DATJSON, '$.Q24.Q24'), '') AS B9, ISNULL(JSON_VALUE(DATJSON, 
                               '$.Q26.Q26'), '') AS B10, ISNULL(JSON_VALUE(DATJSON, '$.Q28.Q28'), '') AS B11, ISNULL(JSON_VALUE(DATJSON, '$.Q32.Q32'), '') AS B12, ISNULL(JSON_VALUE(DATJSON, 
                               '$.Q33.Q33'), '') AS B13, ISNULL(JSON_VALUE(DATJSON, '$.Q34.Q34'), '') AS B14, ISNULL(JSON_VALUE(DATJSON, '$.Q35.Q35'), '') AS B15, ISNULL(JSON_VALUE(DATJSON, 
                               '$.Q36.Q36'), '') AS B16, ISNULL(JSON_VALUE(DATJSON, '$.Q12.Q12'), '') AS B1_1, ISNULL(JSON_VALUE(DATJSON, '$.Q14.Q14'), '') AS B2_1, ISNULL(JSON_VALUE(DATJSON, 
                               '$.Q17.Q17'), '') AS B4_1, ISNULL(JSON_VALUE(DATJSON, '$.Q19.Q19'), '') AS B5_1, ISNULL(JSON_VALUE(DATJSON, '$.Q21.Q21'), '') AS B6_1, ISNULL(JSON_VALUE(DATJSON, 
                               '$.Q27.Q27'), '') AS B10_1, ISNULL(JSON_VALUE(DATJSON, '$.Q29.Q29'), '') AS B11_1
                FROM     dbo.DATA AS DA1 WITH (NOLOCK)
                WHERE  (PKEY = '2210010_A')
                UNION ALL
                SELECT  IDKEY, Status, SURVEY_TYPE, ISNULL(JSON_VALUE(DATJSON, '$.Q1.Q1'), '') AS A0, ISNULL(JSON_VALUE(DATJSON, '$.Q39.Q39'), '') AS B0, ISNULL(JSON_VALUE(DATJSON, 
                               '$.Q41.Q41'), '') AS B1, ISNULL(JSON_VALUE(DATJSON, '$.Q43.Q43'), '') AS B2, ISNULL(JSON_VALUE(DATJSON, '$.Q45.Q45'), '') AS B3, ISNULL(JSON_VALUE(DATJSON, 
                               '$.Q46.Q46'), '') AS B4, ISNULL(JSON_VALUE(DATJSON, '$.Q48.Q48'), '') AS B5, ISNULL(JSON_VALUE(DATJSON, '$.Q50.Q50'), '') AS B6, ISNULL(JSON_VALUE(DATJSON, 
                               '$.Q52.Q52'), '') AS B7, ISNULL(JSON_VALUE(DATJSON, '$.Q53.Q53'), '') AS B8, ISNULL(JSON_VALUE(DATJSON, '$.Q54.Q54'), '') AS B9, ISNULL(JSON_VALUE(DATJSON, 
                               '$.Q56.Q56'), '') AS B10, ISNULL(JSON_VALUE(DATJSON, '$.Q58.Q58'), '') AS B11, ISNULL(JSON_VALUE(DATJSON, '$.Q62.Q62'), '') AS B12, ISNULL(JSON_VALUE(DATJSON, 
                               '$.Q63.Q63'), '') AS B13, ISNULL(JSON_VALUE(DATJSON, '$.Q64.Q64'), '') AS B14, ISNULL(JSON_VALUE(DATJSON, '$.Q65.Q65'), '') AS B15, ISNULL(JSON_VALUE(DATJSON, 
                               '$.Q66.Q66'), '') AS B16, ISNULL(JSON_VALUE(DATJSON, '$.Q42.Q42'), '') AS B1_1, ISNULL(JSON_VALUE(DATJSON, '$.Q44.Q44'), '') AS B2_1, ISNULL(JSON_VALUE(DATJSON, 
                               '$.Q47.Q47'), '') AS B4_1, ISNULL(JSON_VALUE(DATJSON, '$.Q49.Q49'), '') AS B5_1, ISNULL(JSON_VALUE(DATJSON, '$.Q51.Q51'), '') AS B6_1, ISNULL(JSON_VALUE(DATJSON, 
                               '$.Q57.Q57'), '') AS B10_1, ISNULL(JSON_VALUE(DATJSON, '$.Q59.Q59'), '') AS B11_1
                FROM     dbo.DATA AS DA2 WITH (NOLOCK)
                WHERE  (PKEY = '2210010_A')
                UNION ALL
                SELECT  IDKEY, Status, SURVEY_TYPE, ISNULL(JSON_VALUE(DATJSON, '$.Q1.Q1'), '') AS A0, ISNULL(JSON_VALUE(DATJSON, '$.Q69.Q69'), '') AS B0, ISNULL(JSON_VALUE(DATJSON, 
                               '$.Q71.Q71'), '') AS B1, ISNULL(JSON_VALUE(DATJSON, '$.Q73.Q73'), '') AS B2, ISNULL(JSON_VALUE(DATJSON, '$.Q75.Q75'), '') AS B3, ISNULL(JSON_VALUE(DATJSON, 
                               '$.Q76.Q76'), '') AS B4, ISNULL(JSON_VALUE(DATJSON, '$.Q78.Q78'), '') AS B5, ISNULL(JSON_VALUE(DATJSON, '$.Q80.Q80'), '') AS B6, ISNULL(JSON_VALUE(DATJSON, 
                               '$.Q82.Q82'), '') AS B7, ISNULL(JSON_VALUE(DATJSON, '$.Q83.Q83'), '') AS B8, ISNULL(JSON_VALUE(DATJSON, '$.Q84.Q84'), '') AS B9, ISNULL(JSON_VALUE(DATJSON, 
                               '$.Q86.Q86'), '') AS B10, ISNULL(JSON_VALUE(DATJSON, '$.Q88.Q88'), '') AS B11, ISNULL(JSON_VALUE(DATJSON, '$.Q92.Q92'), '') AS B12, ISNULL(JSON_VALUE(DATJSON, 
                               '$.Q93.Q93'), '') AS B13, ISNULL(JSON_VALUE(DATJSON, '$.Q94.Q94'), '') AS B14, ISNULL(JSON_VALUE(DATJSON, '$.Q95.Q95'), '') AS B15, ISNULL(JSON_VALUE(DATJSON, 
                               '$.Q96.Q96'), '') AS B16, ISNULL(JSON_VALUE(DATJSON, '$.Q72.Q72'), '') AS B1_1, ISNULL(JSON_VALUE(DATJSON, '$.Q74.Q74'), '') AS B2_1, ISNULL(JSON_VALUE(DATJSON, 
                               '$.Q77.Q77'), '') AS B4_1, ISNULL(JSON_VALUE(DATJSON, '$.Q79.Q79'), '') AS B5_1, ISNULL(JSON_VALUE(DATJSON, '$.Q81.Q81'), '') AS B6_1, ISNULL(JSON_VALUE(DATJSON, 
                               '$.Q87.Q87'), '') AS B10_1, ISNULL(JSON_VALUE(DATJSON, '$.Q89.Q89'), '') AS B11_1
                FROM     dbo.DATA AS DA3 WITH (NOLOCK)
                WHERE  (PKEY = '2210010_A')
                UNION ALL
                SELECT  IDKEY, Status, SURVEY_TYPE, ISNULL(JSON_VALUE(DATJSON, '$.Q1.Q1'), '') AS A0, ISNULL(JSON_VALUE(DATJSON, '$.Q99.Q99'), '') AS B0, ISNULL(JSON_VALUE(DATJSON, 
                               '$.Q101.Q101'), '') AS B1, ISNULL(JSON_VALUE(DATJSON, '$.Q103.Q103'), '') AS B2, ISNULL(JSON_VALUE(DATJSON, '$.Q105.Q105'), '') AS B3, ISNULL(JSON_VALUE(DATJSON, 
                               '$.Q106.Q106'), '') AS B4, ISNULL(JSON_VALUE(DATJSON, '$.Q108.Q108'), '') AS B5, ISNULL(JSON_VALUE(DATJSON, '$.Q110.Q110'), '') AS B6, ISNULL(JSON_VALUE(DATJSON, 
                               '$.Q112.Q112'), '') AS B7, ISNULL(JSON_VALUE(DATJSON, '$.Q113.Q113'), '') AS B8, ISNULL(JSON_VALUE(DATJSON, '$.Q114.Q114'), '') AS B9, ISNULL(JSON_VALUE(DATJSON, 
                               '$.Q116.Q116'), '') AS B10, ISNULL(JSON_VALUE(DATJSON, '$.Q118.Q118'), '') AS B11, ISNULL(JSON_VALUE(DATJSON, '$.Q122.Q122'), '') AS B12, ISNULL(JSON_VALUE(DATJSON, 
                               '$.Q123.Q123'), '') AS B13, ISNULL(JSON_VALUE(DATJSON, '$.Q124.Q124'), '') AS B14, ISNULL(JSON_VALUE(DATJSON, '$.Q125.Q125'), '') AS B15, ISNULL(JSON_VALUE(DATJSON, 
                               '$.Q126.Q126'), '') AS B16, ISNULL(JSON_VALUE(DATJSON, '$.Q102.Q102'), '') AS B1_1, ISNULL(JSON_VALUE(DATJSON, '$.Q104.Q104'), '') AS B2_1, 
                               ISNULL(JSON_VALUE(DATJSON, '$.Q107.Q107'), '') AS B4_1, ISNULL(JSON_VALUE(DATJSON, '$.Q109.Q109'), '') AS B5_1, ISNULL(JSON_VALUE(DATJSON, '$.Q111.Q111'), '') 
                               AS B6_1, ISNULL(JSON_VALUE(DATJSON, '$.Q117.Q117'), '') AS B10_1, ISNULL(JSON_VALUE(DATJSON, '$.Q119.Q119'), '') AS B11_1
                FROM     dbo.DATA AS DA4 WITH (NOLOCK)
                WHERE  (PKEY = '2210010_A')) AS OUT_A
WHERE  (Status = '10')
go

exec sp_addextendedproperty 'MS_DiagramPane1', N'[0E232FF0-B466-11cf-A24F-00AA00A3EFFF, 1.00]
Begin DesignProperties = 
   Begin PaneConfigurations = 
      Begin PaneConfiguration = 0
         NumPanes = 4
         Configuration = "(H (1[40] 4[20] 2[20] 3) )"
      End
      Begin PaneConfiguration = 1
         NumPanes = 3
         Configuration = "(H (1 [50] 4 [25] 3))"
      End
      Begin PaneConfiguration = 2
         NumPanes = 3
         Configuration = "(H (1 [50] 2 [25] 3))"
      End
      Begin PaneConfiguration = 3
         NumPanes = 3
         Configuration = "(H (4 [30] 2 [40] 3))"
      End
      Begin PaneConfiguration = 4
         NumPanes = 2
         Configuration = "(H (1 [56] 3))"
      End
      Begin PaneConfiguration = 5
         NumPanes = 2
         Configuration = "(H (2 [66] 3))"
      End
      Begin PaneConfiguration = 6
         NumPanes = 2
         Configuration = "(H (4 [50] 3))"
      End
      Begin PaneConfiguration = 7
         NumPanes = 1
         Configuration = "(V (3))"
      End
      Begin PaneConfiguration = 8
         NumPanes = 3
         Configuration = "(H (1[56] 4[18] 2) )"
      End
      Begin PaneConfiguration = 9
         NumPanes = 2
         Configuration = "(H (1 [75] 4))"
      End
      Begin PaneConfiguration = 10
         NumPanes = 2
         Configuration = "(H (1[66] 2) )"
      End
      Begin PaneConfiguration = 11
         NumPanes = 2
         Configuration = "(H (4 [60] 2))"
      End
      Begin PaneConfiguration = 12
         NumPanes = 1
         Configuration = "(H (1) )"
      End
      Begin PaneConfiguration = 13
         NumPanes = 1
         Configuration = "(V (4))"
      End
      Begin PaneConfiguration = 14
         NumPanes = 1
         Configuration = "(V (2))"
      End
      ActivePaneConfig = 0
   End
   Begin DiagramPane = 
      Begin Origin = 
         Top = 0
         Left = 0
      End
      Begin Tables = 
         Begin Table = "OUT_A"
            Begin Extent = 
               Top = 6
               Left = 38
               Bottom = 136
               Right = 201
            End
            DisplayFlags = 280
            TopColumn = 0
         End
      End
   End
   Begin SQLPane = 
   End
   Begin DataPane = 
      Begin ParameterDefaults = ""
      End
   End
   Begin CriteriaPane = 
      Begin ColumnWidths = 11
         Column = 1440
         Alias = 900
         Table = 1170
         Output = 720
         Append = 1400
         NewValue = 1170
         SortType = 1350
         SortOrder = 1410
         GroupBy = 1350
         Filter = 1350
         Or = 1350
         Or = 1350
         Or = 1350
      End
   End
End
', 'SCHEMA', 'dbo', 'VIEW', 'V_MONG_BPART'
go

exec sp_addextendedproperty 'MS_DiagramPaneCount', 1, 'SCHEMA', 'dbo', 'VIEW', 'V_MONG_BPART'
go

