CREATE PROCEDURE [dbo].[SP_2102013_REAL_DQ1]
    @IN_PKEY varchar(20)      -- 프로젝트 ID
	, @IN_INDEX varchar(100) -- @index
AS 
BEGIN

declare 
 @json nvarchar(max) 
 ,@gender nvarchar(64) 
 ,@age nvarchar(64) 
 
SET NOCOUNT ON

 -------Banner 변수-------
 set @gender = 'Q1' 
 set @age = 'Q2_1' 
 
 ------KON DATA JSON형태로 가져오기-------
set @json=( select *
  from (
	select IDKEY, Status,DAT
	from (
		select IDKEY, DATJSON, Status, survey_date
		from DATA with (nolock)
		where PKEY = @IN_PKEY and Status='10' and SURVEY_TYPE = 'CAPI'
   ) IA CROSS APPLY(
     select DISTINCT '{' + STUFF((
         SELECT ',' + SUBSTRING(value,2, LEN(value)-2)
         FROM OPENJSON(IA.DATJSON) where [value] <> '{}'
         FOR XML PATH('')
     ),1,1,' ') + '}' AS DAT
) DAT
) a FOR JSON AUTO)
 
 --------분모 테이블 집계(카운트)--------
 Declare @total_table Table(
    [index_value]  nvarchar(8)
    ,[index] numeric(16,13)
    ,[male] numeric(16,13)
    ,[female] numeric(16,13)
    ,[age_20] numeric(16,13)
    ,[age_30] numeric(16,13)
    ,[age_40] numeric(16,13)
	,[age_50] numeric(16,13)
)
insert into @total_table
select
    'total' as [index_value]
    ,count([index]) as [index] -- index base
    ,count([male]) as [male] -- banner1_1 base
    ,count([female]) as [female] -- banner1_2 base
    ,count([age_20]) as [age_20] -- banner1_2 base
    ,count([age_30]) as [age_30] -- banner1_2 base
    ,count([age_40]) as [age_40] -- banner1_2 base
	,count([age_50]) as [age_50] -- banner1_2 base
    from(
        select
            JSON_VALUE(j_value,'$.'+@IN_INDEX) as [index]
            ,case when JSON_VALUE(j_value,'$.'+@gender) = 1 then JSON_VALUE(j_value,'$.'+@gender) end as [male]
            ,case when JSON_VALUE(j_value,'$.'+@gender) = 2 then JSON_VALUE(j_value,'$.'+@gender) end as [female]
            ,case when JSON_VALUE(j_value,'$.'+@age) >=19 and JSON_VALUE(j_value,'$.'+@age) <30 then 20 end as [age_20]
            ,case when JSON_VALUE(j_value,'$.'+@age) >29 and JSON_VALUE(j_value,'$.'+@age) <40 then 30 end as [age_30]
            ,case when JSON_VALUE(j_value,'$.'+@age) >39 and JSON_VALUE(j_value,'$.'+@age) <50 then 40 end as [age_40]
			,case when JSON_VALUE(j_value,'$.'+@age) >49 and JSON_VALUE(j_value,'$.'+@age) <60 then 50 end as [age_50]
        from(
          select JSON_VALUE([value],'$.IDKEY') as idKey,JSON_VALUE([value],'$.DAT') as j_value from OPENJSON(@json)
        ) in_a
		where JSON_VALUE(j_value,'$.'+@IN_INDEX) is not null
group by JSON_VALUE(j_value,'$.'+@IN_INDEX),j_value,idKey
)out_a


select *
from
(
--------결과 테이블에 분모 테이블 얹기--------
	select * from @total_table

	union all
--------분자/분모--------
	select
	a_case.[index_value] as [index_value] -- index value
	,case when a_total.[index]=0 then 0 else a_case.[index]/a_total.[index] end  as [index]
	,case when a_total.[male]=0 then 0 else a_case.[male]/a_total.[male] end as [male] -- banner1_1 base
	,case when a_total.[female]=0 then 0 else a_case.[female]/a_total.[female] end as [female] -- banner1_2 base
	,case when a_total.[age_20]=0 then 0 else a_case.[age_20]/a_total.[age_20] end as [age_20] -- banner1_2 base
	,case when a_total.[age_30]=0 then 0 else a_case.[age_30]/a_total.[age_30] end as [age_30] -- banner1_2 base
	,case when a_total.[age_40]=0 then 0 else a_case.[age_40]/a_total.[age_40] end as [age_40] -- banner1_2 base
	,case when a_total.[age_50]=0 then 0 else a_case.[age_50]/a_total.[age_50] end as [age_50] -- banner1_2 base
--------분자 테이블과 분모 테이블 조인--------
	from @total_table a_total right join
	(
--------분자 테이블 집계(Sum)--------
		select
		'sum' as [index_value] -- index value
		,sum(cast([index] as numeric(16,13))) as [index] -- index base
		,sum(cast([male] as numeric(16,13))) as [male] -- banner1_1 base
		,sum(cast([female] as numeric(16,13))) as [female] -- banner1_2 base
		,sum(cast([age_20] as numeric(16,13))) as [age_20] -- banner1_2 base
		,sum(cast([age_30] as numeric(16,13))) as [age_30] -- banner1_2 base
		,sum(cast([age_40] as numeric(16,13))) as [age_40] -- banner1_2 base
		,sum(cast([age_50] as numeric(16,13))) as [age_50] -- banner1_2 base
		from(
			select
				JSON_VALUE(j_value,'$.'+@IN_INDEX) as [index]
				,case when JSON_VALUE(j_value,'$.'+@gender) = 1 then JSON_VALUE(j_value,'$.'+@IN_INDEX) end as [male]
				,case when JSON_VALUE(j_value,'$.'+@gender) = 2 then JSON_VALUE(j_value,'$.'+@IN_INDEX) end as [female]
				,case when JSON_VALUE(j_value,'$.'+@age) >=19 and JSON_VALUE(j_value,'$.'+@age) <30 then JSON_VALUE(j_value,'$.'+@IN_INDEX) end as [age_20]
				,case when JSON_VALUE(j_value,'$.'+@age) >29 and JSON_VALUE(j_value,'$.'+@age) <40 then JSON_VALUE(j_value,'$.'+@IN_INDEX) end as [age_30]
				,case when JSON_VALUE(j_value,'$.'+@age) >39 and JSON_VALUE(j_value,'$.'+@age) <50 then JSON_VALUE(j_value,'$.'+@IN_INDEX) end as [age_40]
				,case when JSON_VALUE(j_value,'$.'+@age) >49 and JSON_VALUE(j_value,'$.'+@age) <60 then JSON_VALUE(j_value,'$.'+@IN_INDEX) end as [age_50]
			from(
			select JSON_VALUE([value],'$.IDKEY') as idKey,JSON_VALUE([value],'$.DAT') as j_value from OPENJSON(@json)
			) in_a
			where JSON_VALUE(j_value,'$.'+@IN_INDEX) is not null
		)out_a
	) a_case on 1=1
) super_a
 --FOR JSON AUTO 
 
 SET NOCOUNT OFF;  

END
go

