CREATE FUNCTION [dbo].[FN_EXIST_KEY] (
	@text nvarchar(max),
	@chkkey VARCHAR(5)
)
RETURNS VARCHAR(5) 
AS 
BEGIN DECLARE
	 @cnt VARCHAR(5)
	select @cnt = count(*)  from OPENJSON(@text) where [key] = @chkkey
	RETURN @cnt
END
go

