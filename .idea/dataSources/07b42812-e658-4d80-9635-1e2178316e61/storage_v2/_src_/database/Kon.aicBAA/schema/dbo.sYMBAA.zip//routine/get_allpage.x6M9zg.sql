CREATE PROCEDURE [dbo].[get_allpage]
	-- 프로젝트 모든 문항 정보 가져오기
	@PKEY varchar(20) -- 프로젝트 ID
AS
BEGIN
	select 	
		QID, -- 문 ID
		Qorder, -- 순서
		isnull(qroot,QID) as qroot, -- 그룹문항일 경우 저장되는 key
		json_value(QUESTIONJSON,'$.variable') as variable, -- 문번
		json_value(QUESTIONJSON,'$.qtype') as qtype, -- 문항 타입
		json_value(QUESTIONJSON,'$.title') as title, -- 문항 타이틀
		json_value(QUESTIONJSON,'$.description') as description , -- 문항 안내문
		CASE WHEN LOGICJSON = '' THEN '' ELSE JSON_QUERY(LOGICJSON ,'$.p') END as plogic,  --문항 사전 로직
		CASE WHEN LOGICJSON = '' THEN '' ELSE JSON_QUERY(LOGICJSON ,'$.n') END as nlogic  -- 문항 사후 로직 
	from QUESTION as Qu
	CROSS APPLY ( select [value] from OPENJSON(QUESTIONJSON) where [key]= 'qgroup' )  RB
	OUTER APPLY ( 
		select qgroup, qroot from (
			select JSON_VALUE(QUESTIONJSON,'$.qgroup') as qgroup, max(Qorder) as qorder from QUESTION where PKEY = @PKEY and JSON_VALUE(QUESTIONJSON,'$.qgroup') <> '' group by JSON_VALUE(QUESTIONJSON,'$.qgroup')
		) A CROSS APPLY (
			select QID as qroot from QUESTION where PKEY = @PKEY and Qorder = A.qorder
		) B where RB.value = A.qgroup
	)  C
END;
go

