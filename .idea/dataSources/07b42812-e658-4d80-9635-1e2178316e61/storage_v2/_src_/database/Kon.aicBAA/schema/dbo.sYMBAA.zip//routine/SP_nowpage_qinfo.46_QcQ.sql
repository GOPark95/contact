CREATE PROCEDURE [dbo].[SP_nowpage_qinfo]
	-- 문항 진입시 현재 페이지로 수정하고 문항 정보 가져옴
	@PKEY varchar(20), -- 프로젝트 ID
	@IDKEY varchar(100), -- 응답자 ID
	@QID varchar(20) -- 페이지 ID
AS
BEGIN
		SET NOCOUNT ON
		update kon.dbo.DATA set PAGENAME = @QID where IDKEY= @IDKEY and PKEY= @PKEY		
		select JSON_QUERY(QUESTIONJSON) as qx, CASE WHEN LOGICJSON <> '' THEN JSON_QUERY(LOGICJSON) ELSE '' END as jx, Qorder from kon.dbo.QUESTION with(nolock) where PKEY = @PKEY and QID = @QID FOR JSON AUTO		
END;
go

