CREATE PROCEDURE [dbo].[question_group]
	-- 문항 그룹 가져오기
	@PKEY varchar(20), -- 프로젝트 ID
	@GID varchar(20) -- 그룹ID

AS
BEGIN
	DECLARE 
		@output NVARCHAR(MAX),
	 	@ginfo VARCHAR(200)
	 		
	set @ginfo = (select JSON_VALUE(OPTIONJSON,'$."'+@GID+'".stype') as [stype],ISNULL(JSON_QUERY(OPTIONJSON,'$."'+@GID+'".option'),'""') as [option] from  kon.dbo.QOPTION with(nolock) where PKEY = @PKEY and OTYPE = 'qgroup' FOR JSON PATH)
	set @ginfo = (SUBSTRING(@ginfo,3,LEN(@ginfo)-4))
	set @output = '{"var":'
	set	@output = @output +	(select( select QID,JSON_QUERY(QUESTIONJSON) as qx, CASE WHEN LOGICJSON <> '' THEN JSON_QUERY(LOGICJSON) ELSE '' END as jx, cast(Qorder as varchar(10)) as Qorder from kon.dbo.QUESTION with(nolock) where PKEY = @PKEY and JSON_VALUE(QUESTIONJSON,'$.qgroup') = @GID order by cast(Qorder as int) FOR JSON PATH ))
	set @output = @output + ',' + @ginfo
	set @output = @output + '}'
	select @output
END
go

