CREATE PROCEDURE dbo.SP_JSON_TO_ROW 
    @PKEY varchar(20) -- 프로젝트 ID
	--, @IDKEY varchar(100) -- 응답자 ID
	--, @QTYPE varchar(20) -- 타입 TEST  REAL
AS 
BEGIN
		DECLARE @QUERY     NVARCHAR(MAX) = '',
                @WHERE     NVARCHAR(MAX) = ' ',
                @PARAMETER NVARCHAR(MAX) = '',
                @LASTQID   NVARCHAR(1000) = 'Q26'
		 
		SET NOCOUNT ON
		
		
		-- STRUCTURE 에서 문항번호 가져오기		
		CREATE TABLE #TBL_SP_JSON_TO_ROW ( K01 nVarchar(124), K02 nVarchar(124)  );		
		INSERT INTO #TBL_SP_JSON_TO_ROW 
		--SELECT [key], REPLACE(REPLACE(REPLACE([value], '"', ''), '[', ''), ']', '')
		--FROM kon.dbo.STRUCTURE
		--CROSS APPLY OPENJSON(REPLACE(REPLACE(REPLACE(QINFO, '"[', '['), ']"', ']'), '\"', '"')) T
		--WHERE PKEY = @PKEY;	 
		SELECT K01
		--, (CASE WHEN K02 = '' THEN K01 ELSE K02 END) AS K02
		, (CASE WHEN VALUE = '' THEN K01 ELSE VALUE END) AS K02
		FROM (
			SELECT [key] AS K01, REPLACE(REPLACE(REPLACE([value], '"', ''), '[', ''), ']', '') AS K02
			FROM kon.dbo.STRUCTURE
			CROSS APPLY OPENJSON(REPLACE(REPLACE(REPLACE(QINFO, '"[', '['), ']"', ']'), '\"', '"')) T
			WHERE PKEY = @PKEY
		) X 
		CROSS APPLY STRING_SPLIT(K02 , ',');
		--SELECT * FROM #TBL_SP_JSON_TO_ROW;
		
	    DECLARE @INDEX INT, @K01 nVarchar(124), @K02 nVarchar(124), @K03 nVarchar(124)
	    SET @INDEX = 0; --INDEX초기화
	    
	    DECLARE CUR CURSOR FOR   --CUR라는 이름의 커서 선언
	    SELECT K01, K02 FROM #TBL_SP_JSON_TO_ROW
	    OPEN CUR      --커서 오픈
	        FETCH NEXT FROM CUR INTO @K01, @K02  --SELECT한 값을 @K01,@K02 변수에 넣는다.
	        --커서를이용해 한ROW씩 읽음 
			WHILE @@FETCH_STATUS = 0
			BEGIN
			SET @INDEX = @INDEX + 1; --INDEX증가
			
			IF @K02 = '' 
			BEGIN 
		        SET @K03 = @K01;
			END ELSE BEGIN
		        SET @K03 = @K01 +'.'+ @K02;
			END
		   
		    SET @PARAMETER += ' , JSON_VALUE(DJ, ''$.'+ @K03 +''' ) AS ''$.'+ @K02 +''' '	
		 
			
				
			
			--SELECT 한 데이터의 행집합을 가지고 수행할 작업
			FETCH NEXT FROM CUR INTO @K01, @K02--다음ROW로 이동
		END
		
		--커서 닫고 초기화
		CLOSE CUR
		DEALLOCATE CUR
	
		
		SET @QUERY = 'SELECT IDKEY '
		SET @QUERY += ' , JSON_VALUE(sd, ''$.' + @LASTQID +''') AS survey_date '
		
        SET @QUERY += @PARAMETER 
		SET @QUERY += ' , *  '
	    
	    SET @QUERY += ' FROM ( '
	    SET @QUERY += ' SELECT IDKEY '
	    SET @QUERY += ' , JSON_QUERY(DATJSON) as DJ  '		
		SET @QUERY += ' , JSON_QUERY(survey_date) as sd  '		
		SET @QUERY += ' from  dbo.DATA with(nolock) '
		
		SET @WHERE =  ' where PKEY = ''' + @PKEY +'''  AND Status = 10 ' 
		
        SET @QUERY += @WHERE 
		SET @QUERY += ' ) X '
       
		-- select JSON_QUERY(DATJSON) as qx  from  dbo.DATA with(nolock)  where PKEY = @PKEY 
	    
		-- SELECT @QUERY;
		
		EXEC sp_executesql @QUERY 
		
		DROP TABLE #TBL_SP_JSON_TO_ROW
		
END;
go

exec sp_addextendedproperty 'MS_Description', 'JSON TO ROW', 'SCHEMA', 'dbo', 'PROCEDURE', 'SP_JSON_TO_ROW'
go

