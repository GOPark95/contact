CREATE PROCEDURE [dbo].[update_data]
	-- 문항 수정함 백업 데이터 있을 경우 백업데이터에 삽입
	@PKEY varchar(20), -- 프로젝트 ID
	@IDKEY varchar(100), -- 응답자 ID
	@QID varchar(20), -- 페이지 ID
	@PAGE_DATA NVARCHAR(MAX), -- 페이지 데이터
	@CHARGE_PERSON varchar(30) --- 수정한 사람
AS
BEGIN
	set nocount on
	DECLARE @cnt varchar(1)
	DECLARE	@json_txt nvarchar(max)	
	DECLARE @before_json nvarchar(max)
	
	-- 기존 데이터 유무 체크
	select @json_txt = DATJSON from [DATA] where pkey = @pkey and idkey = @idkey
	-- 데이터 없으면 오류 아웃
	IF ISNULL(@json_txt,'') = ''
		BEGIN
			RETURN;
		END 

	-- JSON에 해당 페이지 값이 있는 지 체크
	EXEC @cnt = [dbo].[FN_EXIST_KEY] @json_txt, @QID
	
	-- 있을 경우 백업데이터에 저장
	IF @cnt = '1'
		BEGIN
			select @before_json = [value] from OPENJSON(@json_txt) where [key] = @QID
			INSERT INTO BACKUP_DATA_TB values (@PKEY, @IDKEY, @QID, @CHARGE_PERSON, @before_json, CONVERT(CHAR(23), getDate(), 21))
		END
	
	UPDATE [KON].[dbo].[DATA] set DATJSON = JSON_MODIFY(DATJSON , '$.'+@QID, JSON_QUERY(@PAGE_DATA) ) where pkey = @pkey and idkey = @idkey 
END;
go

