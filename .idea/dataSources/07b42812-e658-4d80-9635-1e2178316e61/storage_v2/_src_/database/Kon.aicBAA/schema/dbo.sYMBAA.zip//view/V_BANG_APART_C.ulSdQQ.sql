CREATE VIEW dbo.V_BANG_APART_C
AS
SELECT  IDKEY, Status, SURVEY_TYPE, B0, B01_1, B01_2, B02, B03_1, B03_2, B04, B05_1, B05_2, B06_1, B06_2, B07_1, B07_2, B08_1, B08_2, B09_1, B09_2, B10, B11_1, B11_2, B12, B13_1, 
               B13_2, B14, B15, B16_1, B16_2, B17, B18, B19, B20
FROM     (SELECT  IDKEY, Status, SURVEY_TYPE, ISNULL(JSON_VALUE(DATJSON, '$.Q2.Q2'), '') AS B0, ISNULL(JSON_VALUE(DATJSON, '$.Q8.Q7'), '') AS B01_1, ISNULL(JSON_VALUE(DATJSON, 
                               '$.Q8.Q8'), '') AS B01_2, ISNULL(JSON_VALUE(DATJSON, '$.Q9.Q9'), '') AS B02, ISNULL(JSON_VALUE(DATJSON, '$.Q11.Q10'), '') AS B03_1, ISNULL(JSON_VALUE(DATJSON, 
                               '$.Q11.Q11'), '') AS B03_2, ISNULL(JSON_VALUE(DATJSON, '$.Q12.Q12'), '') AS B04, ISNULL(JSON_VALUE(DATJSON, '$.Q14.Q13'), '') AS B05_1, ISNULL(JSON_VALUE(DATJSON, 
                               '$.Q14.Q14'), '') AS B05_2, ISNULL(JSON_VALUE(DATJSON, '$.Q16.Q15'), '') AS B06_1, ISNULL(JSON_VALUE(DATJSON, '$.Q16.Q16'), '') AS B06_2, ISNULL(JSON_VALUE(DATJSON, 
                               '$.Q18.Q17'), '') AS B07_1, ISNULL(JSON_VALUE(DATJSON, '$.Q18.Q18'), '') AS B07_2, ISNULL(JSON_VALUE(DATJSON, '$.Q20.Q19'), '') AS B08_1, ISNULL(JSON_VALUE(DATJSON, 
                               '$.Q20.Q20'), '') AS B08_2, ISNULL(JSON_VALUE(DATJSON, '$.Q22.Q21'), '') AS B09_1, ISNULL(JSON_VALUE(DATJSON, '$.Q22.Q22'), '') AS B09_2, ISNULL(JSON_VALUE(DATJSON, 
                               '$.Q23.Q23'), '') AS B10, ISNULL(JSON_VALUE(DATJSON, '$.Q26.Q25'), '') AS B11_1, ISNULL(JSON_VALUE(DATJSON, '$.Q26.Q26'), '') AS B11_2, ISNULL(JSON_VALUE(DATJSON, 
                               '$.Q27.Q27'), '') AS B12, ISNULL(JSON_VALUE(DATJSON, '$.Q29.Q28'), '') AS B13_1, ISNULL(JSON_VALUE(DATJSON, '$.Q29.Q29'), '') AS B13_2, ISNULL(JSON_VALUE(DATJSON, 
                               '$.Q30.Q30'), '') AS B14, ISNULL(JSON_VALUE(DATJSON, '$.Q32.Q32'), '') AS B15, ISNULL(JSON_VALUE(DATJSON, '$.Q34.Q33'), '') AS B16_1, ISNULL(JSON_VALUE(DATJSON, 
                               '$.Q34.Q34'), '') AS B16_2, ISNULL(JSON_VALUE(DATJSON, '$.Q35.Q35'), '') AS B17, ISNULL(JSON_VALUE(DATJSON, '$.Q36.Q36'), '') AS B18, ISNULL(JSON_VALUE(DATJSON, 
                               '$.Q37.Q37'), '') AS B19, ISNULL(JSON_VALUE(DATJSON, '$.Q38.Q38'), '') AS B20
                FROM     dbo.DATA AS DA1 WITH (NOLOCK)
                WHERE  (PKEY = '2208008_B')
                UNION ALL
                SELECT  IDKEY, Status, SURVEY_TYPE, ISNULL(JSON_VALUE(DATJSON, '$.Q3.Q3'), '') AS B0, ISNULL(JSON_VALUE(DATJSON, '$.Q45.Q44'), '') AS B01_1, ISNULL(JSON_VALUE(DATJSON, 
                               '$.Q45.Q45'), '') AS B01_2, ISNULL(JSON_VALUE(DATJSON, '$.Q46.Q46'), '') AS B02, ISNULL(JSON_VALUE(DATJSON, '$.Q48.Q47'), '') AS B03_1, ISNULL(JSON_VALUE(DATJSON, 
                               '$.Q48.Q48'), '') AS B03_2, ISNULL(JSON_VALUE(DATJSON, '$.Q49.Q49'), '') AS B04, ISNULL(JSON_VALUE(DATJSON, '$.Q51.Q50'), '') AS B05_1, ISNULL(JSON_VALUE(DATJSON, 
                               '$.Q51.Q51'), '') AS B05_2, ISNULL(JSON_VALUE(DATJSON, '$.Q53.Q52'), '') AS B06_1, ISNULL(JSON_VALUE(DATJSON, '$.Q53.Q53'), '') AS B06_2, ISNULL(JSON_VALUE(DATJSON, 
                               '$.Q55.Q54'), '') AS B07_1, ISNULL(JSON_VALUE(DATJSON, '$.Q55.Q55'), '') AS B07_2, ISNULL(JSON_VALUE(DATJSON, '$.Q57.Q56'), '') AS B08_1, ISNULL(JSON_VALUE(DATJSON, 
                               '$.Q57.Q57'), '') AS B08_2, ISNULL(JSON_VALUE(DATJSON, '$.Q59.Q58'), '') AS B09_1, ISNULL(JSON_VALUE(DATJSON, '$.Q59.Q59'), '') AS B09_2, ISNULL(JSON_VALUE(DATJSON, 
                               '$.Q60.Q60'), '') AS B10, ISNULL(JSON_VALUE(DATJSON, '$.Q63.Q62'), '') AS B11_1, ISNULL(JSON_VALUE(DATJSON, '$.Q63.Q63'), '') AS B11_2, ISNULL(JSON_VALUE(DATJSON, 
                               '$.Q64.Q64'), '') AS B12, ISNULL(JSON_VALUE(DATJSON, '$.Q66.Q65'), '') AS B13_1, ISNULL(JSON_VALUE(DATJSON, '$.Q66.Q66'), '') AS B13_2, ISNULL(JSON_VALUE(DATJSON, 
                               '$.Q67.Q67'), '') AS B14, ISNULL(JSON_VALUE(DATJSON, '$.Q69.Q69'), '') AS B15, ISNULL(JSON_VALUE(DATJSON, '$.Q71.Q70'), '') AS B16_1, ISNULL(JSON_VALUE(DATJSON, 
                               '$.Q71.Q71'), '') AS B16_2, ISNULL(JSON_VALUE(DATJSON, '$.Q72.Q72'), '') AS B17, ISNULL(JSON_VALUE(DATJSON, '$.Q73.Q73'), '') AS B18, ISNULL(JSON_VALUE(DATJSON, 
                               '$.Q74.Q74'), '') AS B19, ISNULL(JSON_VALUE(DATJSON, '$.Q75.Q75'), '') AS B20
                FROM     dbo.DATA AS DA2 WITH (NOLOCK)
                WHERE  (PKEY = '2208008_B')
                UNION ALL
                SELECT  IDKEY, Status, SURVEY_TYPE, ISNULL(JSON_VALUE(DATJSON, '$.Q4.Q4'), '') AS B0, ISNULL(JSON_VALUE(DATJSON, '$.Q82.Q81'), '') AS B01_1, ISNULL(JSON_VALUE(DATJSON, 
                               '$.Q82.Q81'), '') AS B01_2, ISNULL(JSON_VALUE(DATJSON, '$.Q83.Q83'), '') AS B02, ISNULL(JSON_VALUE(DATJSON, '$.Q85.Q84'), '') AS B03_1, ISNULL(JSON_VALUE(DATJSON, 
                               '$.Q85.Q85'), '') AS B03_2, ISNULL(JSON_VALUE(DATJSON, '$.Q86.Q86'), '') AS B04, ISNULL(JSON_VALUE(DATJSON, '$.Q88.Q87'), '') AS B05_1, ISNULL(JSON_VALUE(DATJSON, 
                               '$.Q88.Q88'), '') AS B05_2, ISNULL(JSON_VALUE(DATJSON, '$.Q90.Q89'), '') AS B06_1, ISNULL(JSON_VALUE(DATJSON, '$.Q90.Q90'), '') AS B06_2, ISNULL(JSON_VALUE(DATJSON, 
                               '$.Q92.Q91'), '') AS B07_1, ISNULL(JSON_VALUE(DATJSON, '$.Q92.Q92'), '') AS B07_2, ISNULL(JSON_VALUE(DATJSON, '$.Q94.Q93'), '') AS B08_1, ISNULL(JSON_VALUE(DATJSON, 
                               '$.Q94.Q94'), '') AS B08_2, ISNULL(JSON_VALUE(DATJSON, '$.Q96.Q95'), '') AS B09_1, ISNULL(JSON_VALUE(DATJSON, '$.Q96.Q96'), '') AS B09_2, ISNULL(JSON_VALUE(DATJSON, 
                               '$.Q97.Q97'), '') AS B10, ISNULL(JSON_VALUE(DATJSON, '$.Q100.Q99'), '') AS B11_1, ISNULL(JSON_VALUE(DATJSON, '$.Q100.Q100'), '') AS B11_2, ISNULL(JSON_VALUE(DATJSON, 
                               '$.Q101.Q101'), '') AS B12, ISNULL(JSON_VALUE(DATJSON, '$.Q103.Q102'), '') AS B13_1, ISNULL(JSON_VALUE(DATJSON, '$.Q103.Q103'), '') AS B13_2, 
                               ISNULL(JSON_VALUE(DATJSON, '$.Q104.Q104'), '') AS B14, ISNULL(JSON_VALUE(DATJSON, '$.Q106.Q106'), '') AS B15, ISNULL(JSON_VALUE(DATJSON, '$.Q108.Q107'), '') 
                               AS B16_1, ISNULL(JSON_VALUE(DATJSON, '$.Q108.Q108'), '') AS B16_2, ISNULL(JSON_VALUE(DATJSON, '$.Q109.Q109'), '') AS B17, ISNULL(JSON_VALUE(DATJSON, 
                               '$.Q110.Q110'), '') AS B18, ISNULL(JSON_VALUE(DATJSON, '$.Q111.Q111'), '') AS B19, ISNULL(JSON_VALUE(DATJSON, '$.Q112.Q112'), '') AS B20
                FROM     dbo.DATA AS DA2 WITH (NOLOCK)
                WHERE  (PKEY = '2208008_B')) AS OUT_A
WHERE  (Status = '10')
go

exec sp_addextendedproperty 'MS_DiagramPane1', N'[0E232FF0-B466-11cf-A24F-00AA00A3EFFF, 1.00]
Begin DesignProperties = 
   Begin PaneConfigurations = 
      Begin PaneConfiguration = 0
         NumPanes = 4
         Configuration = "(H (1[40] 4[20] 2[20] 3) )"
      End
      Begin PaneConfiguration = 1
         NumPanes = 3
         Configuration = "(H (1 [50] 4 [25] 3))"
      End
      Begin PaneConfiguration = 2
         NumPanes = 3
         Configuration = "(H (1 [50] 2 [25] 3))"
      End
      Begin PaneConfiguration = 3
         NumPanes = 3
         Configuration = "(H (4 [30] 2 [40] 3))"
      End
      Begin PaneConfiguration = 4
         NumPanes = 2
         Configuration = "(H (1 [56] 3))"
      End
      Begin PaneConfiguration = 5
         NumPanes = 2
         Configuration = "(H (2 [66] 3))"
      End
      Begin PaneConfiguration = 6
         NumPanes = 2
         Configuration = "(H (4 [50] 3))"
      End
      Begin PaneConfiguration = 7
         NumPanes = 1
         Configuration = "(V (3))"
      End
      Begin PaneConfiguration = 8
         NumPanes = 3
         Configuration = "(H (1[56] 4[18] 2) )"
      End
      Begin PaneConfiguration = 9
         NumPanes = 2
         Configuration = "(H (1 [75] 4))"
      End
      Begin PaneConfiguration = 10
         NumPanes = 2
         Configuration = "(H (1[66] 2) )"
      End
      Begin PaneConfiguration = 11
         NumPanes = 2
         Configuration = "(H (4 [60] 2))"
      End
      Begin PaneConfiguration = 12
         NumPanes = 1
         Configuration = "(H (1) )"
      End
      Begin PaneConfiguration = 13
         NumPanes = 1
         Configuration = "(V (4))"
      End
      Begin PaneConfiguration = 14
         NumPanes = 1
         Configuration = "(V (2))"
      End
      ActivePaneConfig = 0
   End
   Begin DiagramPane = 
      Begin Origin = 
         Top = 0
         Left = 0
      End
      Begin Tables = 
         Begin Table = "OUT_A"
            Begin Extent = 
               Top = 6
               Left = 38
               Bottom = 136
               Right = 201
            End
            DisplayFlags = 280
            TopColumn = 0
         End
      End
   End
   Begin SQLPane = 
   End
   Begin DataPane = 
      Begin ParameterDefaults = ""
      End
   End
   Begin CriteriaPane = 
      Begin ColumnWidths = 11
         Column = 1440
         Alias = 900
         Table = 1170
         Output = 720
         Append = 1400
         NewValue = 1170
         SortType = 1350
         SortOrder = 1410
         GroupBy = 1350
         Filter = 1350
         Or = 1350
         Or = 1350
         Or = 1350
      End
   End
End
', 'SCHEMA', 'dbo', 'VIEW', 'V_BANG_APART_C'
go

exec sp_addextendedproperty 'MS_DiagramPaneCount', 1, 'SCHEMA', 'dbo', 'VIEW', 'V_BANG_APART_C'
go

