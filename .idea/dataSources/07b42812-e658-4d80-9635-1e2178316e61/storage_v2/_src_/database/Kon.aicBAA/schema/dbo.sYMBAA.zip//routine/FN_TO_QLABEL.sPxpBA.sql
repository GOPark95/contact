CREATE FUNCTION [dbo].[FN_TO_QLABEL] (
	@QID varchar(20),
	@PKEY varchar(30)
)
RETURNS VARCHAR(30)
AS 
BEGIN DECLARE
	@QLABEL VARCHAR(30)
	IF @QID = '' OR @PKEY = ''
		BEGIN 
			set @QLABEL = ''
		END 
	ELSE 
		BEGIN 
			select @QLABEL = (select JSON_VALUE(QUESTIONJSON, '$.variable') as variable  from QUESTION  where PKEY = @PKEY and QID = @QID )	
		END
	RETURN @QLABEL
END;
go

