CREATE PROCEDURE [dbo].[SP_2102013_REAL_allCase]
    @IN_PKEY varchar(20)      -- 프로젝트 ID
	, @IN_INDEX varchar(100) -- @index
AS 
BEGIN

declare 
 @json nvarchar(max) 
 ,@gender nvarchar(64) 
 ,@age nvarchar(64) 
 
SET NOCOUNT ON

-------Banner 변수-------
 set @gender = 'Q1' 
 set @age = 'Q2_1' 
 
------KON DATA JSON형태로 가져오기-------
 set @json=( select * 
 from ( 
 select IDKEY, Status,DAT 
 from ( 
 select IDKEY, DATJSON, Status, survey_date 
 from DATA with (nolock) 
 where PKEY = @IN_PKEY and Status='10' and SURVEY_TYPE = 'CAPI'
 ) IA CROSS APPLY( 
 select DISTINCT '{' + STUFF(( 
 SELECT ',' + SUBSTRING(value,2, LEN(value)-2) 
 FROM OPENJSON(IA.DATJSON) where [value] <> '{}' 
 FOR XML PATH('') 
 ),1,1,' ') + '}' AS DAT 
 ) DAT 
 ) a FOR JSON AUTO) 
 

--------테이블 집계(카운트)--------
 select 
 'case' as [index_value] 
 ,count([index]) as [index] -- index base 
 ,count([male]) as [male] -- banner1_1 base 
 ,count([female]) as [female] -- banner1_2 base 
 ,count([age_20]) as [age_20] -- banner1_2 base 
 ,count([age_30]) as [age_30] -- banner1_2 base 
 ,count([age_40]) as [age_40] -- banner1_2 base 
 ,count([age_50]) as [age_50] -- banner1_2 base 
 from( 
 select 
 JSON_VALUE(j_value,'$.'+@IN_INDEX) as [index] 
 ,case when JSON_VALUE(j_value,'$.'+@gender) = 1 then JSON_VALUE(j_value,'$.'+@gender) end as [male] 
 ,case when JSON_VALUE(j_value,'$.'+@gender) = 2 then JSON_VALUE(j_value,'$.'+@gender) end as [female] 
 ,case when JSON_VALUE(j_value,'$.'+@age) >=19 and JSON_VALUE(j_value,'$.'+@age) <30 then 20 end as [age_20] 
 ,case when JSON_VALUE(j_value,'$.'+@age) >29 and JSON_VALUE(j_value,'$.'+@age) <40 then 30 end as [age_30] 
 ,case when JSON_VALUE(j_value,'$.'+@age) >39 and JSON_VALUE(j_value,'$.'+@age) <50 then 40 end as [age_40]
 ,case when JSON_VALUE(j_value,'$.'+@age) >49 and JSON_VALUE(j_value,'$.'+@age) <60 then 50 end as [age_50]

 from( 
 select JSON_VALUE([value],'$.IDKEY') as idKey,JSON_VALUE([value],'$.DAT') as j_value from OPENJSON(@json) 
 ) in_a 
 where JSON_VALUE(j_value,'$.'+@IN_INDEX) is not null
 group by JSON_VALUE(j_value,'$.'+@IN_INDEX),j_value,idKey 
 )out_a 
 --FOR JSON AUTO 
 
 SET NOCOUNT OFF;  

END
go

