CREATE PROCEDURE [dbo].[SP_2102013_REAL_numeric]
    @IN_PKEY varchar(20)      -- 프로젝트 ID
	, @IN_INDEX varchar(100) -- @index
AS 
BEGIN

declare 
 @json nvarchar(max) 
 ,@gender nvarchar(64) 
 ,@age nvarchar(64) 
 
SET NOCOUNT ON
		
-------Banner 변수-------
 set @gender = 'Q1' 
 set @age = 'Q2_1' 
 
------KON DATA JSON형태로 가져오기-------
set @json=( select *
  from (
	select IDKEY, Status,DAT
	from (
		select IDKEY, DATJSON, Status, survey_date
		from DATA with (nolock)
		where PKEY = @IN_PKEY and Status='10' and SURVEY_TYPE = 'CAPI'
   ) IA CROSS APPLY(
     select DISTINCT '{' + STUFF((
         SELECT ',' + SUBSTRING(value,2, LEN(value)-2)
         FROM OPENJSON(IA.DATJSON) where [value] <> '{}'
         FOR XML PATH('')
     ),1,1,' ') + '}' AS DAT
) DAT
) a FOR JSON AUTO)
 

--------테이블 집계(SUM)--------
select
    'sum' as [index_value]
    ,isnull(sum(cast([index] as float)),0) as [index] -- index base
    ,isnull(sum(cast([male] as float)),0) as [male] -- banner1_1 base
    ,isnull(sum(cast([female] as float)),0) as [female] -- banner1_2 base
    ,isnull(sum(cast([age_20] as float)),0) as [age_20] -- banner1_2 base
    ,isnull(sum(cast([age_30] as float)),0) as [age_30] -- banner1_2 base
    ,isnull(sum(cast([age_40] as float)),0) as [age_40] -- banner1_2 base
	,isnull(sum(cast([age_50] as float)),0) as [age_50] -- banner1_2 base
    from(
        select
            JSON_VALUE(j_value,'$.'+@IN_INDEX) as [index]
            ,case when JSON_VALUE(j_value,'$.'+@gender) = 1 then JSON_VALUE(j_value,'$.'+@IN_INDEX) end as [male]
            ,case when JSON_VALUE(j_value,'$.'+@gender) = 2 then JSON_VALUE(j_value,'$.'+@IN_INDEX) end as [female]
            ,case when JSON_VALUE(j_value,'$.'+@age) >=19 and JSON_VALUE(j_value,'$.'+@age) <30 then JSON_VALUE(j_value,'$.'+@IN_INDEX) end as [age_20]
            ,case when JSON_VALUE(j_value,'$.'+@age) >29 and JSON_VALUE(j_value,'$.'+@age) <40 then JSON_VALUE(j_value,'$.'+@IN_INDEX) end as [age_30]
            ,case when JSON_VALUE(j_value,'$.'+@age) >39 and JSON_VALUE(j_value,'$.'+@age) <50 then JSON_VALUE(j_value,'$.'+@IN_INDEX) end as [age_40]
			,case when JSON_VALUE(j_value,'$.'+@age) >49 and JSON_VALUE(j_value,'$.'+@age) <60 then JSON_VALUE(j_value,'$.'+@IN_INDEX) end as [age_50]
        from(
          select JSON_VALUE([value],'$.IDKEY') as idKey,JSON_VALUE([value],'$.DAT') as j_value from OPENJSON(@json)
        ) in_a
		where JSON_VALUE(j_value,'$.'+@IN_INDEX) is not null
group by JSON_VALUE(j_value,'$.'+@IN_INDEX),j_value,idKey
)out_a

 --FOR JSON AUTO 
 
 SET NOCOUNT OFF;  

END
go

