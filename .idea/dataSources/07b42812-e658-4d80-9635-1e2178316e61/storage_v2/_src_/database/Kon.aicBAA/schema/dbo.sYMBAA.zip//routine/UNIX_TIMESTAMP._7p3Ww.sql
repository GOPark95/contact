






CREATE FUNCTION UNIX_TIMESTAMP (
@ctimestamp datetime
)
RETURNS varchar(20)
AS
BEGIN
  /* Function body */
  declare @return varchar(20)
   
  -- SELECT @return = DATEDIFF(SECOND,{d '1970-01-01'}, @ctimestamp)
  -- SELECT @return = RIGHT(CAST( DATEDIFF_BIG(ms, '1970-01-01 00:00:00', @ctimestamp) AS varchar(15) ),10)
  SELECT @return = replace(cast(CONVERT(CHAR(12), @ctimestamp, 114) as varchar(12)),':','')
   
  return @return
END
go

