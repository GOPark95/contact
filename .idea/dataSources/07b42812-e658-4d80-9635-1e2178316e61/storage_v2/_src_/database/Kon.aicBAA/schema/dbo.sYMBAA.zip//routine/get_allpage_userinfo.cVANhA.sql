CREATE PROCEDURE [dbo].[get_allpage_userinfo]
	-- 유저 모든 문항 정보 가져오기
	@PKEY varchar(30), -- 프로젝트 ID
	@IDKEY varchar(100) -- 응답자 ID
AS
BEGIN
	select 	
		QID, -- 문 ID
		Qorder, -- 순서
		isnull(qroot,QID) as qroot, -- 그룹문항일 경우 저장되는 key
		isnull(user_page,'n') as access_flag, -- 페이지 방문 여부
		isnull(user_data,'') as user_data, -- 페이지 데이터
		json_value(QUESTIONJSON,'$.variable') as variable, -- 문번
		json_value(QUESTIONJSON,'$.qtype') as qtype, -- 문항 타입
		json_value(QUESTIONJSON,'$.title') as title, -- 문항 타이틀
		json_value(QUESTIONJSON,'$.description') as description , -- 문항 안내문
		CASE WHEN LOGICJSON = '' THEN '' ELSE JSON_QUERY(LOGICJSON ,'$.p') END as plogic,  --문항 사전 로직
		CASE WHEN LOGICJSON = '' THEN '' ELSE JSON_QUERY(LOGICJSON ,'$.n') END as nlogic  -- 문항 사후 로직 
	from QUESTION as Qu
	CROSS APPLY ( select [value] from OPENJSON(QUESTIONJSON) where [key]= 'qgroup' )  RB
	OUTER APPLY ( 
		select qgroup, qroot from (
			select JSON_VALUE(QUESTIONJSON,'$.qgroup') as qgroup, max(Qorder) as qorder from QUESTION where PKEY = @PKEY and JSON_VALUE(QUESTIONJSON,'$.qgroup') <> '' group by JSON_VALUE(QUESTIONJSON,'$.qgroup')
		) A CROSS APPLY (
			select QID as qroot from QUESTION where PKEY = @PKEY and Qorder = A.qorder
		) B where RB.value = A.qgroup
	)  C
	OUTER APPLY (
		select [key] as user_page,[value] as user_data from [DATA] a	
		CROSS APPLY OPENJSON(a.DATJSON) b
		where pkey = @PKEY and idkey = @IDKEY and ISNULL(C.qroot, QID) = b.[key] collate Korean_Wansung_CI_AS
	) D  where PKEY = @PKEY order by Qorder FOR JSON PATH
END;
go

