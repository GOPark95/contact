CREATE PROCEDURE [dbo].[SP_KON_HOURLY_ACCESS]
	@targetDate as nvarchar(16) = ''
	,@limitCount as int = 0
AS
BEGIN
	if @targetDate=''
	begin
		set @targetDate = CONVERT(CHAR(10), GETDATE(), 23)
	end
	else
	begin
		set @targetDate = CONVERT(CHAR(10), @targetDate, 23)
	end

	select *
	from(
		select [DATA_PKEY]
			  ,sum([0]) as  [0]
			  ,sum([1]) as  [1]
			  ,sum([2]) as  [2]
			  ,sum([3]) as  [3]
			  ,sum([4]) as  [4]
			  ,sum([5]) as  [5]
			  ,sum([6]) as  [6]
			  ,sum([7]) as  [7]
			  ,sum([8]) as  [8]
			  ,sum([9]) as  [9]
			  ,sum([10]) as [10]
			  ,sum([11]) as [11]
			  ,sum([12]) as [12]
			  ,sum([13]) as [13]
			  ,sum([14]) as [14]
			  ,sum([15]) as [15]
			  ,sum([16]) as [16]
			  ,sum([17]) as [17]
			  ,sum([18]) as [18]
			  ,sum([19]) as [19]
			  ,sum([20]) as [20]
			  ,sum([21]) as [21]
			  ,sum([22]) as [22]
			  ,sum([23]) as [23]
			  ,sum(user_con) as user_con
		from
		(
		SELECT [DATA_PKEY]
			  ,case when logdate between @targetDate+' 00:00:00' and @targetDate+' 00:59:59.999' then 1 else 0 end as [0]
			  ,case when logdate between @targetDate+' 01:00:00' and @targetDate+' 01:59:59.999' then 1 else 0 end as [1]
			  ,case when logdate between @targetDate+' 02:00:00' and @targetDate+' 02:59:59.999' then 1 else 0 end as [2]
			  ,case when logdate between @targetDate+' 03:00:00' and @targetDate+' 03:59:59.999' then 1 else 0 end as [3]
			  ,case when logdate between @targetDate+' 04:00:00' and @targetDate+' 04:59:59.999' then 1 else 0 end as [4]
			  ,case when logdate between @targetDate+' 05:00:00' and @targetDate+' 05:59:59.999' then 1 else 0 end as [5]
			  ,case when logdate between @targetDate+' 06:00:00' and @targetDate+' 06:59:59.999' then 1 else 0 end as [6]
			  ,case when logdate between @targetDate+' 07:00:00' and @targetDate+' 07:59:59.999' then 1 else 0 end as [7]
			  ,case when logdate between @targetDate+' 08:00:00' and @targetDate+' 08:59:59.999' then 1 else 0 end as [8]
			  ,case when logdate between @targetDate+' 09:00:00' and @targetDate+' 09:59:59.999' then 1 else 0 end as [9]
			  ,case when logdate between @targetDate+' 10:00:00' and @targetDate+' 10:59:59.999' then 1 else 0 end as [10]
			  ,case when logdate between @targetDate+' 11:00:00' and @targetDate+' 11:59:59.999' then 1 else 0 end as [11]
			  ,case when logdate between @targetDate+' 12:00:00' and @targetDate+' 12:59:59.999' then 1 else 0 end as [12]
			  ,case when logdate between @targetDate+' 13:00:00' and @targetDate+' 13:59:59.999' then 1 else 0 end as [13]
			  ,case when logdate between @targetDate+' 14:00:00' and @targetDate+' 14:59:59.999' then 1 else 0 end as [14]
			  ,case when logdate between @targetDate+' 15:00:00' and @targetDate+' 15:59:59.999' then 1 else 0 end as [15]
			  ,case when logdate between @targetDate+' 16:00:00' and @targetDate+' 16:59:59.999' then 1 else 0 end as [16]
			  ,case when logdate between @targetDate+' 17:00:00' and @targetDate+' 17:59:59.999' then 1 else 0 end as [17]
			  ,case when logdate between @targetDate+' 18:00:00' and @targetDate+' 18:59:59.999' then 1 else 0 end as [18]
			  ,case when logdate between @targetDate+' 19:00:00' and @targetDate+' 19:59:59.999' then 1 else 0 end as [19]
			  ,case when logdate between @targetDate+' 20:00:00' and @targetDate+' 20:59:59.999' then 1 else 0 end as [20]
			  ,case when logdate between @targetDate+' 21:00:00' and @targetDate+' 21:59:59.999' then 1 else 0 end as [21]
			  ,case when logdate between @targetDate+' 22:00:00' and @targetDate+' 22:59:59.999' then 1 else 0 end as [22]
			  ,case when logdate between @targetDate+' 23:00:00' and @targetDate+' 23:59:59.999' then 1 else 0 end as [23]
			  ,count(1) as user_con
		  FROM [Kon].[dbo].[visit_log] with(nolock)
		  where logdate between @targetDate+' 00:00:00' and @targetDate+' 23:59:59.999' and [DATA_PKEY]<> '' and [DATA_IDKEY]<>''
		  and host = 'kon.kric.com' and referer not like '%ST=TEST%'
		  group by [DATA_PKEY],DATA_IDKEY,[ip],logdate
		) a
		  group by [DATA_PKEY]
	)b
	where user_con > @limitCount
END
go

