CREATE PROCEDURE dbo.SP_COL_DATA
    @PKEY varchar(20), -- 프로젝트 ID
	@IDKEY varchar(100) = '', -- 응답자 ID
	@QTYPE varchar(20) = 'REAL' -- 타입 TEST  REAL
AS 
BEGIN
	DECLARE @QUERY     NVARCHAR(MAX) = '',
            @COLS NVARCHAR(MAX) = ''
            
     SET NOCOUNT ON;
     
     IF OBJECT_ID('tempdb..##spColData_'+@PKEY) IS NOT NULL
     	SET @QUERY = ' DROP TABLE ##spColData_'+@PKEY
     	EXEC (@QUERY)
     	
	SELECT @COLS = STUFF((
		SELECT ',' + 'JSON_VALUE(DATJSON, ''$.' + CASE WHEN JSON_VALUE(Q.QUESTIONJSON, '$.qgroup') <> '' THEN T.QID ELSE P_QID COLLATE Korean_Wansung_CI_AS END + '.' + C_QID + ''') AS ' + C_QID
		FROM kon.dbo.QUESTION Q 
		CROSS APPLY (
			SELECT TOP 1 QID
			FROM kon.dbo.QUESTION
			WHERE PKEY = Q.PKEY AND JSON_VALUE(QUESTIONJSON, '$.qgroup') = JSON_VALUE(Q.QUESTIONJSON, '$.qgroup')
			ORDER BY Qorder DESC
		) T
		LEFT JOIN (
			SELECT S.PKEY, CONVERT(varchar(5), B.[key]) AS P_QID, CONVERT(varchar(20), C.value) AS C_QID
			FROM kon.dbo.[STRUCTURE] S
			CROSS APPLY OPENJSON(QINFO) B
			CROSS APPLY OPENJSON(B.value) C
			WHERE S.PKEY != '2009017_A'
		) H ON H.PKEY = Q.PKEY AND H.P_QID COLLATE Korean_Wansung_CI_AS = Q.QID
		WHERE H.PKEY = @PKEY
		ORDER BY Q.Qorder
		FOR XML PATH('')
	), 1, 1, '')
	
    SET @QUERY = ' SELECT IDKEY, '
    SET @QUERY += @COLS
	SET @QUERY += ' , (SELECT max(value) FROM OPENJSON(survey_date)) as survey_date INTO ##spColData_' + @PKEY + ' '		
	SET @QUERY += ' FROM  dbo.DATA with(nolock) '
	SET @QUERY += ' WHERE PKEY = ''' + @PKEY +'''  AND Status = 10 '
	IF @QTYPE = 'TEST'
	BEGIN
		SET @QUERY += ' AND SURVEY_TYPE = ''TEST'' '
	END
	IF @QTYPE = 'REAL'
	BEGIN
		SET @QUERY += ' AND SURVEY_TYPE <> ''TEST'' '
	END
	IF @IDKEY <> ''
	BEGIN
		SET @QUERY += ' AND IDKEY = ''' + @IDKEY + ''' '
	END 
   
	EXEC (@QUERY)
END;

go

