CREATE PROCEDURE [dbo].[userdata_with_label]
	-- 프로젝트 응답자 데이터 라벨과 함께 가져오기
	-- exec [dbo].[userdata_with_label] '2002021_A','Q3, Q14, Q15, Q18, Q21, Q22','Q12_1, Q13_1, Q4_1, Q8_1, Q8_2, Q10_1, Q10_2, Q11_1, Q20_1'
	@PKEY varchar(20), -- 프로젝트 ID
	@SINGLEQA varchar(200), -- 단수 문항 QARR
	@OPENQA varchar(200) -- 오픈 문항 QARR
AS
BEGIN
	 
	 DECLARE @SQL_COMMAND NVARCHAR(MAX)
	 
	 SET @SQL_COMMAND = ' DECLARE @json NVARCHAR(MAX) '
	 SET @SQL_COMMAND = @SQL_COMMAND + ' set @json = (SELECT LINFO from kon.dbo.[STRUCTURE] with(nolock) where PKEY = @PKEY  )  '
	 SET @SQL_COMMAND = @SQL_COMMAND + ' set @json = ( select DISTINCT ''{'' + STUFF((  '
	 SET @SQL_COMMAND = @SQL_COMMAND + ' SELECT '','' + SUBSTRING(value,2, LEN(value)-2) '
	 SET @SQL_COMMAND = @SQL_COMMAND + ' FROM OPENJSON(@json) where [key] in ( select VAL1 collate Korean_Wansung_CI_AS from [dbo].[FN_SPLIT](@SINGLEQA,'','') ) '
	 SET @SQL_COMMAND = @SQL_COMMAND + ' FOR XML PATH('''') '
	 SET @SQL_COMMAND = @SQL_COMMAND + ' ),1,1,'' '') + ''}'' ) '

	 IF @SINGLEQA <> ''
	 	BEGIN 
	 		SET @SINGLEQA = REPLACE(@SINGLEQA,' ','')
	 	END
 	IF @OPENQA <> ''
	 	BEGIN 
	 		SET @OPENQA = REPLACE(@OPENQA,' ','')
	 	END
					 
	 SET @SQL_COMMAND = @SQL_COMMAND + ' select IDKEY '
	 IF @SINGLEQA <> ''
	 	BEGIN
			SET @SQL_COMMAND = @SQL_COMMAND + ',' + @SINGLEQA + ',' + REPLACE(@SINGLEQA,'Q','LQ')
		END
	IF @OPENQA <> ''
	 	BEGIN
			SET @SQL_COMMAND = @SQL_COMMAND + ','  + @OPENQA
		END
	SET @SQL_COMMAND = @SQL_COMMAND + ' from ( '
	SET @SQL_COMMAND = @SQL_COMMAND + ' select IDKEY '
	IF @SINGLEQA <> ''	 	 
		BEGIN
		SET @SQL_COMMAND = @SQL_COMMAND + ',' + ( select STRING_AGG(VAL1, ', ') as STR
			from (
				select 'a' as grp, ('ISNULL(JSON_VALUE(DATJSON,''$.'+ VAL1 + '.' + VAL1 +'''),'''') as ' + VAL1) as VAL1
				from [dbo].[FN_SPLIT](@SINGLEQA,',')
			) as b group by grp )
		END		
	IF @OPENQA <> ''
	 	BEGIN
			SET @SQL_COMMAND = @SQL_COMMAND + ',' + ( select STRING_AGG(VAL1, ', ') as STR
				from (
					select 'a' as grp, ('JSON_VALUE(DATJSON,''$.'+ LEFT(VAL1,CHARINDEX('_',VAL1)-1) + '.' + VAL1 +''') as ' + VAL1) as VAL1
					from [dbo].[FN_SPLIT](@OPENQA,',')
				) as b group by grp )
		END
	SET @SQL_COMMAND = @SQL_COMMAND + ' from [DATA] where pkey = @PKEY and Status= ''10'' and SURVEY_TYPE <> ''TEST''  '
	
	SET @SQL_COMMAND = @SQL_COMMAND + ' )  as  RB '
	
	IF @SINGLEQA <> ''
	 	BEGIN
			SET @SQL_COMMAND = @SQL_COMMAND + ' CROSS APPLY( '
			SET @SQL_COMMAND = @SQL_COMMAND + ' select ' + ( select STRING_AGG(VAL1, ', ') as STR
				from (
					select 'a' as grp, ('JSON_VALUE(@json,''$.'+VAL1+'."''+[RB].['+ VAL1 + ']+''"'') as L' + VAL1) as VAL1
					from [dbo].[FN_SPLIT](@SINGLEQA,',')
				) as b group by grp )
				
			SET @SQL_COMMAND = @SQL_COMMAND + ' ) CA1 '		
		END

	EXECUTE sp_executesql @SQL_COMMAND, 
				N'@PKEY varchar(20), @SINGLEQA varchar(200)',
	  			@PKEY = @PKEY, @SINGLEQA = @SINGLEQA;
END;
go

