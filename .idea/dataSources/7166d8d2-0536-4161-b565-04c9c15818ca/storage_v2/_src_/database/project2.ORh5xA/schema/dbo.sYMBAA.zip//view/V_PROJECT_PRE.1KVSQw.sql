
CREATE VIEW [dbo].[V_PROJECT_PRE]
AS
SELECT  id, '' AS p_sn_tmp, p_sn, p_subject_pre, '' AS p_content_tmp, '' AS p_depart, '' AS p_depart_dep, 
               '' AS p_depart_team, '' AS p_cli_company, '' AS p_cli_depart, '' AS p_cp_code, p_contact_people, '' AS p_cli_type, 
               '' AS p_cli_class, '' AS p_contactor, CONVERT(VARCHAR(10), p_contact_date, 120) AS p_contact_date, 
               p_contact_place, '' AS p_contact_content, '' AS p_prop_date, '' AS p_upload_date, '' AS p_types1, '' AS p_types2, 
               '' AS p_types3, '' AS p_method1, '' AS p_method2, '' AS p_method3, '' AS p_intention, p_contact_discuss, 
               '' AS p_regok, '' AS p_delok, '' AS p_del_rcompany, '' AS p_del_cprice, '' AS p_del_cprice_chk, 
               '' AS p_del_krcprice, '' AS p_del_reason1, '' AS p_del_reason2, '' AS p_del_cplan, '' AS p_del_user, 
               '' AS p_del_usersn, '' AS p_del_date, p_input_dt, p_input_user, '' AS p_input_user_name, '' AS p_input_user_ip, 
               '' AS p_sample, '' AS p_dept_rsh, '' AS p_dept_field, '' AS p_dept_it, '' AS p_dept_admin, p_contact_date_time, 
               p_contact_schedule, p_contact_people_krc, p_contact_people_cli, Attribute01, Attribute02, Attribute03, 
               Attribute04, list_view_yn
FROM     T_PROJECT_PRE where list_del='Y'
UNION ALL
SELECT  p_sn AS id, p_sn_tmp, sn AS p_sn, p_subject_tmp AS p_subject_pre, p_content_tmp, p_depart, p_depart_dep, 
               p_depart_team, p_cli_company, p_cli_depart, p_cp_code, p_cli_name AS p_contact_people, p_cli_type, 
               p_cli_class, p_contactor, p_contact_date AS p_contact_date, p_contact_place, p_contact_content, p_prop_date, 
               p_upload_date, p_types1, p_types2, p_types3, p_method1, p_method2, p_method3, p_intention, 
               p_memo AS p_contact_discuss, p_regok, p_delok, p_del_rcompany, p_del_cprice, p_del_cprice_chk, 
               p_del_krcprice, p_del_reason1, p_del_reason2, p_del_cplan, p_del_user, p_del_usersn, p_del_date, 
               write_date AS p_input_dt, p_input_user_no AS p_input_user, p_input_user_name, p_input_user_ip, p_sample, 
               p_dept_rsh, p_dept_field, p_dept_it, p_dept_admin, '' AS p_contact_date_time, '' AS p_contact_schedule, 
               '' AS p_contact_people_krc, '' AS p_contact_people_cli, '' AS Attribute01, '' AS Attribute02, '' AS Attribute03, 
               '' AS Attribute04, '' as list_view_yn
FROM     project2_pre

go

exec sp_addextendedproperty 'MS_DiagramPane1', N'[0E232FF0-B466-11cf-A24F-00AA00A3EFFF, 1.00]
Begin DesignProperties = 
   Begin PaneConfigurations = 
      Begin PaneConfiguration = 0
         NumPanes = 4
         Configuration = "(H (1[40] 4[20] 2[20] 3) )"
      End
      Begin PaneConfiguration = 1
         NumPanes = 3
         Configuration = "(H (1 [50] 4 [25] 3))"
      End
      Begin PaneConfiguration = 2
         NumPanes = 3
         Configuration = "(H (1 [50] 2 [25] 3))"
      End
      Begin PaneConfiguration = 3
         NumPanes = 3
         Configuration = "(H (4 [30] 2 [40] 3))"
      End
      Begin PaneConfiguration = 4
         NumPanes = 2
         Configuration = "(H (1 [56] 3))"
      End
      Begin PaneConfiguration = 5
         NumPanes = 2
         Configuration = "(H (2 [66] 3))"
      End
      Begin PaneConfiguration = 6
         NumPanes = 2
         Configuration = "(H (4 [50] 3))"
      End
      Begin PaneConfiguration = 7
         NumPanes = 1
         Configuration = "(V (3))"
      End
      Begin PaneConfiguration = 8
         NumPanes = 3
         Configuration = "(H (1[56] 4[18] 2) )"
      End
      Begin PaneConfiguration = 9
         NumPanes = 2
         Configuration = "(H (1 [75] 4))"
      End
      Begin PaneConfiguration = 10
         NumPanes = 2
         Configuration = "(H (1[66] 2) )"
      End
      Begin PaneConfiguration = 11
         NumPanes = 2
         Configuration = "(H (4 [60] 2))"
      End
      Begin PaneConfiguration = 12
         NumPanes = 1
         Configuration = "(H (1) )"
      End
      Begin PaneConfiguration = 13
         NumPanes = 1
         Configuration = "(V (4))"
      End
      Begin PaneConfiguration = 14
         NumPanes = 1
         Configuration = "(V (2))"
      End
      ActivePaneConfig = 0
   End
   Begin DiagramPane = 
      Begin Origin = 
         Top = 0
         Left = 0
      End
      Begin Tables = 
      End
   End
   Begin SQLPane = 
   End
   Begin DataPane = 
      Begin ParameterDefaults = ""
      End
   End
   Begin CriteriaPane = 
      Begin ColumnWidths = 11
         Column = 1440
         Alias = 900
         Table = 1170
         Output = 720
         Append = 1400
         NewValue = 1170
         SortType = 1350
         SortOrder = 1410
         GroupBy = 1350
         Filter = 1350
         Or = 1350
         Or = 1350
         Or = 1350
      End
   End
End
', 'SCHEMA', 'dbo', 'VIEW', 'V_PROJECT_PRE'
go

exec sp_addextendedproperty 'MS_DiagramPaneCount', 1, 'SCHEMA', 'dbo', 'VIEW', 'V_PROJECT_PRE'
go

