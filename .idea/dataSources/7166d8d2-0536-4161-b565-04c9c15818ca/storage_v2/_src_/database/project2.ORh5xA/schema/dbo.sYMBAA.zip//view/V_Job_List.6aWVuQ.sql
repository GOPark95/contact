
CREATE VIEW V_Job_List AS 
SELECT p_no, j_date, j_p_sn, j_contents, '' AS j_contents_nm, j_time, j_write_date, j_ip, j_approval 
FROM Job_List 
WHERE j_flag = '1'
UNION ALL
SELECT 	j_p_no , j_date, CASE WHEN LEFT(j_p_sn, 4) = '9999' THEN '99999' ELSE j_p_sn END AS j_p_sn, j_detail_code, j_detail2,
			ROUND((j_time_block_end_code+1 - CASE WHEN j_time_block_st_code = 0 THEN -1 ELSE j_time_block_st_code END) * 0.5, 0) AS j_time,
			j_write_date, j_ip, (SELECT TOP 1 d_no FROM cost_account WHERE job_date = J.j_date AND user_code = J.j_p_no) AS j_approval 
FROM Job J
WHERE j_date > '2019-01-01' AND j_p_sn <> '99998'



go

