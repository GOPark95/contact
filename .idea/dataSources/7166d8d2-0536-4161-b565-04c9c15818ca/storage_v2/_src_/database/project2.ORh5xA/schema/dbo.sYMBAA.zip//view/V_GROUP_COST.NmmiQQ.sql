-- dbo.V_GROUP_COST source

CREATE VIEW V_GROUP_COST AS 
SELECT d_no, hangmok, depart_cd, p_job_part, depart, gubun, project2.dbo.Split(rawdata, '^^', 1) AS cost_date, 
			CONVERT(money, replace(project2.dbo.Split(rawdata, '^^', 4), ' ', '')) AS cost, project2.dbo.Split(rawdata, '^^', 3) AS contents, write_name , p_no 
FROM
(
	SELECT 		문서번호 AS d_no, CONVERT(varchar(1000), target1) AS target1, CONVERT(varchar(1000), target2) AS target2, CONVERT(varchar(1000), target3) AS target3,
					CONVERT(varchar(1000), target4) AS target4, CONVERT(varchar(1000), target5) AS target5, CONVERT(varchar(1000), target6) AS target6,
					CONVERT(varchar(1000), target7) AS target7, CONVERT(varchar(1000), target8) AS target8, CONVERT(varchar(1000), target9) AS target9,
					CONVERT(varchar(1000), target10) AS target10, CONVERT(varchar(1000), target11) AS target11, CONVERT(varchar(1000), target12) AS target12,
					CONVERT(varchar(1000), target13) AS target13, CONVERT(varchar(1000), target14) AS target14,
					CONVERT(varchar(100), target21) AS depart_cd,
					(SELECT TOP 1 p_job_part FROM project2.dbo.person WHERE p_no = login_p_no) AS p_job_part,
					CASE WHEN CONVERT(varchar(100), target21) = '0' THEN  
						login_이름
					ELSE 
						CASE WHEN CONVERT(varchar(100), target21) = '18' THEN
							CASE WHEN (SELECT TOP 1 p_job_part FROM project2.dbo.person WHERE p_no = login_p_no) = '08' THEN
								'개발그룹'
							ELSE
								'경영문화본부'
							END
						ELSE
							(SELECT TOP 1 CASE WHEN LEFT(T_Name, 2) = '자료' THEN '데이터이노베이션' ELSE T_Name END FROM project2.dbo.v_Department WHERE before_t_cd1 = CONVERT(varchar(100), target21))
						END
					END AS depart,
					CASE WHEN CONVERT(varchar(10), target20) = '장' THEN
						'그룹장활동비'	
					ELSE
						'그룹활동비'
					END AS gubun,
					login_이름 AS write_name,
					login_p_no AS p_no
	FROM project2.dbo.문서내용 
	WHERE 문서제목='부서비신청서' AND del_yes_no = 'no' 
	AND  문서번호 > 'KRC-2019-w'
) AS columnTable 
UNPIVOT 
(	
	rawdata FOR hangmok IN (	
		target1, target2, target3, target4, target5, target6, target7,
		target8, target9, target10, target11, target12, target13, target14 
	)	
) AS rowTable 
WHERE rawdata <> '';
go

