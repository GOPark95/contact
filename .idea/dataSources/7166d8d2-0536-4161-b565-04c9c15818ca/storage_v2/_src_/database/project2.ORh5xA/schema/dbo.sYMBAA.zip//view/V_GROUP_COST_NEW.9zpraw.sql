CREATE VIEW dbo.V_GROUP_COST_NEW
AS
SELECT  d_no, hangmok
,CASE WHEN p_no='20151203' THEN '0' ELSE depart_cd END AS depart_cd
,CASE WHEN p_no='20151203' THEN '01' ELSE p_job_part END AS p_job_part
,CASE WHEN p_no='20151203' THEN 'E101' ELSE d_code END AS d_code
,CASE WHEN p_no='20151203' THEN '최정심' ELSE isnull(depart, '') END AS depart
, gubun, project2.dbo.Split(rawdata, '^^', 1) AS cost_date/*, '' as txt_pjt*/ , project2.dbo.Split(rawdata, '^^', 7) AS txt_pjt, 
               project2.dbo.Split(rawdata, '^^', 3) AS txt_hangmok/*, '' as contents*/ , project2.dbo.Split(rawdata, '^^', 8) AS contents, CONVERT(money, replace(project2.dbo.Split(rawdata, '^^', 4), ' ', '')) 
               AS cost, write_name, p_no
FROM     (SELECT  문서번호 AS d_no, CONVERT(varchar(1000), target1) AS target1, CONVERT(varchar(1000), target2) AS target2, CONVERT(varchar(1000), target3) AS target3, CONVERT(varchar(1000), 
                               target4) AS target4, CONVERT(varchar(1000), target5) AS target5, CONVERT(varchar(1000), target6) AS target6, CONVERT(varchar(1000), target7) AS target7, CONVERT(varchar(1000), 
                               target8) AS target8, CONVERT(varchar(1000), target9) AS target9, CONVERT(varchar(1000), target10) AS target10, CONVERT(varchar(1000), target11) AS target11, 
                               CONVERT(varchar(1000), target12) AS target12, CONVERT(varchar(1000), target13) AS target13, CONVERT(varchar(1000), target14) AS target14, CONVERT(varchar(100), target21) 
                               AS depart_cd,
                                   (SELECT  TOP 1 p_job_part
                                    FROM     project2.dbo.person
                                    WHERE  p_no = login_p_no) AS p_job_part, CASE WHEN CONVERT(varchar(100), target21) = '0' THEN login_이름 ELSE CASE WHEN CONVERT(varchar(100), target21) 
                               = '18' THEN CASE WHEN
                                   (SELECT  TOP 1 p_job_part
                                    FROM     project2.dbo.person
                                    WHERE  p_no = login_p_no) = '08' THEN '개발그룹' ELSE '경영문화본부' END ELSE
                                   (SELECT  TOP 1 CASE WHEN LEFT(T_Name, 2) = '자료' THEN '데이터이노베이션' ELSE T_Name END
                                    FROM     project2.dbo.v_Department
                                    WHERE  before_t_cd1 = CONVERT(varchar(100), target21)) END END AS depart,
                                   (SELECT  TOP 1 Code
                                    FROM     project2.dbo.v_Department
                                    WHERE  before_t_cd1 = CONVERT(varchar(100), target21) AND before_j_cd2 <> CASE WHEN CONVERT(varchar(100), target21) = '18' AND
                                                       (SELECT  TOP 1 p_job_part
                                                        FROM     project2.dbo.person
                                                        WHERE  p_no = login_p_no) <> '08' THEN '08' ELSE '99' END) AS d_code, '그룹운영비' AS gubun, login_이름 AS write_name, login_p_no AS p_no
                FROM     project2.dbo.문서내용
                WHERE  문서제목 = '부서비신청서' AND del_yes_no = 'no' AND 문서번호 > 'KRC-2022-w') AS columnTable UNPIVOT (rawdata FOR hangmok IN (target1, target2, target3, target4, target5, 
               target6, target7, target8, target9, target10, target11, target12, target13, target14)) AS rowTable
WHERE  rawdata <> '';
go

exec sp_addextendedproperty 'MS_DiagramPane1', N'[0E232FF0-B466-11cf-A24F-00AA00A3EFFF, 1.00]
Begin DesignProperties = 
   Begin PaneConfigurations = 
      Begin PaneConfiguration = 0
         NumPanes = 4
         Configuration = "(H (1[40] 4[20] 2[20] 3) )"
      End
      Begin PaneConfiguration = 1
         NumPanes = 3
         Configuration = "(H (1 [50] 4 [25] 3))"
      End
      Begin PaneConfiguration = 2
         NumPanes = 3
         Configuration = "(H (1 [50] 2 [25] 3))"
      End
      Begin PaneConfiguration = 3
         NumPanes = 3
         Configuration = "(H (4 [30] 2 [40] 3))"
      End
      Begin PaneConfiguration = 4
         NumPanes = 2
         Configuration = "(H (1 [56] 3))"
      End
      Begin PaneConfiguration = 5
         NumPanes = 2
         Configuration = "(H (2 [66] 3))"
      End
      Begin PaneConfiguration = 6
         NumPanes = 2
         Configuration = "(H (4 [50] 3))"
      End
      Begin PaneConfiguration = 7
         NumPanes = 1
         Configuration = "(V (3))"
      End
      Begin PaneConfiguration = 8
         NumPanes = 3
         Configuration = "(H (1[56] 4[18] 2) )"
      End
      Begin PaneConfiguration = 9
         NumPanes = 2
         Configuration = "(H (1 [75] 4))"
      End
      Begin PaneConfiguration = 10
         NumPanes = 2
         Configuration = "(H (1[66] 2) )"
      End
      Begin PaneConfiguration = 11
         NumPanes = 2
         Configuration = "(H (4 [60] 2))"
      End
      Begin PaneConfiguration = 12
         NumPanes = 1
         Configuration = "(H (1) )"
      End
      Begin PaneConfiguration = 13
         NumPanes = 1
         Configuration = "(V (4))"
      End
      Begin PaneConfiguration = 14
         NumPanes = 1
         Configuration = "(V (2))"
      End
      ActivePaneConfig = 0
   End
   Begin DiagramPane = 
      Begin Origin = 
         Top = 0
         Left = 0
      End
      Begin Tables = 
      End
   End
   Begin SQLPane = 
   End
   Begin DataPane = 
      Begin ParameterDefaults = ""
      End
   End
   Begin CriteriaPane = 
      Begin ColumnWidths = 11
         Column = 1440
         Alias = 900
         Table = 1170
         Output = 720
         Append = 1400
         NewValue = 1170
         SortType = 1350
         SortOrder = 1410
         GroupBy = 1350
         Filter = 1350
         Or = 1350
         Or = 1350
         Or = 1350
      End
   End
End
', 'SCHEMA', 'dbo', 'VIEW', 'V_GROUP_COST_NEW'
go

exec sp_addextendedproperty 'MS_DiagramPaneCount', 1, 'SCHEMA', 'dbo', 'VIEW', 'V_GROUP_COST_NEW'
go

