







CREATE view [dbo].[V_punching_project]

as 

-- FCS(펀칭) 등록 프로젝트 가져오기(FCS 검증사이트와 동일하게 수정함 - 20171130) 
select AA.p_child_sn as pu_code, AA.p_subject as pu_subject, AA.p_method_nm from 
(
	select 
	p_sn, p_child_sn, p_subject, p_method_cd, p_method_nm, allocation_cnt, depcol_cnt, 
	collection_cnt, escalation_cnt, error_cnt, complete_cnt, 
	case when complete_cnt = 0 then 0.00 else 
	case when escalation_cnt = 0 then 0.00 else round(convert(float, complete_cnt)/escalation_cnt * 100, 2) end end as tok_rating, 
	case when error_cnt = 0 then 0.00 else case when escalation_cnt = 0 then 0.00 else round(convert(float, error_cnt)/escalation_cnt * 100, 2) end 
	end as error_rating, p_progress from 
	(
		select tpm.p_sn, tpm.p_child_sn, tpm.p_subject, tpm.p_method_cd, tpc.p_method_nm, 
		isnull(al.allocation_cnt,0) as allocation_cnt, isnull(de.depcol_cnt,0) as depcol_cnt, 
		isnull(co.collection_cnt,0) as collection_cnt, isnull(al.escalation_cnt,0) as escalation_cnt, 
		isnull(al.error_cnt,0) as error_cnt, isnull(al.complete_cnt,0) as complete_cnt, case when isnull(tpm.p_qc_complete,'3') = '3' then 
		case when al.allocation_cnt > 0 then '2' else '3' end else '1' end as p_progress 
		from V_PROJECT_FCS_LIST tpm 
		left join t_project_method_cd tpc on tpm.p_method_cd = tpc.p_method_cd 
		left join 
		(
			select intranet_project, sum(q_allocation) as allocation_cnt, 
			sum(q_escalation) as escalation_cnt, sum(q_error) as error_cnt, sum(q_complete) as complete_cnt 
			from T_QUOTA_TABLE group by intranet_project 
		) al on tpm.p_child_sn = al.intranet_project 
		left join 
		(
			select p_child_sn, SUM(depcol_cnt) as depcol_cnt, use_yn, dep_col from T_DEPCOL 
			group by p_child_sn, use_yn, dep_col
		) de on tpm.p_child_sn = de.p_child_sn and de.use_yn='y' and de.dep_col='deploy' 
		left join 
		(
			select p_child_sn, SUM(collection_cnt) as collection_cnt, use_yn from T_COLLECTION group by p_child_sn, use_yn 
		) co 
		on tpm.p_child_sn = co.p_child_sn and co.use_yn='y' 
		--where tpm.p_progress_status >= '008' and tpm.p_field_complete is null
		where tpm.p_progress_status >= '008'
	) s 
) AA
union all 
select '1111111_C11_1' as pu_code, '정보분석팀_수행계획서 미결재 프로젝트 펀치 셋팅전용' as pu_subject,'개별면접(F2F)' as p_method_nm



go

grant select on V_punching_project to punching_user
go

