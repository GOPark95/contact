

CREATE VIEW [dbo].[V_PROJECT_FCS_LIST]
AS
SELECT  p_index, p_method_cd, p_sn, intranet_project, p_client_type_cd, p_sub_type, p_child_sn, p_subject, p_intention, 
               p_con_date_st, p_con_date_end, p_decide_date, p_cont_cost, p_export_range, p_category, p_sur_area, 
               p_sur_target, p_sample, p_inspection_rate, p_research_date_st, p_research_date_end, p_sur_part, 
               p_field_process, p_rsch_dept, p_field_dept, p_is_dept, p_supp_dept, p_rsch_1_a, p_rsch_2_a, p_rsch_3_a, 
               p_rsch_4_a, p_rsch_1_b, p_rsch_2_b, p_rsch_3_b, p_rsch_4_b, p_rsch_1_c, p_rsch_2_c, p_rsch_3_c, 
               p_rsch_4_c, p_sv_1, p_sv_2, p_sv_3, p_sv_4, p_code_1, p_code_2, p_code_3, p_code_4, p_verify_1, 
               p_verify_2, p_verify_3, p_verify_4, p_dp_1, p_dp_2, p_dp_3, p_dp_4, p_it_1, p_it_2, p_it_3, p_it_4, p_supp_1, 
               p_supp_2, p_supp_3, p_supp_4, p_rsch_date_st, p_rsch_date_end, p_field_date_st, p_field_date_end, 
               p_code_date_st, p_code_date_end, p_verify_date_st, p_verify_date_end, p_dp_date_st, p_dp_date_end, 
               p_it_date_st, p_it_date_end, p_premeet_date, p_premeet_time, p_premeet_place, p_ot_date, p_ot_time, 
               p_ot_place, p_sur_memo, p_memo, p_progress_status, p_input_dt, p_input_complete, p_research_complete, 
               p_field_complete, p_dp_complete, p_support_complete, p_field_complete_date, p_statistics, 
               p_qc_complete
FROM     dbo.V_PROJECT_FCS
/*##### 2018-12 이전
WHERE  (p_progress_status = '008') AND (p_field_complete IS NULL) AND (intranet_project <> '') OR
               (p_progress_status = '008') AND (p_field_complete IS NULL) AND (p_child_sn IN
                   (SELECT  p_sn
                    FROM     dbo.T_QC_CONFIG
                    WHERE  (p_sn IN
                                       (SELECT  p_child_sn
                                        FROM     dbo.T_PROJECT_METHOD
                                        WHERE  (p_progress_status = '008') AND (p_field_complete IS NULL)))
                    GROUP BY p_sn))
*/--##### 2018-12 이후
WHERE  (p_progress_status = '008') AND (intranet_project <> '') OR
               (p_progress_status = '008') AND (p_child_sn IN
                   (SELECT  p_sn
                    FROM     dbo.T_QC_CONFIG
                    WHERE  (p_sn IN
                                       (SELECT  p_child_sn
                                        FROM     dbo.T_PROJECT_METHOD
                                        WHERE  (p_progress_status = '008') ))
                    GROUP BY p_sn))

go

exec sp_addextendedproperty 'MS_DiagramPane1', N'[0E232FF0-B466-11cf-A24F-00AA00A3EFFF, 1.00]
Begin DesignProperties = 
   Begin PaneConfigurations = 
      Begin PaneConfiguration = 0
         NumPanes = 4
         Configuration = "(H (1[40] 4[20] 2[20] 3) )"
      End
      Begin PaneConfiguration = 1
         NumPanes = 3
         Configuration = "(H (1 [50] 4 [25] 3))"
      End
      Begin PaneConfiguration = 2
         NumPanes = 3
         Configuration = "(H (1 [50] 2 [25] 3))"
      End
      Begin PaneConfiguration = 3
         NumPanes = 3
         Configuration = "(H (4 [30] 2 [40] 3))"
      End
      Begin PaneConfiguration = 4
         NumPanes = 2
         Configuration = "(H (1 [56] 3))"
      End
      Begin PaneConfiguration = 5
         NumPanes = 2
         Configuration = "(H (2 [66] 3))"
      End
      Begin PaneConfiguration = 6
         NumPanes = 2
         Configuration = "(H (4 [50] 3))"
      End
      Begin PaneConfiguration = 7
         NumPanes = 1
         Configuration = "(V (3))"
      End
      Begin PaneConfiguration = 8
         NumPanes = 3
         Configuration = "(H (1[56] 4[18] 2) )"
      End
      Begin PaneConfiguration = 9
         NumPanes = 2
         Configuration = "(H (1 [75] 4))"
      End
      Begin PaneConfiguration = 10
         NumPanes = 2
         Configuration = "(H (1[66] 2) )"
      End
      Begin PaneConfiguration = 11
         NumPanes = 2
         Configuration = "(H (4 [60] 2))"
      End
      Begin PaneConfiguration = 12
         NumPanes = 1
         Configuration = "(H (1) )"
      End
      Begin PaneConfiguration = 13
         NumPanes = 1
         Configuration = "(V (4))"
      End
      Begin PaneConfiguration = 14
         NumPanes = 1
         Configuration = "(V (2))"
      End
      ActivePaneConfig = 0
   End
   Begin DiagramPane = 
      Begin Origin = 
         Top = 0
         Left = 0
      End
      Begin Tables = 
         Begin Table = "V_PROJECT_FCS"
            Begin Extent = 
               Top = 6
               Left = 38
               Bottom = 135
               Right = 245
            End
            DisplayFlags = 280
            TopColumn = 0
         End
      End
   End
   Begin SQLPane = 
   End
   Begin DataPane = 
      Begin ParameterDefaults = ""
      End
   End
   Begin CriteriaPane = 
      Begin ColumnWidths = 11
         Column = 1440
         Alias = 900
         Table = 1170
         Output = 720
         Append = 1400
         NewValue = 1170
         SortType = 1350
         SortOrder = 1410
         GroupBy = 1350
         Filter = 1350
         Or = 1350
         Or = 1350
         Or = 1350
      End
   End
End
', 'SCHEMA', 'dbo', 'VIEW', 'V_PROJECT_FCS_LIST'
go

exec sp_addextendedproperty 'MS_DiagramPaneCount', 1, 'SCHEMA', 'dbo', 'VIEW', 'V_PROJECT_FCS_LIST'
go

