CREATE VIEW dbo.V_LOGIN_AUTH AS 
SELECT p_name, p_ip, p_user_mail FROM project2.dbo.V_Person 
WHERE (p_resign='0' AND p_depart_now + p_team_now IN ('S401', 'M101', 'M201'))
OR p_no IN (20080101, 20200302, 20190301, 20190108)
go

