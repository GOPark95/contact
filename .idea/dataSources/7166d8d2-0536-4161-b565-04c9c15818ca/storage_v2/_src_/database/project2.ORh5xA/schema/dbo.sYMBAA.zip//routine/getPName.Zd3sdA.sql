CREATE FUNCTION dbo.getPName(@p_no int)
RETURNS varchar(20)
AS 
BEGIN
	DECLARE @p_name varchar(20)
	
	SELECT @p_name = p_name FROM project2.dbo.person WHERE p_no = @p_no
	
	RETURN ISNULL(@p_name, '');
END;
go

