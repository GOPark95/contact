Create   FUNCTION dbo.holiday_cnt(
            @vac_st_date varchar(10),
			@vac_end_date varchar(10)
    )
    returns int
AS
BEGIN
	DECLARE @returnVal int
	SET @returnVal = 0
	
	WHILE @vac_st_date <= @vac_end_date
	BEGIN
		SELECT @returnVal = @returnVal + CASE WHEN dbo.holiday_chk(@vac_st_date) = '0' THEN 1 ELSE 0 END 
		
		SET @vac_st_date = CONVERT(varchar(10), dateadd(DAY, 1, CONVERT(smalldatetime, @vac_st_date)), 120)
	END
	Return @returnVal
END;
go

