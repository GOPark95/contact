
CREATE PROCEDURE [dbo].[sp_money_dir_add]


       @t_year       int, -- 검색년
       @p_year       int,  -- 이후1년
       @m_year       int, -- 이전1년
                     
       @t_month      varchar(2),  -- 검색월
       @t_table      varchar(50), -- table명
       @t_user      varchar(30)    -- 등록/수정 아이디   



AS
BEGIN
	SET NOCOUNT ON;

	--  프로젝트 직접비(추가내용:프로젝트접대비)
	
	DECLARE @y1 nvarchar(10)	
	DECLARE @y2 nvarchar(10)
	set @y1=convert(char(4),@m_year)+'-'+@t_month+'-01' -- ~부터
	set @y2=convert(char(4),@p_year)+'-'+@t_month+'-31' -- ~까지	
	
	DECLARE @group1 nvarchar(40), @code1 nvarchar(40)


	insert into dbo.sales_exp_money (tyear,tmonth,group1,group2,code1,code2,tgubn,exp_yymmdd,exp_title,account1,account2,category1,category2,category3,category4,doc_no,tgubn_code,p_child_sn,cost_money,cost_vat,
	cost_label,cost_text,div_use,edit_date,edit_user) 
	select 
	@t_year,@t_month,
	case when len(convert(nvarchar(20),BB.프로젝트코드))=11 then '프로젝트' else '' end as group1, '' as group2,
	case when len(convert(nvarchar(20),BB.프로젝트코드))=11 then convert(nvarchar(20),BB.프로젝트코드) else '' end as code1, '' as code2,	
	BB.구분, BB.사용일자, BB.문서제목, BB.계정정보1, BB.계정정보2, BB.구분1, BB.구분2, BB.구분3, BB.구분4, 
	BB.문서번호, BB.구분코드, BB.프로젝트코드, BB.단가, BB.부가세, BB.라벨, BB.전표내용,'1',GETDATE(),@t_user
	from 
	(
			select 
			'' as 구분1, '' as 구분2, '' as 구분3, '프로젝트접대비' as 구분4, A.* from 
			(
			select
			SUBSTRING(문서번호,10,1) as 구분,
			convert(nvarchar(10),target3) as 사용일자, 
			문서제목, '' as 계정정보1, '' as 계정정보2, 
			문서번호,
			SUBSTRING(문서번호,10,1) as 구분코드,
			p_sn as 프로젝트코드,
			convert(nvarchar(20),target4) as 단가,
			case when convert(nvarchar(20),target5)='' then '0' else convert(nvarchar(15),target5) end as 부가세,
			target1 as 라벨,
			target2 as 전표내용
			from dbo.문서내용
			where 문서제목='접대비보고서'
			and p_sn in (
				select p_child_sn from dbo.T_PROJECT_METHOD
				where CONVERT(nvarchar(7),p_statistics_date,120)=convert(nvarchar(4),@t_year)+'-'+@t_month
			)	
			and del_yes_no='no'			
			
			
/*			
			and convert(nvarchar(10),target3) between @y1 and @y2
--			and convert(nvarchar(10),target3) between '2000-01-01' and '3000-01-01'
			
			and left(p_sn,4)<9999
*/			
			) A
	) BB
	order by BB.사용일자 asc


END
go

