
CREATE PROCEDURE [dbo].[sp_analysis_user]


       @t_year       int, -- 검색년
       @p_year       int,  -- 이후1년
       @m_year       int, -- 이전1년
                     
       @t_month      varchar(2),  -- 검색월
       @t_table      varchar(50), -- table명
       @t_user      varchar(30)    -- 등록/수정 아이디   
       
        

AS
BEGIN

	SET NOCOUNT ON

---------- 월별 미등록 사원 등록 처리(system) ↓--------------------
---------- 월별 미등록 사원 등록 처리(system) ↓--------------------

insert into dbo.sales_user_team
(tyear,tmonth,sales_gubn,sales_hd_cd,sales_team_cd,tuser_no,div_use,edit_date,edit_user)

select 
AA.tyear, AA.tmonth,AA.sales_gubn,
case when AA.sales_gubn='팀' then null else BB.hd_cd end as sales_hd_cd, 
case when AA.sales_gubn='팀' then team_cd else null end as sales_team_cd, 
AA.p_no as tuser_no,'1' as div_use, getdate() as edit_date, 'system' as edit_user
from 
(
	select 
	@t_year as tyear,@t_month as tmonth,
	'팀' as sales_gubn, p_no, p_depart
-- 미적용	case when p_depart='39' then '본부'    -- ㅡMI연구소(39)는 본부로 처리
-- 미적용	else '팀' end as sales_gubn, p_no, p_depart
	from dbo.person
	where p_no in (
		-- 목표부서 미등록 사원추출 ↓ ------------------	
		select C.p_no from 
		(
			select A.p_no, B.tuser_no from 
			(
			select p_no from dbo.sales_month_result
			where div_use='1'
			and tyear=@t_year
			and tmonth=@t_month
			group by p_no
			) A
			left join 
			(
			select tuser_no from dbo.sales_user_team
			where div_use='1'
			and tyear=@t_year
			and tmonth=@t_month
			group by tuser_no
			) B
			on A.p_no=B.tuser_no
		) C	
		where C.tuser_no is null
		-- 목표부서 미등록 사원추출 ↑ ------------------
	)
) AA
left join 
(
select * from dbo.TG_SALES_LIST
where div_use='1'
and tg_gubn='0' -- 팀(0), 본부(1)
and tyear=@t_year
) BB
on AA.p_depart=BB.team_cd


---------- 월별 미등록 사원 등록 처리(system) ↑--------------------
---------- 월별 미등록 사원 등록 처리(system) ↑--------------------


------------ 1차 추출 ---------------------------------

insert into dbo.sales_month_result 
(tyear, tmonth, tmethod, tmethod_gubn, tservice_range, tservice_label, p_child_sn, cost_money, part_gubn, part_gubn_rate, 
p_no_odr, p_no, p_no_rate, p_no_rate_end, direct_cost, div_use, edit_date, edit_user)
select 
@t_year as tyear, @t_month as tmonth, 
CC.조사방법 as tmethod, 
CC.정량정성 as tmethod_gubn, 
CC.용역범위 as tservice_range, 
CC.용역범위라벨 as tservice_label, 
CC.프로젝트코드 as p_child_sn, 
CC.단위금액 as cost_money, 
CC.tgubn as part_gubn,
null as part_gubn_rate, 
ROW_NUMBER() OVER (PARTITION BY CC.프로젝트코드+'-'+left(CC.tgubn,2) ORDER BY CC.프로젝트코드+'-'+left(CC.tgubn,2) asc) as p_no_odr,
CC.tuser_no as p_no, 
null as p_no_rate,  
null as p_no_rate_end, 
null as direct_cost,
'1' as div_use, getdate() as edit_date, @t_user AS edit_user
from 
(
	select 조사방법,정량정성,용역범위,용역범위라벨,프로젝트코드,isnull(단위금액,'0') as 단위금액, tgubn, tuser_no from 
	(
		select 
		A.*, B.정량정성, C.용역범위라벨
		from 
		(
				select 
				p_method_cd as 조사방법,
				p_export_range as 용역범위,
				p_child_sn as 프로젝트코드,
				p_cont_cost as 단위금액,
				p_rsch_1_a as 기획1,
				p_rsch_2_a as 기획2,
				p_rsch_3_a as 기획3,
				p_rsch_4_a as 기획4,

				p_rsch_1_b as 실사관리1,
				p_rsch_2_b as 실사관리2,
				p_rsch_3_b as 실사관리3,
				p_rsch_4_b as 실사관리4,
				p_rsch_1_c as 보고서1,
				p_rsch_2_c as 보고서2,
				p_rsch_3_c as 보고서3,
				p_rsch_4_c as 보고서4
				from dbo.T_PROJECT_METHOD
				where left(p_statistics_date,7)=convert(nvarchar(4),@t_year)+'-'+@t_month

		) A
		left join 
		(
		-- 조사방법(정량:1, 정성:2)
		SELECT p_method_cd, p_gubn as 정량정성  FROM dbo.T_PROJECT_METHOD_CD
		) B
		on A.조사방법=B.p_method_cd
		left join 
		(
		-- 용역범위 정보
		SELECT c_common_code, c_code_name as 용역범위라벨 FROM dbo.T_COMMON_CODE_DETAIL
		where convert(nvarchar(10),c_code_desc)='용역범위 정보'
		) C
		on A.용역범위=C.c_common_code
	) AA
	UnPivot (tuser_no For tgubn In ([기획1],[기획2],[기획3],[기획4],[실사관리1],[실사관리2],[실사관리3],[실사관리4],[보고서1],[보고서2],[보고서3],[보고서4])) As UnPivoRtn
) CC
where len(CC.tuser_no)>0
and CC.tuser_no in (
select p_no from dbo.person
where p_team_place<10   -- 인턴사원 제외(참여자가 퇴사자인 경우도 포함하여 계산) 
/*
	select tuser_no from dbo.sales_user
	where convert(nvarchar(4),tyear)+'-'+tmonth=convert(nvarchar(4),@t_year)+'-'+@t_month
	and div_use='1'
	and sales_gubn in ('팀','본부')
*/	
)
order by CC.프로젝트코드,CC.tgubn asc



-- (1) 참여구분 비율할당 적용SQL(join update)
update dbo.sales_month_result set 
part_gubn_rate=B.tgubn_rate
from dbo.sales_month_result as A
left join 
(
	select
	tyear, tmonth, prj_type, service_type, tgubn, 
	case when tgubn='tplan' then '기획' 
	when tgubn='tprogress' then '실사' 
	when tgubn='treport' then '보고' end as tgubn_han, 
	tgubn_rate
	from 
	(
	select
	tyear, tmonth, prj_type, service_type, tplan, tprogress, treport
	from dbo.sales_index
	where div_use='1'
	and convert(nvarchar(4),tyear)+'-'+tmonth in (
		select top 1 convert(nvarchar(4),tyear)+'-'+tmonth from dbo.sales_index
		where div_use='1'
	)
	group by tyear, tmonth, prj_type, service_type, tplan, tprogress, treport
	) A
	UnPivot (tgubn_rate For tgubn In ([tplan],[tprogress],[treport])) As UnPivoRtn
) B
on A.tmethod_gubn=B.prj_type
and A.tservice_range=B.service_type
and left(A.part_gubn,2)=B.tgubn_han
where A.div_use='1'
and A.tyear=@t_year
and A.tmonth=@t_month







-- (2) 참여사원 비율할당 적용(join update)
update dbo.sales_month_result set 
p_no_rate_end=BB.tgubn_user_rate
from dbo.sales_month_result as  AA
left join 
(
	select 
	p_child_sn, tmethod_gubn, tservice_range, pgubn, max_num, join_cnt, 
	right(tgubn_user_rate_lb,1) as ranks, tgubn_user_rate
	from 
	(
		select
		A.p_child_sn, A.tmethod_gubn, A.tservice_range, A.pgubn, A.max_num , 
		B.join_cnt, B.rate1, B.rate2, B.rate3, B.rate4
		from 
		(
			select p_child_sn, tmethod_gubn, tservice_range, left(part_gubn,2) as pgubn, 
			MAX(p_no_odr) as max_num 
			from dbo.sales_month_result
			where div_use='1'
			and tyear=@t_year
			and tmonth=@t_month
			group by p_child_sn, tmethod_gubn, tservice_range, left(part_gubn,2) 
		) A
		left join 
		(
			select 
			prj_type,service_type,join_cnt,rate1,rate2,rate3,rate4
			from dbo.sales_index
			where div_use='1'
			and convert(nvarchar(4),tyear)+'-'+tmonth in (
				select top 1 convert(nvarchar(4),tyear)+'-'+tmonth from dbo.sales_index
				where div_use='1'
			)
			group by prj_type,service_type,join_cnt,rate1,rate2,rate3,rate4
		) B
		on A.tmethod_gubn=B.prj_type
		and A.tservice_range=B.service_type
		and A.max_num=B.join_cnt
	) C
	UnPivot (tgubn_user_rate For tgubn_user_rate_lb In ([rate1],[rate2],[rate3],[rate4])) As UnPivoRtn
) BB
on AA.p_child_sn=BB.p_child_sn
and AA.tmethod_gubn=BB.tmethod_gubn
and AA.tservice_range=BB.tservice_range
and left(AA.part_gubn,2)=BB.pgubn
and AA.p_no_odr=BB.ranks
where AA.div_use='1'
and AA.tyear=@t_year
and AA.tmonth=@t_month



-- (3) 프로젝트 직접비 업데이트(join update)
update dbo.sales_month_result set 
direct_cost=B.sum_money
from dbo.sales_month_result as A
left join 
(
select group1, code1, SUM(cost_money) as sum_money  from dbo.sales_exp_money
where group1='프로젝트' 
and tyear=@t_year 
and tmonth=@t_month
group by group1, code1
) B
on A.p_child_sn=B.code1
where A.tyear=@t_year 
and A.tmonth=@t_month
and A.div_use='1'

-- (4) 지출내용이 없는경우  direct_cost is null 은 0 으로 처리 

update dbo.sales_month_result set 
direct_cost=0
where tyear=@t_year 
and tmonth=@t_month
and div_use='1'
and direct_cost is null 

-----------------------------------------------------------------



 -- 본부/팀 직접비 초기화
update dbo.sales_indirect_cost set 
div_use='0'
where div_use='1'
and tyear=@t_year 
and tmonth=@t_month


-- 본부비 사용금액(월별)
insert into dbo.sales_indirect_cost 
(tyear, tmonth, tgubn, hd_cd, team_cd, direct_cost, div_use, edit_date, edit_user)
 select
 @t_year as tyear, @t_month as tmonth,
 group1,code2,'' as nocost,
 SUM(cost_money) as direct_money, 
 '1' as div_use, 
 getdate() as edit_date, 
 @t_user AS edit_user
 from dbo.sales_exp_money
 where group1 in ('본부')
 and tyear=@t_year
 and tmonth=@t_month
 and exp_yymmdd between CONVERT(nvarchar(4),@t_year)+'-'+@t_month+'-01' and CONVERT(nvarchar(4),@t_year)+'-'+@t_month+'-31'
 group by tyear,tmonth,group1,code2 
 
 
 -- 팀비 사용금액(월별)
insert into dbo.sales_indirect_cost 
(tyear, tmonth, tgubn, hd_cd, team_cd, direct_cost, div_use, edit_date, edit_user)
 select
 @t_year as tyear, @t_month as tmonth,
 group1 ,'' as nocost, code2,
 SUM(cost_money) as direct_money, 
 '1' as div_use, 
 getdate() as edit_date, 
 @t_user AS edit_user
 from dbo.sales_exp_money
 where group1 in ('팀')
 and tyear=@t_year
 and tmonth=@t_month
 and exp_yymmdd between CONVERT(nvarchar(4),@t_year)+'-'+@t_month+'-01' and CONVERT(nvarchar(4),@t_year)+'-'+@t_month+'-31'
 group by tyear,tmonth,group1,code2 
 
 
 



END
go

