-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[sp_money_payment]
	-- Add the parameters for the stored procedure here

       @t_year       int, -- 검색년
       @p_year       int,  -- 이후1년
       @m_year       int, -- 이전1년
                     
       @t_month      varchar(2),  -- 검색월
       @t_table      varchar(50), -- table명
       @t_user      varchar(30)    -- 등록/수정 아이디   



AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here

	--  가지급금 계산
	
	DECLARE @y1 nvarchar(10)	
	DECLARE @y2 nvarchar(10)
	set @y1=convert(char(4),@m_year)+'-'+@t_month+'-01' -- ~부터
	set @y2=convert(char(4),@p_year)+'-'+@t_month+'-31' -- ~까지	

	DECLARE @문서번호 nvarchar(20)
	DECLARE @문서제목 nvarchar(30)	
	DECLARE @지급일자 nvarchar(10)
	
	DECLARE @구분코드 char(1)
	DECLARE @내용 nvarchar(max)
	
	DECLARE @프로젝트코드 nvarchar(30)	
	DECLARE @라벨 nvarchar(400)
	DECLARE @가불내용 nvarchar(max)	
		
	DECLARE @t1 nvarchar(10),@t2 money
	
	DECLARE @group1 nvarchar(40), @code1 nvarchar(40)

-------------(1)-----------------------------
	DECLARE cur_step1 CURSOR FOR
	select 
	A.문서번호, A.문서제목,A.지급일자, A.구분코드, A.target_all, A.프로젝트코드, A.라벨, A.가불내용
	from
	(
		select 
		문서번호, 
		문서제목, 
		SUBSTRING(문서번호,10,1) as 구분코드,
		target15 as target_all ,
		target18 as 프로젝트코드,
		target6 as 라벨,
		target11 as 가불내용,
		convert(nvarchar(10),target4) as 지급일자
		from dbo.문서내용
		where 문서제목 in ('가지급금정산2','가지급금정산')
		and p_sn in (
			select p_child_sn from dbo.T_PROJECT_METHOD
			where CONVERT(nvarchar(7),p_statistics_date,120)=convert(nvarchar(4),@t_year)+'-'+@t_month
		)	
		and del_yes_no='no' -- 결재중 or 결재완료(no)
				
--		and convert(nvarchar(10),target4) between @y1 and @y2 -- 지급일자기준
--		and convert(nvarchar(10),target4) between '2000-01-01' and '3000-01-01' -- 지급일자기준

	) A
-- 	where A.구분코드 in ('5','Q')
	order by A.지급일자 asc
	OPEN cur_step1
	FETCH NEXT FROM cur_step1 INTO @문서번호, @문서제목, @지급일자, @구분코드, @내용, @프로젝트코드, @라벨, @가불내용
	WHILE @@FETCH_STATUS = 0
	BEGIN
		-------------(2)-----------------------------
		DECLARE cur_step2 CURSOR FOR	
		select [1] as t1,[2] as t2 from (
			SELECT POS, VAL1 FROM  dbo.[FN_SPLIT](@내용,'^^')
			where POS in (1,2)
		) A
		pivot
		(max(A.VAL1) for A.POS in ([1],[2])) B	
		OPEN cur_step2		
		FETCH NEXT FROM cur_step2 INTO @t1, @t2
		WHILE @@FETCH_STATUS = 0
		BEGIN
			-------------(3)-----------------------------
			if len(@프로젝트코드)=11 
				BEGIN
				set @group1='프로젝트'
				set @code1=@프로젝트코드
				end 
			else
				BEGIN
				set @group1=''	
				set @code1=''
				end 
			
			insert into dbo.sales_exp_money (tyear,tmonth,group1,group2,code1,code2,tgubn,exp_yymmdd,exp_title,account1,account2,category1,category2,category3,category4,doc_no,tgubn_code,p_child_sn,cost_money,cost_vat,cost_label,cost_text,div_use,edit_date,edit_user) 
			values (@t_year,@t_month,@group1,'',@code1,'',@구분코드,@t1,@문서제목,'','','','','','가지급금액',@문서번호,@구분코드,@프로젝트코드,@t2,0, @라벨, @가불내용,'1',GETDATE(),@t_user)
			-------------(3)-----------------------------		
		FETCH NEXT FROM cur_step2 INTO @t1, @t2
		END
		CLOSE cur_step2
		DEALLOCATE cur_step2
		-------------(2)-----------------------------	
		
	FETCH NEXT FROM cur_step1 INTO @문서번호, @문서제목, @지급일자, @구분코드, @내용, @프로젝트코드, @라벨, @가불내용
	END
	
	CLOSE cur_step1
	DEALLOCATE cur_step1
-------------(1)-----------------------------




END
go

