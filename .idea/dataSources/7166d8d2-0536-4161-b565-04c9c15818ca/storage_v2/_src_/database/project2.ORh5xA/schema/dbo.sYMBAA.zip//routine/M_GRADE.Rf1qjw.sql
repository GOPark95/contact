CREATE FUNCTION dbo.M_GRADE
(
	@m_id NUMERIC(18, 0), 
	@cDate VARCHAR(10), 
	@sebu VARCHAR(10)
)
RETURNS VARCHAR(20)
AS 
BEGIN 
	DECLARE @grade VARCHAR(20)
	
	SELECT TOP 1 @grade = CC.name
	FROM T_MYUN_GRADE_HISTORY MG LEFT JOIN category CC 
	ON CC.구분 = 'grade' AND MG.m_grade = CC.code
	WHERE m_id = @m_id 
	AND ISNULL(attribute02, @sebu) = @sebu
	AND m_grade_dt <= @cDate 
	ORDER BY m_grade_dt DESC, insert_dt DESC
	
	RETURN @grade;
END;
go

