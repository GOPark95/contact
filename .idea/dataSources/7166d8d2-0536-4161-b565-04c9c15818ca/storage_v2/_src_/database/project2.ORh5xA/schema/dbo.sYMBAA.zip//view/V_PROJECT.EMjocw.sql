CREATE VIEW dbo.V_PROJECT
AS
SELECT  sn, p_sn, p_sn_tmp, p_subject, p_content, p_intention, p_depart, p_depart_dep, p_depart_team, p_cli_company, 
               p_cli_depart, p_cp_code, p_cli_name, p_cli_type, p_cli_class, p_area_part, p_area, p_target_sex, p_target_age, 
               p_target_job, p_target_part, p_target_text, p_method, CONVERT(VARCHAR(50), p_category) AS p_category, 
               p_category2, p_category3, p_types1, p_types2, p_types3, p_rsch_1, p_rsch_2, p_rsch_3, p_rsch_4, p_rsch_5, 
               p_rsch_6, p_it, p_dper, p_dper2, p_dper3, p_dper4, p_sv, p_sv2, p_coder, p_verify, p_budget, p_budget_pre, 
               p_budget_mid, p_budget_fin, p_sales, p_esti_cost, p_real_cost, p_esti_cost_research, p_real_cost_research, 
               p_conv_date, p_convdate_st, p_convdate_end, p_convdate_st2, p_convdate_end2, p_report_st, p_report_end, 
               p_report_st2, p_report_end2, p_field_st, p_field_end, p_field_st2, p_field_end2, p_reg_date, p_punch_st, 
               p_punch_end, p_punch_st2, p_punch_end2, p_survey_date, p_prop_date, p_dp_st, p_dp_end, p_dp_st2, 
               p_dp_end2, p_ot_date, p_ot_date2, p_tableguide_date, p_editguide_date, p_premeet_date, p_premeet_date2, 
               p_input_standard_date, p_upload_date, p_cross_app_end_date, p_cross_app_yes_no, p_Dp_rank, p_field_rank, 
               p_dp_point, p_field_point, p_sample, p_sample_real, p_sample_seoul, p_extract, p_survey_cnt, p_survey_open, 
               p_contactor, p_contact_date, p_contact_place, p_contact_content, p_close, p_filed_point_del_yes_no, p_spss, 
               p_memo, p_rsch_1p, p_rsch_2p, p_rsch_3p, p_rsch_4p, p_reg_rsch, p_tax, p_reg_mana, p_view_grade, 
               p_method_chk, p_sample_chk, p_budget_chk, p_survey_cnt_chk, p_survey_part, p_survey_times, 
               p_field_process, p_verify_chk, p_verify_prop_chk, p_error_chk, p_error_prop_chk, p_otjoin_chk, p_people_chk, 
               p_sample_value_chk, p_verify_total_chk, p_astime_chk, p_field_rank_chk, '' AS p_dept_rsh, '' AS p_dept_field, 
               '' AS p_dept_it, '' AS p_dept_admin, '' AS p_decide_date, '' AS p_con_date_st, '' AS p_con_date_end, 
               '' AS p_export_range, p_conv_date AS p_input_dt, '' AS p_state, p_rsch_1 AS p_input_user, 
               '' AS p_statistics, '' as p_drop_reason
FROM     PROJECT
WHERE  RIGHT(p_sn, 3) <> '000'
UNION ALL
SELECT  sn AS sn, p_sn AS p_sn, '' AS p_sn_tmp, p_subject AS p_subject, p_content AS p_content, 
               p_intention AS p_intention, p_depart AS p_depart, p_depart_dep AS p_depart_dep, 
               p_depart_team AS p_depart_team, p_cli_company_cd AS p_cli_company, p_cli_depart AS p_cli_depart, 
               p_cli_per_cd AS p_cp_code, p_cli_name AS p_cli_name, p_client_type_cd AS p_cli_type, 
               p_cli_class AS p_cli_class, p_area_part AS p_area_part, p_area AS p_area, p_target_sex AS p_target_sex, 
               p_target_age AS p_target_age, p_target_job AS p_target_job, p_target_part AS p_target_part, 
               p_target_text AS p_target_text, p_method AS p_method, p_category AS p_category, p_category2 AS p_category2, 
               p_category3 AS p_category3, p_types1 AS p_types1, p_types2 AS p_types2, p_types3 AS p_types3, 
               p_rsch_1 AS p_rsch_1, p_rsch_2 AS p_rsch_2, p_rsch_3 AS p_rsch_3, p_rsch_4 AS p_rsch_4, 
               p_rsch_5 AS p_rsch_5, p_rsch_6 AS p_rsch_6, p_it AS p_it, p_dper AS p_dper, p_dper2 AS p_dper2, 
               p_dper3 AS p_dper3, p_dper4 AS p_dper4, p_sv AS p_sv, p_sv2 AS p_sv2, p_coder AS p_coder, 
               p_verify AS p_verify, ISNULL(p_total_cost, p_obtain_cost) AS p_budget, p_budget_pre AS p_budget_pre, 
               p_budget_mid AS p_budget_mid, p_budget_fin AS p_budget_fin, p_sales AS p_sales, p_esti_cost AS p_esti_cost, 
               p_real_cost AS p_real_cost, p_esti_cost_research AS p_esti_cost_research, 
               p_real_cost_research AS p_real_cost_research, p_conv_date AS p_conv_date, p_convdate_st AS p_convdate_st, 
               p_convdate_end AS p_convdate_end, p_convdate_st2 AS p_convdate_st2, 
               p_convdate_end2 AS p_convdate_end2, p_report_st AS p_report_st, p_report_end AS p_report_end, 
               p_report_st2 AS p_report_st2, p_report_end2 AS p_report_end2, p_field_st AS p_field_st, 
               p_field_end AS p_field_end, p_field_st2 AS p_field_st2, p_field_end2 AS p_field_end2, 
               p_reg_date AS p_reg_date, p_punch_st AS p_punch_st, p_punch_end AS p_punch_end, 
               p_punch_st2 AS p_punch_st2, p_punch_end2 AS p_punch_end2, p_survey_date AS p_survey_date, 
               p_prop_date AS p_prop_date, p_dp_st AS p_dp_st, p_dp_end AS p_dp_end, p_dp_st2 AS p_dp_st2, 
               p_dp_end2 AS p_dp_end2, p_ot_date AS p_ot_date, p_ot_date2 AS p_ot_date2, 
               p_tableguide_date AS p_tableguide_date, p_editguide_date AS p_editguide_date, 
               p_premeet_date AS p_premeet_date, p_premeet_date2 AS p_premeet_date2, 
               p_input_standard_date AS p_input_standard_date, p_upload_date AS p_upload_date, 
               p_cross_app_end_date AS p_cross_app_end_date, p_cross_app_yes_no AS p_cross_app_yes_no, 
               p_Dp_rank AS p_Dp_rank, p_field_rank AS p_field_rank, p_dp_point AS p_dp_point, 
               p_field_point AS p_field_point, p_sample AS p_sample, p_sample_real AS p_sample_real, 
               p_sample_seoul AS p_sample_seoul, p_extract AS p_extract, p_survey_cnt AS p_survey_cnt, 
               p_survey_open AS p_survey_open, p_contactor AS p_contactor, p_contact_date AS p_contact_date, 
               p_contact_place AS p_contact_place, p_contact_content AS p_contact_content, p_close AS p_close, 
               p_filed_point_del_yes_no AS p_filed_point_del_yes_no, p_spss AS p_spss, p_memo AS p_memo, 
               p_rsch_1p AS p_rsch_1p, p_rsch_2p AS p_rsch_2p, p_rsch_3p AS p_rsch_3p, p_rsch_4p AS p_rsch_4p, 
               p_reg_rsch AS p_reg_rsch, p_tax AS p_tax, p_reg_mana AS p_reg_mana, p_view_grade AS p_view_grade, 
               p_method_chk AS p_method_chk, p_sample_chk AS p_sample_chk, p_budget_chk AS p_budget_chk, 
               p_survey_cnt_chk AS p_survey_cnt_chk, p_survey_part AS p_survey_part, p_survey_times AS p_survey_times, 
               p_field_process AS p_field_process, p_verify_chk AS p_verify_chk, p_verify_prop_chk AS p_verify_prop_chk, 
               p_error_chk AS p_error_chk, p_error_prop_chk AS p_error_prop_chk, p_otjoin_chk AS p_otjoin_chk, 
               p_people_chk AS p_people_chk, p_sample_value_chk AS p_sample_value_chk, 
               p_verify_total_chk AS p_verify_total_chk, p_astime_chk AS p_astime_chk, p_field_rank_chk AS p_field_rank_chk, 
               p_dept_rsh, p_dept_field, p_dept_it, p_dept_admin, p_decide_date, p_con_date_st, p_con_date_end, 
               p_export_range, p_input_dt, p_state, p_input_user, p_statistics, p_drop_reason
FROM     T_PROJECT_BASE
go

exec sp_addextendedproperty 'MS_DiagramPane1', N'[0E232FF0-B466-11cf-A24F-00AA00A3EFFF, 1.00]
Begin DesignProperties = 
   Begin PaneConfigurations = 
      Begin PaneConfiguration = 0
         NumPanes = 4
         Configuration = "(H (1[6] 4[11] 2[65] 3) )"
      End
      Begin PaneConfiguration = 1
         NumPanes = 3
         Configuration = "(H (1 [50] 4 [25] 3))"
      End
      Begin PaneConfiguration = 2
         NumPanes = 3
         Configuration = "(H (1 [50] 2 [25] 3))"
      End
      Begin PaneConfiguration = 3
         NumPanes = 3
         Configuration = "(H (4 [30] 2 [40] 3))"
      End
      Begin PaneConfiguration = 4
         NumPanes = 2
         Configuration = "(H (1 [56] 3))"
      End
      Begin PaneConfiguration = 5
         NumPanes = 2
         Configuration = "(H (2 [66] 3))"
      End
      Begin PaneConfiguration = 6
         NumPanes = 2
         Configuration = "(H (4 [50] 3))"
      End
      Begin PaneConfiguration = 7
         NumPanes = 1
         Configuration = "(V (3))"
      End
      Begin PaneConfiguration = 8
         NumPanes = 3
         Configuration = "(H (1[56] 4[18] 2) )"
      End
      Begin PaneConfiguration = 9
         NumPanes = 2
         Configuration = "(H (1 [75] 4))"
      End
      Begin PaneConfiguration = 10
         NumPanes = 2
         Configuration = "(H (1[66] 2) )"
      End
      Begin PaneConfiguration = 11
         NumPanes = 2
         Configuration = "(H (4 [60] 2))"
      End
      Begin PaneConfiguration = 12
         NumPanes = 1
         Configuration = "(H (1) )"
      End
      Begin PaneConfiguration = 13
         NumPanes = 1
         Configuration = "(V (4))"
      End
      Begin PaneConfiguration = 14
         NumPanes = 1
         Configuration = "(V (2))"
      End
      ActivePaneConfig = 0
   End
   Begin DiagramPane = 
      Begin Origin = 
         Top = 0
         Left = 0
      End
      Begin Tables = 
      End
   End
   Begin SQLPane = 
   End
   Begin DataPane = 
      Begin ParameterDefaults = ""
      End
   End
   Begin CriteriaPane = 
      Begin ColumnWidths = 11
         Column = 1440
         Alias = 900
         Table = 1170
         Output = 720
         Append = 1400
         NewValue = 1170
         SortType = 1350
         SortOrder = 1410
         GroupBy = 1350
         Filter = 1350
         Or = 1350
         Or = 1350
         Or = 1350
      End
   End
End
', 'SCHEMA', 'dbo', 'VIEW', 'V_PROJECT'
go

exec sp_addextendedproperty 'MS_DiagramPaneCount', 1, 'SCHEMA', 'dbo', 'VIEW', 'V_PROJECT'
go

