
create PROCEDURE dbo.sp_money_data_arr


       @t_year       int, -- 검색년
       @p_year       int,  -- 이후1년
       @m_year       int, -- 이전1년
                     
       @t_month      varchar(2),  -- 검색월
       @t_table      varchar(50), -- table명
       @t_user      varchar(30)    -- 등록/수정 아이디   
       
        

AS
BEGIN

	SET NOCOUNT ON
--비용관련 불필요 데이터 정리

    DECLARE @y1      nvarchar(30)    -- ~ 부터
    DECLARE @y2      nvarchar(30)    -- ~ 까지
    set @y1=convert(char(4),@t_year)+@t_month+'01'
    set @y2=convert(char(4),@t_year)+@t_month+'31'      


-- 일반비용 삭제처리
delete from dbo.sales_exp_money
where div_use='1'
and group1='일반' 
and tyear=@t_year
and tmonth=@t_month

-- 추출범위외 '팀','본부' 사용비용 데이터 삭제처리
delete from dbo.sales_exp_money
where div_use='1'
and group1 in ('팀','본부')
and tyear=@t_year
and tmonth=@t_month
and (replace(exp_yymmdd,'-','')<@y1 or replace(exp_yymmdd,'-','')>@y2)


-- *************************************************************
-- MI연구소의 경우 예외처리 팀(39) 를  본부(43) 으로 처리
-- *************************************************************
/*
-- 미사용
update dbo.sales_exp_money set 
 group1='본부'
,code2='43'
where div_use='1'
and group1='팀'
and code2='39'
and tyear=@t_year
and tmonth=@t_month
*/



/*
update dbo.sales_exp_money set 
div_use='9999'
where id in (
	select id from dbo.sales_exp_money
	where div_use='1'
	and group1='일반' 
	and tyear=@t_year
	and tmonth=@t_month
)


update dbo.sales_exp_money set 
div_use='9999'
where id in (
	select id from dbo.sales_exp_money
	where div_use='1'
	and group1 in ('팀','본부')
	and tyear=@t_year
	and tmonth=@t_month
	and (replace(exp_yymmdd,'-','')<@y1 or replace(exp_yymmdd,'-','')>@y2)
)
*/

END
go

