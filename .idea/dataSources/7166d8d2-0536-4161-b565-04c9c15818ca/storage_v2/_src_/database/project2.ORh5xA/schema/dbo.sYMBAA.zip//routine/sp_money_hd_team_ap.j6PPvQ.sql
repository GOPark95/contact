
CREATE PROCEDURE [dbo].[sp_money_hd_team_ap]


       @t_year       int, -- 검색년
       @p_year       int,  -- 이후1년
       @m_year       int, -- 이전1년
                     
       @t_month      varchar(2),  -- 검색월
       @t_table      varchar(50), -- table명
       @t_user      varchar(30)    -- 등록/수정 아이디   



AS
BEGIN

	SET NOCOUNT ON;


	 --  본부/팀/ 일반 비용
/*	 
	DECLARE @y1 nvarchar(10)	
	DECLARE @y2 nvarchar(10)
	set @y1=convert(char(4),@m_year)+'-'+@t_month+'-01' -- ~부터
	set @y2=convert(char(4),@p_year)+'-'+@t_month+'-31' -- ~까지	
*/


	
	DECLARE @문서번호 nvarchar(20)
	DECLARE @문서제목 nvarchar(30)	
	DECLARE @발급일자 nvarchar(10)
		
	DECLARE @구분코드 char(1)
	DECLARE @등록구분1 nvarchar(10)
	DECLARE @등록구분2 nvarchar(10)

	DECLARE @내용 nvarchar(max)	

	DECLARE @t1 nvarchar(500)	
	DECLARE @t2 int
	DECLARE @t3 nvarchar(500)
	
	DECLARE @t11 nvarchar(10)
	DECLARE @t12 nvarchar(300)
	DECLARE @t13 nvarchar(500)
	DECLARE @t14 nvarchar(20)
	DECLARE @t15 nvarchar(20)
	DECLARE @t16 nvarchar(200)
	
	DECLARE @group1 nvarchar(40), @code1 nvarchar(40)
	DECLARE @group2 nvarchar(40), @code2 nvarchar(40)		
	

	-- 부서비신청서 
	DECLARE cur_step1 CURSOR FOR
	select 
	A.문서번호, A.문서제목, A.발급일자, A.구분코드, A.등록구분1, A.등록구분2, A.target_all 
	from
	(
		select 
		문서번호, 문서제목,  	
		convert(nvarchar(10),발급일) as 발급일자,	
		SUBSTRING(문서번호,10,1) as 구분코드,	
		convert(nvarchar(10),target20) as 등록구분1,
		convert(nvarchar(10),target21) as 등록구분2,
		replace(convert(nvarchar(1000),isnull(target1,'')),'¿','')+'¿'+replace(convert(nvarchar(1000),isnull(target2,'')),'¿','')+'¿'+replace(convert(nvarchar(1000),isnull(target3,'')),'¿','')+'¿'+replace(convert(nvarchar(1000),isnull(target4,'')),'¿','')+'¿'+replace(convert(nvarchar(1000),isnull(target5,'')),'¿','')+'¿'+
		replace(convert(nvarchar(1000),isnull(target6,'')),'¿','')+'¿'+replace(convert(nvarchar(1000),isnull(target7,'')),'¿','')+'¿'+replace(convert(nvarchar(1000),isnull(target8,'')),'¿','')+'¿'+replace(convert(nvarchar(1000),isnull(target9,'')),'¿','')+'¿'+replace(convert(nvarchar(1000),isnull(target10,'')),'¿','')+'¿'+
		replace(convert(nvarchar(1000),isnull(target11,'')),'¿','')+'¿'+replace(convert(nvarchar(1000),isnull(target12,'')),'¿','')+'¿'+replace(convert(nvarchar(1000),isnull(target13,'')),'¿','')+'¿'+replace(convert(nvarchar(1000),isnull(target14,'')),'¿','')+'¿' 
		as target_all
		from dbo.문서내용
		where 문서제목='부서비신청서'	
		and del_yes_no='no' -- 결재중 or 결재완료(no)		
		--and 문서번호 in ('KRC-2016-w-00080')
		and convert(nvarchar(10),target20) in ('본부','팀')
		and convert(nvarchar(7),target1)=convert(nvarchar(4),@t_year)+'-'+@t_month
		
--		and convert(nvarchar(10),target1) between @y1 and @y2
--		and convert(nvarchar(10),target3) between '2000-01-01' and '3000-01-01'
	) A
	where A.구분코드='w'
	order by A.발급일자 asc


	OPEN cur_step1
	FETCH NEXT FROM cur_step1 INTO @문서번호, @문서제목, @발급일자, @구분코드, @등록구분1, @등록구분2, @내용 
	WHILE @@FETCH_STATUS = 0
	BEGIN
		----------------------(2)------------------------------------------------

		DECLARE cur_step2 CURSOR FOR		
		select POS, VAL1 from  dbo.[FN_SPLIT](@내용,'¿') where len(VAL1)>0
		OPEN cur_step2
		FETCH NEXT FROM cur_step2 INTO @t2,@t3 
		WHILE @@FETCH_STATUS = 0
		BEGIN
			----------------------(3)------------------------------------------------
			DECLARE cur_step3 CURSOR FOR					
			select [1] as t1,[2] as t2,[3] as t3,[4] as t4,[5] as t5,[6] as t6 from (
				select POS, VAL1 from  dbo.FN_SPLIT(@t3,'^^')
			) A
			pivot
			(max(A.VAL1) for A.POS in ([1],[2],[3],[4],[5],[6])) B
			OPEN cur_step3
			
			FETCH NEXT FROM cur_step3 INTO @t11,@t12,@t13,@t14,@t15,@t16
			WHILE @@FETCH_STATUS = 0
			BEGIN 

			set @group1=''
			set @code1=''
			set @group2=''
			set @code2=''			

					--------------------------------------------------------
					select @group1=C.tlabel, @code1=C.hcd2, @code2=C.hcd, @group2=C.hname  from 
					(
							select 
							'본부' as tlabel,
							hd_cd2 as hcd2, 
							hd_cd as hcd, 
							hd_name as hname 
							from dbo.TEAM_GROUP
							where hd_cd2<>''
							group by hd_cd2,hd_cd, hd_name
						union 
							select 
							A.tlabel,
							A.hd_cd2,
							A.team_cd,
							A.team_name  
							from 
							(
							select 
							'팀' as tlabel,
							(9999000+team_cd) as hd_cd2,
							team_cd,team_name 
							from dbo.TEAM_GROUP
							where team_cd>0 
							group by team_cd,team_name
							) A
							group by A.tlabel,A.hd_cd2,A.team_cd,A.team_name 
					) C
					where C.tlabel=@등록구분1
					and C.hcd=@등록구분2
					--------------------------------------------------------

			-- #Table에 insert
			-------------(3)-----------------------------
			insert into dbo.sales_exp_money (tyear,tmonth,group1,group2,code1,code2,tgubn,exp_yymmdd,exp_title,account1,account2,category1,category2,category3,category4,doc_no,tgubn_code,p_child_sn,cost_money,cost_vat,cost_label,cost_text,div_use,edit_date,edit_user) 
			values  (@t_year,@t_month,@group1,@group2,@code1,@code2,'A',@t11,@문서제목,'','',@등록구분1,@등록구분2,'',@문서제목,@문서번호,@구분코드,@t15,@t14,0,@t12,@t13+' ['+@t16+']','1',GETDATE(),@t_user)		
			-------------(3)-----------------------------			

			FETCH NEXT FROM cur_step3 INTO @t11,@t12,@t13,@t14,@t15,@t16
			END
			CLOSE cur_step3
			DEALLOCATE cur_step3




			----------------------(3)------------------------------------------------
		FETCH NEXT FROM cur_step2 INTO @t2,@t3 
		END
		CLOSE cur_step2
		DEALLOCATE cur_step2

		----------------------(2)------------------------------------------------
	FETCH NEXT FROM cur_step1 INTO @문서번호, @문서제목, @발급일자, @구분코드, @등록구분1, @등록구분2, @내용 
	END

	CLOSE cur_step1
	DEALLOCATE cur_step1
-------------(1)-----------------------------



END
go

