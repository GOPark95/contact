CREATE view [dbo].[V_Person]
as
select p_no, p_name, p_depart_now, 
(select D_Name from v_Department where D_code=p_depart_now and T_Code=p_team_now) as p_depart_name, 
p_team_now,
(select T_Name from v_Department where D_code=p_depart_now and T_Code=p_team_now) as p_team_name,
p_rank_now,
(select R_Name from N_Rank where flag='1'and R_Code=p_rank_now) as p_rank_name,
p_position_now, 
(select P_Name from N_Position where flag='1'and P_Code=p_position_now) as p_position_name,
p_job_now, 
(select name from category_인사관리용 where 구분='담당업무' and d_yes_no='no' and code=p_job_now) as p_job_name,
p_user_mail, p_tel2, p_tel3, p_ip, p_tel_ip, p_depart, p_depart_first, p_team, p_team_place, krc_power, krc_in_date, krc_out_date, p_resign, p_pass, p_pass_new, birthday, jumin
from person where p_pos_first is not null
go

