CREATE FUNCTION dbo.M_FOOD_COST
(
	@m_id NUMERIC(18, 0), 
	@cDate VARCHAR(10), 
	@p_child_sn VARCHAR(20),
	@sebu VARCHAR(10),
	@lunch_dinner VARCHAR(10)
)
RETURNS VARCHAR(20)
AS 
BEGIN 
	DECLARE @food_cost VARCHAR(30)
	DECLARE @fc_unit VARCHAR(20)
	DECLARE @foodRate NUMERIC(8, 5)
	DECLARE @sumFCost FLOAT 
	
	SELECT @foodRate = SUM(CASE WHEN p_child_sn = @p_child_sn AND p_sebu_code = @sebu THEN job_in_time ELSE 0 END) / SUM(job_in_time) 
	FROM neakeun_work NW LEFT JOIN 
	man M ON NW.neakeun_name = M.m_name AND LEFT(NW.neakeun_jumin, 6) = LEFT(M.m_jumin, 6) 
	WHERE [date] = @cDate
	AND M.id = @m_id
	AND in_time + out_time <> '00000000'
	
	SELECT TOP 1 @fc_unit = cost 
	FROM t_neakeun_pay_COST 
	WHERE [type] = @lunch_dinner 
	AND use_start_dt <= @cDate
	ORDER BY use_start_dt DESC
	
	SELECT @sumFCost = ISNULL(SUM(s_sum), 0)  
	FROM T_NEAKEUN_PAY TNP LEFT JOIN 
	man M ON TNP.m_name = M.m_name AND LEFT(TNP.m_jumin, 6) = LEFT(M.m_jumin, 6) 
	WHERE M.id = @m_id
	AND TNP.work_dt = @cDate
	AND TNP.s_gubun = ('추가수당' + CASE @lunch_dinner WHEN 'lunch' THEN '1' WHEN 'dinner' THEN '2' END) 
	
	IF(@sumFCost = CONVERT(FLOAT, @fc_unit))
		BEGIN 
			SELECT @food_cost = 0
		END	
	ELSE
		BEGIN
			SELECT @food_cost = ROUND(CONVERT(FLOAT, @fc_unit) * @foodRate, 0)		
		END
	
	RETURN @food_cost;
END;
go

