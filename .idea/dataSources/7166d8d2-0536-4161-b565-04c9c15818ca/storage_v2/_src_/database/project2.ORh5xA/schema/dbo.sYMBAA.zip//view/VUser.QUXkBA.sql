CREATE VIEW dbo.VUser AS
SELECT 	p_no AS OID,
			LOWER(project2.dbo.SPLIT(p_user_mail, '@', 1)) AS ACCOUNT,
			p_depart_now + p_team_now AS GROUPCODE,
			P.p_name AS NAME,
			ROW_NUMBER() OVER(ORDER BY p_depart_now, p_team_now, CASE WHEN p_position_now = 10 THEN -1 ELSE p_position_now END DESC, p_job_now, CASE WHEN p_rank_now = 10 THEN 24 WHEN p_rank_now = 16 THEN 0 WHEN p_rank_now = 11 THEN 31 ELSE p_rank_now END, krc_in_date) AS SORTORDER,
			p_no AS USERCODE,
			R.R_Name AS GROUPTITLE,
			CASE	WHEN p_position_now IN (6, 8) THEN 'c'  
					WHEN p_position_now IN (4, 5) THEN 'e'
					WHEN p_position_now IN (3) THEN 'h'
			ELSE 'k' END AS ACCESSGRADE,
			CASE	WHEN p_position_now IN (6, 8) THEN '대표이사'  
					WHEN p_position_now IN (4, 5) THEN '임원급'
					WHEN p_position_now IN (3) THEN '그룹장급'
			ELSE '그룹원' END AS GROUPPOSITION,
			S.P_Name AS POSITIONCODE,
			'' AS DESCRIPTION,
			p_user_mail AS EMAIL,
			p_tel3 AS TELEPHONE,
			p_tel2 AS MOBILEPHONE,
			'02-3415-5150' AS FAX,
			'0' AS FLAGACCOUNTLOCK,
			'1' AS FLAGPRIMARY
FROM project2.dbo.Person	 P 
LEFT JOIN project2.dbo.N_Rank R ON P.p_rank_now = R.R_Code AND R.flag = 1
LEFT JOIN project2.dbo.N_Position S ON P.p_position_now = S.P_code AND R.flag = 1
WHERE p_resign = '0' 
AND krc_in_date IS NOT NULL AND ISNULL(krc_out_date, '') = ''
go

