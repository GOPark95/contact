CREATE FUNCTION [dbo].[FN_diff_HHMI]
(
       @ss int
)

RETURNS varchar(50)
AS

BEGIN

       DECLARE @ResultVar varchar(50)
       
       if @ss > 3600
       begin
          set @ss = @ss - 3600
       end
       
       select @ResultVar =
             CONVERT(varchar(10),@ss/3600) + ':'
             + right('0'+CONVERT(varchar(2),(@ss%3600) / 60),2) -- + ':' + right('0'+CONVERT(varchar(2),@ss%60),2) + '초'

       RETURN @ResultVar 

END
go

