
create PROCEDURE dbo.sp_money_dir


       @t_year       int, -- 검색년
       @p_year       int,  -- 이후1년
       @m_year       int, -- 이전1년
                     
       @t_month      varchar(2),  -- 검색월
       @t_table      varchar(50), -- table명
       @t_user      varchar(30)    -- 등록/수정 아이디   



AS
BEGIN
	SET NOCOUNT ON;

	--  프로젝트 직접비
	
	DECLARE @y1 nvarchar(10)	
	DECLARE @y2 nvarchar(10)
	set @y1=convert(char(4),@m_year)+'-'+@t_month+'-01' -- ~부터
	set @y2=convert(char(4),@p_year)+'-'+@t_month+'-31' -- ~까지	
	

	insert into dbo.sales_exp_money (tyear,tmonth,group1,group2,code1,code2,tgubn,exp_yymmdd,exp_title,account1,account2,category1,category2,category3,category4,doc_no,tgubn_code,p_child_sn,cost_money,cost_vat,
	cost_label,cost_text,div_use,edit_date,edit_user) 
	select 
	@t_year,@t_month,
	case when len(convert(nvarchar(20),A.프로젝트코드))=11 then '프로젝트' else '' end as group1, '' as group2,
	case when len(convert(nvarchar(20),A.프로젝트코드))=11 then convert(nvarchar(20),A.프로젝트코드) else '' end as code1, '' as code2,
	A.구분, A.사용일자, A.문서제목, A.계정정보1, A.계정정보2,'' as 구분1,'' as 구분2,'' as 구분3,'단일비용' as 구분4, A.문서번호, 
	A.구분코드, A.프로젝트코드, A.단가, A.부가세, A.라벨, A.전표내용,'1',GETDATE(),@t_user         
    from 
	(
	select 
	'I' as 구분,	 
	convert(nvarchar(10),target3) as 사용일자,
	문서제목,  
	convert(nvarchar(50),target11) as 계정정보1, 
	convert(nvarchar(50),target12) as 계정정보2,	
	문서번호,
	target10 as 프로젝트코드,
	SUBSTRING(문서번호,10,1) as 구분코드,
	
	case when convert(nvarchar(20),target5)='' then '0' else convert(nvarchar(20),target5) end as 단가, 
	case when convert(nvarchar(20),target6)='' then '0' else convert(nvarchar(20),target6) end as 부가세 ,
	target1 as 라벨,'['+convert(nvarchar(1000),isnull(target8,''))+'] '+convert(nvarchar(1000),isnull(target2,'')) as 전표내용
	from dbo.문서내용
	where 문서제목='지출결의서'
 	and convert(nvarchar(10),target3) between @y1 and @y2
-- 	and convert(nvarchar(10),target3) between '2000-01-01' and '3000-01-01'

	and del_yes_no='no' -- 결재중 or 결재완료(no)
	and SUBSTRING(문서번호,10,1)='I'
	) A
	where A.프로젝트코드 is not null
	and A.구분코드='i'
	order by A.사용일자 asc


END
go

