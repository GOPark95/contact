
CREATE PROCEDURE  [dbo].[sp_special_prj_reg]

        @t_year       int, -- 검색년
        @t_month      varchar(2),  -- 검색월

	    @prj_code varchar(20),   -- 프로젝트코드
		@ArrUser  varchar(400),  -- 사원아이디 (", " 구분 ) 배열 순서대로 
		@ArrRate varchar(400), -- 사원할당 비율 (", " 구분 ) 배열 순서대로  
        @t_user      varchar(30)    -- 등록/수정 아이디   
       

AS
BEGIN

	SET NOCOUNT ON

	DECLARE @t_prj_ck int
	set @t_prj_ck=0  -- default

	select top 1 @t_prj_ck=id from dbo.sales_month_result
	where p_child_sn=@prj_code
	and div_use='1'
	and tyear=@t_year
	and tmonth=@t_month

If @t_prj_ck>0
Begin


	-- ######################################################
	-- 이전 임의할당된 데이터가 있는경우 삭제처리
	delete from [dbo].[sales_month_result]
	where p_child_sn=@prj_code
	and part_gubn='임의할당'
	and part_gubn_rate is null


	--  임의변경 프로젝트 div_use  상태변경(999)
	update [dbo].[sales_month_result] set 
	 div_use='999'
	where div_use='1'
	and p_child_sn=@prj_code
	-- ######################################################

	DECLARE @tSQL varchar(max) 
	DECLARE @tSQL_pr varchar(max) 

	DECLARE @t1 varchar(50) 
	DECLARE @t2 varchar(50) 
	DECLARE @r1 varchar(50) 
	DECLARE @r2 varchar(50) 

	set @r1='[NAME]'
	set @r2='[RATE]'

	-- default SQL
	set @tSQL = ''
	set @tSQL = @tSQL + ' INSERT INTO [dbo].[sales_month_result] ([tyear],[tmonth],[tmethod],[tmethod_gubn], '
	set @tSQL = @tSQL + ' [tservice_range],[tservice_label],[p_child_sn],[cost_money],[part_gubn],[part_gubn_rate],'
	set @tSQL = @tSQL + ' [p_no_odr],[p_no],[p_no_rate],[p_no_rate_end],[direct_cost],[div_use],[edit_date],[edit_user]) '
	set @tSQL = @tSQL + ' select '
	set @tSQL = @tSQL + ' tyear, tmonth, tmethod, tmethod_gubn, tservice_range, tservice_label, p_child_sn, cost_money,  '
	set @tSQL = @tSQL + ' ''임의할당'' as part_gubn,  '
	set @tSQL = @tSQL + ' [RATE] as part_gubn_rate, ''1'' as p_no_odr, ''[NAME]'' as p_no, NULL as p_no_rate, '
	set @tSQL = @tSQL + ' 100 as p_no_rate_end, direct_cost, 1 as div_use,  '
	set @tSQL = @tSQL + ' getdate() as edit_date, '''+@t_user+''' as edit_user '
	set @tSQL = @tSQL + ' from [dbo].[sales_month_result] '
	set @tSQL = @tSQL + ' where div_use=''999'' '
	set @tSQL = @tSQL + ' and p_child_sn='''+@prj_code+''' '
	set @tSQL = @tSQL + ' group by tyear,tmonth,tmethod,tmethod_gubn,tservice_range,tservice_label,p_child_sn,cost_money,direct_cost '

	-- 처리
	IF CHARINDEX( ',', @ArrUser ) = 0
		BEGIN
		-- 배열 값이 하나만 있는 경우
		 select @t1=(SUBSTRING(@ArrUser,1,LEN(@ArrUser))),@t2=(SUBSTRING(@ArrRate,1, LEN(@ArrRate)))
		 set @tSQL_pr=replace(replace(@tSQL,@r2,@t2),@r1,@t1)
		 exec (@tSQL_pr)
		
		END
	ELSE
	BEGIN
		WHILE ChARINDEX(',', @ArrUser) <> 0
		BEGIN
			-- 배열 값이 하나 이상인 경우
			 select @t1=(SUBSTRING(@ArrUser,1,CHARINDEX(',',@ArrUser)-1)),@t2=(SUBSTRING(@ArrRate,1,CHARINDEX(',', @ArrRate)-1))
			 set @tSQL_pr=replace(replace(@tSQL,@r2,@t2),@r1,@t1)
			 exec (@tSQL_pr)
		

			SET @ArrUser=SUBSTRING(@ArrUser,CHARINDEX(',',@ArrUser) + 1,LEN(@ArrUser))
			SET @ArrRate=SUBSTRING(@ArrRate,CHARINDEX(',',@ArrRate) + 1,LEN(@ArrRate))

				IF CHARINDEX( ',', @ArrUser ) = 0
				BEGIN
				-- 마지막 루틴..
				select @t1=(SUBSTRING(@ArrUser,1,LEN(@ArrUser))),@t2=(SUBSTRING(@ArrRate,1, LEN(@ArrRate)))
				set @tSQL_pr=replace(replace(@tSQL,@r2,@t2),@r1,@t1)
				exec (@tSQL_pr)
				END
		END
	END



	-- ######################################################
	-- 원본데이터 미사용 처리 
	update [dbo].[sales_month_result] set 
	div_use='0'
	where div_use='999'
	and p_child_sn=@prj_code
	-- ######################################################

end 
END



go

