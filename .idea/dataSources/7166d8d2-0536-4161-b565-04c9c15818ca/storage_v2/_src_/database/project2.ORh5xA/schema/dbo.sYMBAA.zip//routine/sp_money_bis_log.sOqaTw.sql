
create PROCEDURE dbo.sp_money_bis_log


       @t_year       int, -- 검색년
       @p_year       int,  -- 이후1년
       @m_year       int, -- 이전1년
                     
       @t_month      varchar(2),  -- 검색월
       @t_table      varchar(50), -- table명
       @t_user      varchar(30)    -- 등록/수정 아이디   



AS
BEGIN

	SET NOCOUNT ON;

	-- 업무일지_팀_본부_프로젝트비용
	DECLARE @y1 nvarchar(10)	
	DECLARE @y2 nvarchar(10)
	set @y1=convert(char(4),@m_year)+'-'+@t_month+'-01' -- ~부터
	set @y2=convert(char(4),@p_year)+'-'+@t_month+'-31' -- ~까지	
	
		-- #Table에 insert
		insert into dbo.sales_exp_money (tyear,tmonth,group1,group2,code1,code2,tgubn,exp_yymmdd,exp_title,account1,account2,category1,category2,category3,category4,doc_no,
		tgubn_code,p_child_sn,cost_money,cost_vat,cost_label,cost_text,div_use,edit_date,edit_user) 
		select 
		@t_year,@t_month,
		case when A.프로젝트코드='99999' then '일반' else isnull(convert(nvarchar(10),B.구분4),'프로젝트') end as group1,
		case when isnull(convert(nvarchar(10),B.구분4),'프로젝트') in ('팀','본부') then isnull(B.구분3,'') else '' end as group2,	
		case when isnull(convert(nvarchar(10),B.구분4),'프로젝트')='프로젝트' then convert(nvarchar(20),A.프로젝트코드) else convert(nvarchar(20),isnull(B.구분1,'')) end as code1,
		case when isnull(convert(nvarchar(10),B.구분4),'프로젝트') in ('팀','본부') then convert(nvarchar(20),isnull(B.구분2,'')) else '' end as code2,			
		'M' as 구분,
		A.업무일자 as 사용일자,
		'업무일지' as 문서제목,
		A.업무코드 as 계정정보1, 
		A.비용코드 as 계정정보2,
		isnull(convert(nvarchar(10),B.구분4),'프로젝트') as 구분_1,
		isnull(B.구분2,'') as 구분_2,
		isnull(B.구분1,'') as 구분_3,
		isnull(B.구분3,'') as 구분_4,
		'업무일지' as 문서번호,
		'M' as 구분코드,
		A.프로젝트코드,		
		A.등록금액 as 단가,		
		0 as 부가세,
		A.업무일지제목 as 라벨,	
		A.업무내용 as 전표내용,
		'1',GETDATE(),@t_user
		FROM 
		(
			SELECT 	
			job_date as 업무일자,
			p_sn as 프로젝트코드,
			p_subject  as 업무일지제목,  
			job_code as 업무코드,
			job_name as 업무내용,			
			cost_code as 비용코드,	
			cost_money as 등록금액
			-- *
			FROM cost_account 
			where cost_money>0
			and convert(nvarchar(10),job_date) between @y1 and @y2
--			and convert(nvarchar(10),job_date) between '2000-01-01' and '3000-01-01'
			
		) A
		left join 
		(
			-- 본부/팀 정보
			select X.ht_cd as 구분1, X.tgubn as 구분2, X.tname as 구분3, X.tgubn_label as 구분4 from 
			(
				select hd_cd2 as ht_cd, hd_cd as tgubn,hd_name as tname,'본부' as tgubn_label from dbo.TEAM_GROUP
				where hd_cd2<>''
				group by hd_cd2, hd_cd,hd_name
				union 
				select
				9999000+CONVERT(int,team_cd)as ht_cd,
				team_cd as tgubn,
				team_name as tname,
				'팀' as tgubn_label
				from dbo.TEAM_GROUP
				where team_cd>0
				group by team_cd,team_name

			) X
			group by X.ht_cd, X.tgubn, X.tname, X.tgubn_label
			having X.tgubn>0
		) B
		on A.프로젝트코드=convert(nvarchar(15),B.구분1)
		order by A.업무일자 asc 
		



END
go

