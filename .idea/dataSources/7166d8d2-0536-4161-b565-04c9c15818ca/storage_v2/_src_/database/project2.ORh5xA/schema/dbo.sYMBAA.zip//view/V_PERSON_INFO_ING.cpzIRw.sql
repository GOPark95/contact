
CREATE VIEW dbo.V_PERSON_INFO_ING
AS

SELECT  P.p_name, P.p_no, isnull(P.career,0)+isnull(P.career_ing,0) as career, P.Sex, P.grade, T.hd_name, T.hd_cd
FROM     (SELECT  p_no, p_name, 
                               CASE WHEN p_depart = '0' THEN CASE WHEN p_no = '20000201' THEN '41' WHEN p_no = '20140702' THEN
                                '42' WHEN p_no = '20160603' THEN '43' ELSE '0' END ELSE p_depart END AS p_depart, 
                               CASE WHEN SubString(dbo.Jumin_Decode(jumin), 8, 1) % 2 = 1 THEN '남성' ELSE '여성' END AS Sex, 
                               CASE WHEN edu_end_chk_5 <> '' THEN '박사' ELSE CASE WHEN edu_end_chk_4 <> '' THEN '석사' ELSE
                                CASE WHEN edu_end_chk_3 <> '' THEN '학사' ELSE CASE WHEN edu_end_chk_2 <> '' THEN '전문학사'
                                ELSE '고졸' END END END END AS grade, CONVERT(int, 
                               CASE WHEN career_year_sum = '' THEN 0 ELSE career_year_sum END) + 1 AS career,
							   CASE WHEN DATEDIFF(month,krc_in_date,getdate())>0 then 
							   DATEDIFF(month,krc_in_date,getdate())/12 else 0 end as career_ing

                FROM     dbo.person
                WHERE  (p_resign = 0) AND (p_ip IS NOT NULL) AND (p_pos NOT IN ('31', '32', '98', '999'))) 
               AS P LEFT OUTER JOIN
                   (SELECT  hd_cd, team_cd, hd_name
                    FROM     dbo.TEAM_GROUP
                    WHERE  (div_use = '1')
                    UNION ALL
                    SELECT  hd_cd, hd_cd AS team_cd, hd_name AS team_name
                    FROM     dbo.TEAM_GROUP AS TEAM_GROUP_1
                    WHERE  (hd_cd BETWEEN '41' AND '50')
                    GROUP BY hd_cd, hd_name) AS T ON P.p_depart = T.team_cd


go

