
create View V_Vacation_Cnt as
select p_no, p_name, sum(cast(b.[used_cnt] as float)) as [used_cnt] from person as a
left join
(
	select j_p_no, j_name, j_date, case when j_detail_code='8' then '1' when j_detail_code='10' then '0.5'when j_detail_code='11' then '0.5' end as [used_cnt] from job
	where j_detail_code in ('8','10','11')
) as b on a.p_no=b.j_p_no and a.p_name=b.j_name
where a.krc_out_date='' and a.krc_in_date is not null
and b.j_date >
(
	case
	when a.krc_in_type_1 like '%경력%' Then
		case
		--0년차
		when Datediff(day,convert(date,a.krc_in_date),getdate()) < 365 then convert(Date, a.krc_in_date)
		Else
			case when left(convert(date,getdate()),5)>'03-01' Then left(convert(date,getdate()),4)+'-03-01'
			else left(DATEADD(Year,-1,convert(date,getdate(),23)),4)+'-03-01'
			end
		End
	Else
		case
		--0년차
		when Datediff(day,convert(date,a.krc_in_date),getdate()) < 365 then convert(Date, a.krc_in_date)
		--1년차
		when Datediff(day,convert(date,a.krc_in_date),getdate()) between 365 and 730 then DATEADD(Year,1,convert(date,a.krc_in_date,23))
		--2년차
		when Datediff(day,convert(date,a.krc_in_date),getdate()) between 730 and 1095 then left(DATEADD(Year,0,convert(date,getdate(),23)),4)+'-'+right(convert(Date, a.krc_in_date),5)
		Else
			case when left(convert(date,getdate()),5)>'03-01' Then left(convert(date,getdate()),4)+'-03-01'
			else left(DATEADD(Year,-1,convert(date,getdate(),23)),4)+'-03-01'
			end
		End
	End
	
)
and b.j_date <=
(
	case
	when a.krc_in_type_1 like '%경력%' Then
		case
		--0년차
		when Datediff(day,convert(date,a.krc_in_date),getdate()) < 365 then DATEADD(Year,1,convert(date,a.krc_in_date,23))
		Else
			case when left(convert(date,getdate()),5) > '03-01' Then left(DATEADD(Year,1,convert(date,getdate(),23)),4)+'-02-28'
			else left(convert(date,getdate()),4)+'-02-28'
			end
		End
	Else
		case
		--0년차
		when Datediff(day,convert(date,a.krc_in_date),getdate()) < 365 then DATEADD(Year,1,convert(date,a.krc_in_date,23))
		--1년차
		when Datediff(day,convert(date,a.krc_in_date),getdate()) between 365 and 730 then DATEADD(Year,2,convert(date,a.krc_in_date,23))
		--2년차
		when Datediff(day,convert(date,a.krc_in_date),getdate()) between 730 and 1095 then
			case 
				--2년차인데 입사일이 03-01 이전인경우
				when right(convert(Date, a.krc_in_date),5) < '03-01' Then left(convert(date,getdate()),4)+'-02-28'
				Else left(DATEADD(Year,1,convert(date,getdate(),23)),4)+'-02-28'
			End
		Else
			case when left(convert(date,getdate()),5) > '03-01' Then left(DATEADD(Year,1,convert(date,getdate(),23)),4)+'-02-28'
			else left(convert(date,getdate()),4)+'-02-28'
			end
		End
	End
	
)
group by p_no, p_name
go

