

CREATE FUNCTION dbo.MCAL(@ym VARCHAR(7))
RETURNS @TB TABLE
(  
   ymd VARCHAR(10) PRIMARY KEY
) AS
BEGIN
	INSERT INTO @TB
	SELECT @ym + '-' + RIGHT('0'+CONVERT(varchar(2), [number]), 2) AS ymd
	FROM master..spt_values
	WHERE type = 'P' 
	AND [number]  BETWEEN 1 AND 31
	AND ISDATE(@ym + '-' +  RIGHT('0'+CONVERT(varchar(2), [number]), 2)) = 1

	RETURN
END
go

