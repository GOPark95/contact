

create VIEW V_Cati_Count
as
select PP.intranet_project, PP.p_subject, s_client, s_client_name, s_date, s_time, s_oktelno, CS.prj_code, PP.prj_name from new_cati.dbo.sheet1 CS
left join
(
	select CT.intranet_project, PT.p_subject, CT.prj_name, CT.prj_code from new_cati.dbo.project CT WITH(NOLOCK) 
	left join
	(
		select p_child_sn,p_subject from project2.dbo.T_PROJECT_METHOD WITH(NOLOCK)
		where p_child_sn is not null
	) PT on CT.intranet_project=PT.p_child_sn
	WHERE CT.intranet_project IS NOT NULL
) as PP on CS.prj_code=PP.prj_code
where CS.s_client not in ('0','15254','15632')
go

