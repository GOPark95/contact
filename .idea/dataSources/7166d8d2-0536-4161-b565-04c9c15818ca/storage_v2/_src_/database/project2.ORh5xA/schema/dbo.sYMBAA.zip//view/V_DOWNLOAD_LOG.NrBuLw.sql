-- DROP VIEW dbo.V_DOWNLOAD_LOG;
CREATE VIEW dbo.V_DOWNLOAD_LOG AS
-- 다운로드 로그
SELECT 	VP.p_team_name, VP.p_name, DL.d_date AS down_date, 
			CD.c_code_name AS file_category, SA.f_file_name AS file_name,
			ISNULL(T_Name, '기타') AS p_depart, SA.f_p_sn AS p_sn, PB.p_subject
FROM project2.dbo.T_DOWN_LOG DL LEFT JOIN 
project2.dbo.T_SYSTEM_ATTACH SA ON DL.f_id = SA.f_id
LEFT JOIN project2.dbo.V_Person VP ON DL.d_user_no = VP.p_no
LEFT JOIN project2.dbo.T_COMMON_CODE_DETAIL CD ON CD.c_kind_code = '001' AND SA.f_kind = CD.c_common_code
LEFT JOIN project2.dbo.V_PROJECT PB ON SA.f_p_sn = PB.p_sn
LEFT JOIN project2.dbo.N_Depart_Team DT ON PB.p_depart_dep = DT.before_t_cd1 AND (DT.T_Name = '파트너' OR D_Code = 'R')
WHERE DL.d_date > '2019-01-01' AND PB.p_sn IS NOT NULL;
go

