
CREATE FUNCTION dbo.fn_p_category_split(
   @value varchar(30)
 )
 RETURNs varchar(150)
 AS 
 BEGIN
     DECLARE @sum_comm varchar(200)
        
       SELECT  @sum_comm = STRING_AGG(spl_str2,',') --, STRING_AGG(spl_str,',') 
         FROM ( 
        SELECT trim(@value) AS origin
             , ( CASE 
                    WHEN replace(value,',','') = 1  then '고객만족도'
                    WHEN replace(value,',','') = 2  then 'A&U/실태조사'
                    WHEN replace(value,',','') = 3  then '광고효과'
                    WHEN replace(value,',','') = 4  then '컨셉테스트'
                    WHEN replace(value,',','') = 5  then '제품력'
                    WHEN replace(value,',','') = 6  then '수요예측'
                    WHEN replace(value,',','') = 7  then '기업이미지'
                    WHEN replace(value,',','') = 8  then '판매/유통'
                    WHEN replace(value,',','') = 9  then '행정서비스'
                    WHEN replace(value,',','') = 10 then '정치/사회현안'
                    WHEN replace(value,',','') = 11 then '선거여론'
                    WHEN replace(value,',','') = 12 then '정책관련'
                    WHEN replace(value,',','') = 13 then '청렴도'
                    WHEN replace(value,',','') = 14 then '브랜드진단'
                    WHEN replace(value,',','') = 15 then 'Segmentation'
                    WHEN replace(value,',','') = 16 then 'Positioning'
                    WHEN replace(value,',','') = 17 then '신제품개발'
                    WHEN replace(value,',','') = 18 then '디자인/UI테스트'
                    WHEN replace(value,',','') = 19 then '기타'
                 ELSE replace(value,',','')
                  end)AS spl_str2
             , replace(value,',','') AS spl_str 
          FROM STRING_SPLIT(trim(@value), ' ')
    ) AA 
    GROUP BY origin
     
     
   RETURN @sum_comm
END
go

