
CREATE VIEW V_CLIENT_COMP
AS
SELECT 
p_cli_company_cd			,
p_cli_company_nm			,
p_cli_company_yn	,
p_input_dt			,
 ''	as	c_type	
FROM T_CLIENT_COMP

union all
  
select c_code	as	p_cli_company_cd	,
c_name	as	p_cli_company_nm	,
 ''	AS	p_cli_company_yn	,
 ''	AS	p_input_dt	,
c_type 
from client
go

