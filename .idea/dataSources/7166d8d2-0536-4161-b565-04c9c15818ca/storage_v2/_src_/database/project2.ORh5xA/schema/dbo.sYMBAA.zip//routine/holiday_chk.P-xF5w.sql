Create   FUNCTION dbo.holiday_chk(
                @Current_day    VARCHAR(10)
    )
    returns varchar(1)
AS
BEGIN
	DECLARE @ReturnVal varchar(1)
	
	DECLARE @pYear int
	DECLARE @pMonth int
	DECLARE @pDay int
	
	DECLARE @Current_dayL VARCHAR(10)
	
	DECLARE @pYearL int
	DECLARE @pMonthL int
	DECLARE @pDayL int
	
	SET @Current_day = Replace(@Current_day, '-', '')
	
	SET @pYear = CONVERT(int, LEFT(@Current_day, 4))
	SET @pMonth = CONVERT(int, SUBSTRING(@Current_day, 5,2))
	SET @pDay = CONVERT(int, RIGHT(@Current_day, 2))
	
	SELECT @Current_dayL = dbo.LunarToSolar_F(@Current_day,1)
	
	SET @pYearL = CONVERT(int, LEFT(@Current_dayL, 4))
	SET @pMonthL = CONVERT(int, SUBSTRING(@Current_dayL, 5,2))
	SET @pDayL = CONVERT(int, RIGHT(@Current_dayL, 2))
	
	BEGIN
	SELECT @ReturnVal = CASE WHEN DATEPART(DW, @Current_day) IN (1, 7) THEN 1 ELSE CASE WHEN Count(*) = 1 THEN 1 ELSE 0 END END 
	FROM project2.dbo.공휴일 
	WHERE 
		(양력여부 = '1' 
			AND (
				(년 = 0 AND 월 = @pMonth AND 일 = @pDay) OR
				(년 = @pYear AND 월 = @pMonth AND 일 = @pDay)
			)
		) OR
		(양력여부 = '2' 
			AND (
				(년 = 0 AND 월 = @pMonthL AND 일 = @pDayL) OR
				(년 = @pYearL AND 월 = @pMonthL AND 일 = @pDayL)
			)
		)
	END
	Return @ReturnVal
END;
go

