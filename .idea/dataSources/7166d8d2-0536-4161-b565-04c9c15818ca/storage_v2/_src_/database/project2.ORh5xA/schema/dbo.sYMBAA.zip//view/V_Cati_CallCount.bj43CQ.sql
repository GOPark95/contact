
create View dbo.V_Cati_CallCount
as
select log_user, log_user_name, log_user_jumin, prj_code, log_date, first_call, Last_call, isnull(in_time,'1000') as in_time, isnull(out_time,'1800') as out_time,
isnull([완료],0) as [완료], isnull([err_cnt],0) as [에러], isnull([중단],0) as [중단], isnull([쿼터오버],0) as [쿼터오버], isnull([거절],0) as [거절],
isnull([대상자아님],0) as [대상자아님], isnull([결번],0) as [결번], isnull([비수신],0) as [비수신], isnull([통화중],0) as [통화중], isnull([부재중],0) as [부재중] from
(
 select LG.*, NIO.in_time, NIO.out_time, LGc.first_call, LGc.Last_call, SS.err_cnt from
	(
	select log_user, log_user_name, log_user_jumin, prj_code, log_date,
	case 
		when log_stat in ('1') then '완료'
		when log_stat in ('11','20') then '중단'
		when log_stat in ('4') then '쿼터오버'
		when log_stat in ('5','15','16','99') then '거절'
		when log_stat in ('12') then '대상자아님'
		when log_stat in ('3','10') then '결번'
		when log_stat in ('2') then '비수신'
		when log_stat in ('7') then '통화중'
		when log_stat in ('6','9','19') then '부재중'
	end as log_stat, count(log_user) as log_cnt
	from new_cati.dbo.logfile
	where (log_etc not in ('RESET','CHANGE') or log_user not in ('0','15254','15632'))
	group by log_user, log_user_name, log_user_jumin, prj_code, log_date, log_stat
	) PV
	Pivot
	(
		sum(log_cnt) for log_stat in ([완료],[중단],[쿼터오버],[거절],[대상자아님],[결번],[비수신],[통화중],[부재중])
	) LG -- logfile counting Table
	left join
	(
		select neakeun_name, date, in_time, out_time, m_id
		from project2.dbo.neakeun_in_out_time
	) as NIO on NIO.m_id=LG.log_user and NIO.date=LG.log_date -- man in_out Table
	left join
	(
		select log_user, log_date, prj_code, min(log_st_time) as first_call, max(log_st_time) as Last_call 
		from new_cati.dbo.logfile
		where (log_etc not in ('RESET','CHANGE') or log_user not in ('0','15254','15632'))
		group by log_user, log_date, prj_code
	) as LGc on LGc.log_user=LG.log_user and LGc.prj_code=LG.prj_code and LGc.log_date=LG.log_date -- Call first, Last Table
	left join
	(
		select s_client, prj_code, s_date, chk, count(chk) as err_cnt from new_cati.dbo.sheet1_send where chk='4'
		group by s_client, prj_code, s_date, chk
	) as SS on SS.s_client=LG.log_user and SS.prj_code=LG.prj_code and SS.s_date=LG.log_date -- Error counting Table
) as T
go

