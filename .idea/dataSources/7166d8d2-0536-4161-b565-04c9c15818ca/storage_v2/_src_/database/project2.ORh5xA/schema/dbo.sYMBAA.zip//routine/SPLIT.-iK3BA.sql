-- made by nanababo007@naver.com
CREATE FUNCTION [dbo].[SPLIT]
(
  @P_STR VARCHAR(4000)
 ,@P_PART VARCHAR(200)
 ,@P_LOC INT = 1
)
RETURNS VARCHAR(4000)
AS
BEGIN
 
 DECLARE @I INT;
 DECLARE @J INT;
 DECLARE @K INT;
 
 DECLARE @V_STR_LEN INT;
 DECLARE @V_PART_LEN INT;
 
 IF @P_STR IS NULL OR @P_STR = '' BEGIN
  RETURN '';
 END
 
 IF @P_PART IS NULL OR @P_PART = '' BEGIN
  RETURN '';
 END

 IF @P_LOC < 1 BEGIN
  RETURN '';
 END
 
 SET @P_STR = @P_STR + @P_PART;
 SET @V_STR_LEN = LEN(@P_STR);
 SET @V_PART_LEN = LEN(@P_PART);
 
 

 SET @I = 1;
 SET @J = 0;
 SET @K = 0;

 WHILE @I > 0 BEGIN
  SET @K = @I; -- 이전위치

  IF @I = 1 BEGIN
   SET @I = CHARINDEX(@P_PART,@P_STR,1);
  END ELSE BEGIN
   SET @I = CHARINDEX(@P_PART,@P_STR,@I+1);
  END

  IF @I <> 0 BEGIN
   SET @J = @J + 1;

   IF @P_LOC = @J BEGIN
    IF @K = 1 BEGIN
     RETURN SUBSTRING(@P_STR, 1, @I-1);
    END ELSE BEGIN
	    
	    --자를 문자수가 0보다 작으면 '' 리턴
	    IF ( @I-(@K+@V_PART_LEN) ) <= 0 
	    BEGIN
		    RETURN ''
	    END
	    ELSE
	    BEGIN
            RETURN SUBSTRING(@P_STR, @K+@V_PART_LEN, @I-(@K+@V_PART_LEN));
	    END
     --RETURN SUBSTRING(@P_STR, @K+@V_PART_LEN, @I-(@K+@V_PART_LEN));
    END

    BREAK;
   END
  END
 END
 
 RETURN '';
 
END

go

