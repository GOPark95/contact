CREATE FUNCTION dbo.M_GRADE_COST
(
	@m_id NUMERIC(18, 0), 
	@cDate VARCHAR(10), 
	@sebu VARCHAR(10)
)
RETURNS VARCHAR(20)
AS 
BEGIN 
	DECLARE @cost VARCHAR(30)
	
	SELECT TOP 1 @cost = cost 
	FROM t_neakeun_pay_COST
	WHERE grade = (
		SELECT TOP 1 m_grade
		FROM T_MYUN_GRADE_HISTORY
		WHERE m_id = @m_id 
		AND ISNULL(attribute02, @sebu) = @sebu
		AND m_grade_dt <= @cDate 
		ORDER BY m_grade_dt DESC, insert_dt DESC
	) AND [type] = 'cost' 
	AND use_start_dt <= @cDate
	ORDER BY use_start_dt DESC
	
	RETURN @cost;
END;
go

