CREATE FUNCTION dbo.VAC_USE (@p_no varchar(8), @s_date varchar(10))
RETURNS float
AS 
BEGIN
	DECLARE @krc_in_date AS varchar(10);
	DECLARE @s_year AS int;
	DECLARE @gap_day AS int;
	DECLARE @tmp_plus AS int;
	DECLARE @use_cnt AS float;
	DECLARE @st_date AS varchar(10);	
	DECLARE @ed_date AS varchar(10);

	SELECT @s_date = CONVERT(varchar(10), CONVERT(date, @s_date), 120);	

	SELECT @krc_in_date = krc_in_date FROM project2.dbo.person WHERE p_no = @p_no;
	SET @s_year = CONVERT(int, LEFT(@s_date, 4));
	SELECT @s_year = CASE WHEN CONVERT(varchar(4), @s_year) + '-04-01' <= @s_date THEN @s_year + 1 ELSE @s_year END;
	SET @gap_day = DateDiff(DAY, CONVERT(date, @krc_in_date), CONVERT(date, @s_date));
	SELECT @tmp_plus = CASE WHEN RIGHT(@krc_in_date, 5) < '04-01' THEN 2 ELSE 3 END;
	
	SELECT @st_date = CASE
		--0년차
		WHEN @gap_day <= 365 THEN CONVERT(date, @krc_in_date)
		--1년차
		WHEN @gap_day BETWEEN 366 AND 730 THEN DATEADD(YEAR, 1, CONVERT(date, @krc_in_date, 23))
		--2년차
		WHEN @gap_day > 730 AND @s_date < CONVERT(varchar(4), CONVERT(int, LEFT(@krc_in_date, 4)) + @tmp_plus) + '-04-01' THEN DATEADD(YEAR, 2, CONVERT(date, @krc_in_date, 23))
		ELSE 	
			CASE WHEN CONVERT(varchar(4), @s_year) <= '2020' THEN
				CONVERT(varchar(4), @s_year-1) + '-03-01'
			ELSE
				CONVERT(varchar(4), @s_year-1) + '-04-01'
			END
		END;
	SELECT @ed_date = CASE
		--0년차
		WHEN @gap_day <= 365 THEN DATEADD(YEAR, 1, CONVERT(date, @krc_in_date, 23))
		--1년차
		WHEN @gap_day BETWEEN 366 AND 730 THEN DATEADD(YEAR, 2, CONVERT(date, @krc_in_date, 23))
		--2년차
		WHEN @gap_day > 730 AND @s_date < CONVERT(varchar(4), CONVERT(int, LEFT(@krc_in_date, 4)) + @tmp_plus) + '-04-01' THEN CONVERT(varchar(4), @s_year) + '-04-01'
		ELSE
			CASE WHEN CONVERT(varchar(4), @s_year) < '2020' THEN
				CONVERT(varchar(4), @s_year) + '-03-01'
			ELSE
				CONVERT(varchar(4), @s_year) + '-04-01'
			END
		END;
	

	SELECT @use_cnt = ISNULL(sum(CASE WHEN j_contents=8 THEN 1 
				WHEN j_contents IN (10, 11) THEN 0.5 END), 0) 
	FROM project2.dbo.V_Job_List
	WHERE j_contents IN (8,10,11)
	AND p_no = @p_no
	AND j_date >= @st_date AND j_date < @ed_date;
	
	SELECT @use_cnt = @use_cnt + ISNULL(SUM(CASE WHEN RIGHT(CONVERT(varchar(20), target3), 2) = '반차' 
						THEN 0.5 
						ELSE  
							CASE WHEN CONVERT(varchar(20), target3) = '연차 휴가' THEN
								dbo.holiday_cnt(CONVERT(varchar(10), target1), CONVERT(varchar(10), target2))
							ELSE 0
							END 
						END
					), 0)
	FROM project2.dbo.문서내용 M LEFT JOIN project2.dbo.Document D 
	ON M.문서번호 = D.d_no
	WHERE 문서번호 > 'KRC-2019' AND 문서제목 = '휴가원' AND del_yes_no = 'no' AND login_p_no = @p_no AND d_orders <> @p_no
	AND CONVERT(varchar(10), target1) >= @st_date 
	AND CONVERT(varchar(10), target1) < @ed_date;
	
	RETURN @use_cnt;
END;

go

