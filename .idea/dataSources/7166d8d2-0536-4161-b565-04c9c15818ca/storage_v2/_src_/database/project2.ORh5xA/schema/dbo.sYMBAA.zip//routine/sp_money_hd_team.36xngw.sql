
CREATE PROCEDURE [dbo].[sp_money_hd_team]


       @t_year       int, -- 검색년
       @p_year       int,  -- 이후1년
       @m_year       int, -- 이전1년
                     
       @t_month      varchar(2),  -- 검색월
       @t_table      varchar(50), -- table명
       @t_user      varchar(30)    -- 등록/수정 아이디   



AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;


	 --  본부/팀/ 일반 비용
	DECLARE @y1 nvarchar(10)	
	DECLARE @y2 nvarchar(10)
	
/*	
	set @y1=convert(char(4),@m_year)+'-'+@t_month+'-01' -- ~부터
	set @y2=convert(char(4),@p_year)+'-'+@t_month+'-31' -- ~까지	
*/
    -- 해당월만 가져옮
	set @y1=convert(char(4),@t_year)+'-'+@t_month+'-01' -- ~부터 
	set @y2=convert(char(4),@t_year)+'-'+@t_month+'-31' -- ~까지	
	
	

	insert into dbo.sales_exp_money (tyear,tmonth,group1,group2,code1,code2,tgubn,exp_yymmdd,exp_title,account1,account2,category1,category2,category3,category4,doc_no,tgubn_code,p_child_sn,cost_money,cost_vat,cost_label,cost_text,div_use,edit_date,edit_user) 
	select
	@t_year,@t_month,
	case when AA.구분4='' and AA.프로젝트코드='99999' then '일반' else AA.구분4 end as group1,
	구분3 as group2, 
	case when AA.구분4='' and AA.프로젝트코드='99999' then AA.프로젝트코드 else AA.구분1 end as code1,
	case when AA.구분2='0' or AA.구분2 is null  then '' else convert(nvarchar(20),AA.구분2) end as code2,
	AA.구분,AA.사용일자,AA.문서제목,AA.계정정보1,AA.계정정보2,AA.구분1,AA.구분2,AA.구분3, 
	case when AA.구분4='' and AA.프로젝트코드='99999' then '일반접대비' else AA.구분4 end as 구분4,
	AA.문서번호,AA.구분코드,AA.프로젝트코드,AA.단가,AA.부가세,AA.라벨,AA.전표내용,'1',GETDATE(),@t_user
	from 
	(
			select
			isnull(B.구분1,'') as 구분1, isnull(B.구분2,'') as 구분2, isnull(B.구분3,'') as 구분3, isnull(B.구분4,'') as 구분4, 
			A.*
			from 
			(
			select
			SUBSTRING(문서번호,10,1) as 구분,
			convert(nvarchar(10),target3) as 사용일자, 
			문서제목, '' as 계정정보1, '' as 계정정보2, 
			문서번호,
			SUBSTRING(문서번호,10,1) as 구분코드,
			p_sn as 프로젝트코드,
			convert(nvarchar(15),target4) as 단가,
			case when convert(nvarchar(20),target5)='' then '0' else convert(nvarchar(10),target5) end as 부가세,
			target1 as 라벨,
			target2 as 전표내용
			from dbo.문서내용
			where 문서제목='접대비보고서'
			and del_yes_no='no' -- 결재중 or 결재완료(no)			
			and convert(nvarchar(10),target3) between @y1 and @y2
--			and convert(nvarchar(10),target3) between '2000-01-01' and '3000-12-33'
			and left(p_sn,4)>=9999
			) A
			left join 
			(
				-- 본부/팀 정보
				select X.ht_cd as 구분1, X.tgubn as 구분2, X.tname as 구분3, X.tgubn_label as 구분4 from 
				(
					select hd_cd2 as ht_cd, hd_cd as tgubn,hd_name as tname,'본부' as tgubn_label from dbo.TEAM_GROUP
					where hd_cd2<>''
					group by hd_cd2, hd_cd,hd_name
					union 
					select
					9999000+CONVERT(int,team_cd)as ht_cd,
					team_cd as tgubn,
					team_name as tname,
					'팀' as tgubn_label
					from dbo.TEAM_GROUP
					where team_cd>0
					group by team_cd,team_name

				) X
				group by X.ht_cd, X.tgubn, X.tname, X.tgubn_label
				having X.tgubn>0
			) B
			on A.프로젝트코드=B.구분1
	) AA


END
go

