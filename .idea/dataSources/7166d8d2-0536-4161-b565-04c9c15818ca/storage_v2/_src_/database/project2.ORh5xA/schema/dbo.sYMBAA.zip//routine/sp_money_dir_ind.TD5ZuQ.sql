
create PROCEDURE dbo.sp_money_dir_ind

		--  본부/팀/ 일반 접대비
		
       @t_year       int, -- 검색년
       @p_year       int,  -- 이후1년
       @m_year       int, -- 이전1년
                     
       @t_month      varchar(2),  -- 검색월
       @t_table      varchar(50), -- table명
       @t_user      varchar(30)    -- 등록/수정 아이디   


AS
BEGIN

	SET NOCOUNT ON;

	DECLARE @y1 nvarchar(10)	
	DECLARE @y2 nvarchar(10)
	set @y1=convert(char(4),@m_year)+'-'+@t_month+'-01' -- ~부터
	set @y2=convert(char(4),@p_year)+'-'+@t_month+'-31' -- ~까지	

	DECLARE @문서번호 nvarchar(20)
	DECLARE @문서제목 nvarchar(30)	
	DECLARE @사용일자 nvarchar(10)
	
	DECLARE @계정정보1 nvarchar(50)
	DECLARE @계정정보2 nvarchar(50)
		
	DECLARE @구분코드 char(1)
	DECLARE @내용 nvarchar(max)
	DECLARE @분리2 nvarchar(max)
	DECLARE @t1 nvarchar(30),@t2 money,@t3 money,@t4 money,@t5 nvarchar(max)

	DECLARE @group1 nvarchar(40), @code1 nvarchar(40)	
	DECLARE @group2 nvarchar(40), @code2 nvarchar(40)		

	DECLARE cur_step1 CURSOR FOR
	select 
	A.문서번호, A.문서제목, A.사용일자, A.계정정보1, A.계정정보2, A.구분코드, A.target_all 
	from
	(
		select 
		문서번호, 문서제목,  
		convert(nvarchar(10),target3) as 사용일자,
		convert(nvarchar(50),target11) as 계정정보1, 
		convert(nvarchar(50),target12) as 계정정보2,
		SUBSTRING(문서번호,10,1) as 구분코드,
		replace(convert(nvarchar(1000),isnull(target21,'')),'¿','')+'¿'+replace(convert(nvarchar(1000),isnull(target22,'')),'¿','')+'¿'+replace(convert(nvarchar(1000),isnull(target23,'')),'¿','')+'¿'+replace(convert(nvarchar(1000),isnull(target24,'')),'¿','')+'¿'+replace(convert(nvarchar(1000),isnull(target25,'')),'¿','')+'¿'+
		replace(convert(nvarchar(1000),isnull(target26,'')),'¿','')+'¿'+replace(convert(nvarchar(1000),isnull(target27,'')),'¿','')+'¿'+replace(convert(nvarchar(1000),isnull(target28,'')),'¿','')+'¿'+replace(convert(nvarchar(1000),isnull(target29,'')),'¿','')+'¿'+replace(convert(nvarchar(1000),isnull(target30,'')),'¿','')+'¿'+
		replace(convert(nvarchar(1000),isnull(target31,'')),'¿','')+'¿'+replace(convert(nvarchar(1000),isnull(target32,'')),'¿','')+'¿'+replace(convert(nvarchar(1000),isnull(target33,'')),'¿','')+'¿'+replace(convert(nvarchar(1000),isnull(target34,'')),'¿','')+'¿'+replace(convert(nvarchar(1000),isnull(target35,'')),'¿','')+'¿'+
		replace(convert(nvarchar(1000),isnull(target36,'')),'¿','')+'¿'+replace(convert(nvarchar(1000),isnull(target37,'')),'¿','')+'¿'+replace(convert(nvarchar(1000),isnull(target38,'')),'¿','')+'¿'+replace(convert(nvarchar(1000),isnull(target39,'')),'¿','')+'¿'+replace(convert(nvarchar(1000),isnull(target40,'')),'¿','')+'¿'+
		replace(convert(nvarchar(1000),isnull(target41,'')),'¿','')+'¿'+replace(convert(nvarchar(1000),isnull(target42,'')),'¿','')+'¿'+replace(convert(nvarchar(1000),isnull(target43,'')),'¿','')+'¿'+replace(convert(nvarchar(1000),isnull(target44,'')),'¿','')+'¿'+replace(convert(nvarchar(1000),isnull(target45,'')),'¿','')+'¿'+
		replace(convert(nvarchar(1000),isnull(target46,'')),'¿','')+'¿'+replace(convert(nvarchar(1000),isnull(target47,'')),'¿','')+'¿'+replace(convert(nvarchar(1000),isnull(target48,'')),'¿','')+'¿'+replace(convert(nvarchar(1000),isnull(target49,'')),'¿','')+'¿'+replace(convert(nvarchar(1000),isnull(target50,'')),'¿','')+'¿' 
		as target_all 
		from dbo.문서내용
		where 문서제목='지출결의서'
		and convert(nvarchar(10),target3) between @y1 and @y2	
--		and convert(nvarchar(10),target3) between '2000-01-01' and '3000-01-01'
		and del_yes_no='no' -- 결재중 or 결재완료(no)
	) A
	where A.구분코드='A'
	order by A.사용일자 asc

	OPEN cur_step1
	FETCH NEXT FROM cur_step1 INTO @문서번호, @문서제목, @사용일자, @계정정보1, @계정정보2, @구분코드, @내용
	WHILE @@FETCH_STATUS = 0
	BEGIN
		----------------------(2)------------------------------------------------
		DECLARE cur_step2 CURSOR FOR		
		SELECT VAL1 FROM  dbo.[FN_SPLIT](@내용,'¿')
		where len(VAL1)>0
		OPEN cur_step2
		FETCH NEXT FROM cur_step2 INTO @분리2
		WHILE @@FETCH_STATUS = 0
		BEGIN
			----------------------(3)------------------------------------------------
			DECLARE cur_step3 CURSOR FOR		
			select [1] as t1,[2] as t2,[3] as t3,[4] as t4,[5] as t5 from (
				select A.POS, A.VAL1 from dbo.[FN_SPLIT](
				(SELECT VAL1 as a FROM  dbo.[FN_SPLIT](replace(@분리2,'^//^','¿'),'^^') where pos='2'),'¿') A
			) B
			pivot
			(max(B.val1) for B.POS in ([1],[2],[3],[4],[5])) C
			OPEN cur_step3
			
			FETCH NEXT FROM cur_step3 INTO @t1,@t2,@t3,@t4,@t5
			WHILE @@FETCH_STATUS = 0
			BEGIN 
			
			set @group1=''	
			set @group2=''	
			set @code1=''
			set @code2=''
					
			if len(@t1)=11 
				BEGIN
					set @group1='프로젝트'
					set @code1=@t1
					set @group2=''	
					set @code2=''					
					
				end 
			else if @t1='99999'
				BEGIN
					set @group1='일반'	
					set @code1=@t1
					set @group2=''	
					set @code2=''							
				end
			else if convert(int,@t1)>9999000
				BEGIN

					select @group1=C.tlabel, @code1=C.hcd2, @code2=C.hcd, @group2=C.hname  from 
					(
							select 
							'본부' as tlabel,
							hd_cd2 as hcd2, 
							hd_cd as hcd, 
							hd_name as hname 
							from dbo.TEAM_GROUP
							where hd_cd2<>''
							group by hd_cd2,hd_cd, hd_name
						union 
							select 
							A.tlabel,
							A.hd_cd2,
							A.team_cd,
							A.team_name  
							from 
							(
							select 
							'팀' as tlabel,
							(9999000+team_cd) as hd_cd2,
							team_cd,team_name 
							from dbo.TEAM_GROUP
							where team_cd>0 
							group by team_cd,team_name
							) A
							group by A.tlabel,A.hd_cd2,A.team_cd,A.team_name 
					) C
					where C.hcd2=@t1
								
				end		
			else 
				BEGIN
					set @group1=''	
					set @code1=''
					set @group2=''	
					set @code2=''							
				end
			
							
					
			
			-- #Table에 insert
				insert into dbo.sales_exp_money (tyear,tmonth,group1,group2,code1,code2,tgubn,exp_yymmdd,exp_title,account1,account2,category1,category2,category3,category4,doc_no,tgubn_code,p_child_sn,cost_money,cost_vat,cost_label,cost_text,div_use,edit_date,edit_user) 
			values (@t_year,@t_month,@group1,@group2,@code1,@code2,'A',@사용일자,@문서제목,@계정정보1,@계정정보2,'','','','멀티비용',@문서번호,@구분코드,@t1,@t2,@t3,'멀티비용',@t5,'1',GETDATE(),@t_user)


			FETCH NEXT FROM cur_step3 INTO @t1,@t2,@t3,@t4,@t5
			END
			CLOSE cur_step3
			DEALLOCATE cur_step3
			----------------------(3)------------------------------------------------
		FETCH NEXT FROM cur_step2 INTO @분리2
		END
		CLOSE cur_step2
		DEALLOCATE cur_step2
	
	
		----------------------(2)------------------------------------------------
	FETCH NEXT FROM cur_step1 INTO @문서번호, @문서제목, @사용일자, @계정정보1, @계정정보2, @구분코드, @내용
	END

	CLOSE cur_step1
	DEALLOCATE cur_step1
-------------(1)-----------------------------

----##############


------------------------------------------



END
go

