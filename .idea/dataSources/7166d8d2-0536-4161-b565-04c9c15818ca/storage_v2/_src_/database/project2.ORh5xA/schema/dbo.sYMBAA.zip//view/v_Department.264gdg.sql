CREATE View [dbo].[v_Department]
as
select a.D_Code + cast(b.T_Code as varchar) as Code, a.D_Name, a.D_Code, b.T_Name, b.T_Code, a.before_cd1, a.before_cd2, a.before_cd3, b.before_t_cd1, b.before_j_cd1, b.before_j_cd2, dz_code from N_Depart as a
left join
(
select T_Name, T_Code, D_Code, before_t_cd1, before_j_cd1, before_j_cd2, dz_code, flag from N_Depart_team
) as b on a.D_Code=b.D_Code
where a.flag='1' and b.flag='1'
go

