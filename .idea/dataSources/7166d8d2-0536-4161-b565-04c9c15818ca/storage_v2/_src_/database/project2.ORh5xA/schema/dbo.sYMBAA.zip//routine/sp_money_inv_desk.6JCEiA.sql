
CREATE PROCEDURE [dbo].[sp_money_inv_desk]
	

       @t_year       int, -- 검색년
       @p_year       int,  -- 이후1년
       @m_year       int, -- 이전1년
                     
       @t_month      varchar(2),  -- 검색월
       @t_table      varchar(50), -- table명
       @t_user      varchar(30)    -- 등록/수정 아이디   



AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here

	--  내근직/ 면접비 수당계산
	
	DECLARE @y1 nvarchar(10)	
	DECLARE @y2 nvarchar(10)
	set @y1=convert(char(4),@m_year)+'-'+@t_month+'-01' -- ~부터
	set @y2=convert(char(4),@p_year)+'-'+@t_month+'-31' -- ~까지	

	
	DECLARE @문서번호 nvarchar(20)
	DECLARE @문서제목 nvarchar(30)	
	DECLARE @발급일자 nvarchar(10)
		
	DECLARE @구분코드 char(1)
	DECLARE @지급비용정보 nvarchar(max)
	DECLARE @프로젝트정보 nvarchar(max)	
	
	DECLARE @t1 nvarchar(100),@t2  nvarchar(100)
	DECLARE @tt1 nvarchar(30),@tt2  nvarchar(30)	
	
	DECLARE @group1 nvarchar(40), @code1 nvarchar(40)	

-- 내근직/ 면접비
	DECLARE cur_step1 CURSOR FOR
	SELECT 
	문서번호, 문서제목, 
	발급일 as 발급일자,
	SUBSTRING(문서번호,10,1) as 구분코드,
	target15 as 지급비용정보, 
	target20 as 프로젝트정보
	FROM 문서내용
	 WHERE 문서제목 in ('내근직수당지출결의서', '면접원수당지출결의서') 
	and convert(nvarchar(10),발급일) between  @y1 and  @y2
--	and convert(nvarchar(10),발급일) between  '2000-01-01' and  '3000-01-01'
	and del_yes_no='no' 
	and 문서번호 like '%-t-%' 
	and target15 is not null
	order by 발급일 asc

	OPEN cur_step1
	FETCH NEXT FROM cur_step1 INTO @문서번호, @문서제목, @발급일자, @구분코드, @지급비용정보, @프로젝트정보
	WHILE @@FETCH_STATUS = 0
	BEGIN

		----------------------(2)------------------------------------------------
		DECLARE cur_step2 CURSOR FOR		
		select A.a2, B.b2 from  
		(select POS  as a1, VAL1 as a2 from  dbo.[FN_SPLIT](@지급비용정보,'^//^')) A
		left join 			
		(select POS  as b1, VAL1 as b2 from  dbo.[FN_SPLIT](@프로젝트정보,'^//^')) B
		on A.a1=B.b1
		order by A.a1 asc 
		OPEN cur_step2
		FETCH NEXT FROM cur_step2 INTO @t1,@t2 
		WHILE @@FETCH_STATUS = 0
		BEGIN

			----------------------(3)------------------------------------------------	
			DECLARE cur_step3 CURSOR FOR	
			select A.a2, B.b2 from  
			(select POS  as a1, VAL1 as a2 from  dbo.[FN_SPLIT](@t1,'^^') where POS='2') A
			left join 			
			(select POS  as b1, VAL1 as b2 from  dbo.[FN_SPLIT](@t2,'^^') where POS='2') B
			on A.a1=B.b1
			order by A.a1 asc 
			OPEN cur_step3
			FETCH NEXT FROM cur_step3 INTO @tt1,@tt2
			WHILE @@FETCH_STATUS = 0
			BEGIN 

			if len(@tt2)=11 
				BEGIN
				set @group1='프로젝트'
				set @code1=@tt2
				end 
			else
				BEGIN
				set @group1=''	
				set @code1=''
				end 


			-- #Table에 insert
			insert into dbo.sales_exp_money (tyear,tmonth,group1,group2,code1,code2,tgubn,exp_yymmdd,exp_title,account1,account2,category1,category2,category3,category4,doc_no,tgubn_code,p_child_sn,cost_money,cost_vat,cost_label,cost_text,div_use,edit_date,edit_user) 
			values  (@t_year,@t_month,@group1,'',@code1,'',@구분코드,@발급일자,@문서제목,'','','','','',left(@문서제목,3),@문서번호,@구분코드,@tt2,@tt1,0,'내근직/면접비','내근직/면접비','1',GETDATE(),@t_user)	

			FETCH NEXT FROM cur_step3 INTO @tt1,@tt2
			END
			CLOSE cur_step3
			DEALLOCATE cur_step3
			----------------------(3)------------------------------------------------

		FETCH NEXT FROM cur_step2 INTO @t1,@t2 
		END
		CLOSE cur_step2
		DEALLOCATE cur_step2
		----------------------(2)------------------------------------------------
	FETCH NEXT FROM cur_step1 INTO @문서번호, @문서제목, @발급일자, @구분코드, @지급비용정보, @프로젝트정보
	END

	CLOSE cur_step1
	DEALLOCATE cur_step1
-------------(1)-----------------------------


END
go

