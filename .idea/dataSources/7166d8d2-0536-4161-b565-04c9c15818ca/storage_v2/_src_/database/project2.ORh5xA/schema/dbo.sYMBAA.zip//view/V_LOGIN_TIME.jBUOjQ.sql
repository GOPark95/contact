CREATE VIEW V_LOGIN_TIME AS
SELECT 	p_no, CONVERT(varchar(10), con_date, 120) AS ymd, 
			substring(CONVERT(varchar(19), dateadd(HOUR, 6, CONVERT(datetime, min(con_date), 120)), 120), 12, 5) AS login_time, 
			substring(CONVERT(varchar(19), dateadd(HOUR, 6, CONVERT(datetime, max(con_date), 120)), 120), 12, 5) AS logout_time,
			FLOOR(datediff(MINUTE, CONVERT(datetime, min(con_date), 120), CONVERT(datetime, max(con_date), 120)) / 30.0)/2.0 AS gap_time
			, dbo.FN_diff_HHMI(datediff(second, CONVERT(datetime, min(con_date), 120), CONVERT(datetime, max(con_date), 120))) AS gap_time2
			,datediff(second, CONVERT(datetime, min(con_date), 120), CONVERT(datetime, max(con_date), 120)) AS gap_time3
FROM  
(  
	SELECT  p_no, dateadd(HOUR, -6, CONVERT(datetime,  
				CASE WHEN LEFT(time, 2) = '24' THEN   
					CONVERT(varchar(10), dateadd(day, 1, CONVERT(datetime, date)), 120)  + ' 00'    
				ELSE   
					date + ' ' + LEFT(time, 2)   
				END + ':' + RIGHT(time, 2) + ':00.000', 120)) AS con_date  
	FROM project2.dbo.login WITH(nolock)   
	WHERE p_no <> '0' AND p_no <> '' AND date >= '2021-01-01' AND del_yes_no='no'  
) TT 
GROUP BY p_no, CONVERT(varchar(10), con_date, 120)
go

