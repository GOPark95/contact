Create   FUNCTION dbo.LunarToSolar_F(
                @Current_day    VARCHAR(8),
                @SolarLunarFlag INT
                )

    returns varchar(10)
AS
BEGIN
    declare @ReturnDate varchar(10)
  BEGIN
    IF @SolarLunarFlag = 0
      BEGIN
	SELECT @ReturnDate = Solar_Date  FROM project2.dbo.LunarToSolar
	  WHERE Lunar_Date = @Current_day

      END 
    ELSE
      BEGIN
	SELECT @ReturnDate = Lunar_Date  FROM project2.dbo.LunarToSolar
	  WHERE Solar_Date = @Current_day
      END
  END
       Return @ReturnDate
END;

go

