CREATE FUNCTION dbo.VAC_REM (@p_no varchar(8), @s_date varchar(10))
RETURNS float
AS 
BEGIN
	DECLARE @krc_in_date AS varchar(10);
	DECLARE @gap_day AS int;
	DECLARE @tmp_plus AS int;
	DECLARE @vac_rem_cnt AS float;

	SELECT @s_date = CONVERT(varchar(10), CONVERT(date, @s_date), 120);

	SELECT @krc_in_date = krc_in_date FROM project2.dbo.person WHERE p_no = @p_no;
	SET @gap_day = DateDiff(DAY, CONVERT(date, @krc_in_date), CONVERT(date, @s_date));
	SELECT @tmp_plus = CASE WHEN RIGHT(@krc_in_date, 5) < (CASE WHEN @s_date < '2020-03-01' THEN '03-01' ELSE '04-01' END) THEN 2 ELSE 3 END;
	
	SELECT @vac_rem_cnt = 
		CASE
		--0년차
		WHEN @gap_day <= 365 THEN 
			CASE WHEN DATEADD(MONTH, 1, CONVERT(date, @krc_in_date)) <= CONVERT(date, @s_date) THEN 1 ELSE 0 END +
			CASE WHEN DATEADD(MONTH, 2, CONVERT(date, @krc_in_date)) <= CONVERT(date, @s_date) THEN 1 ELSE 0 END +
			CASE WHEN DATEADD(MONTH, 3, CONVERT(date, @krc_in_date)) <= CONVERT(date, @s_date) THEN 1 ELSE 0 END +
			CASE WHEN DATEADD(MONTH, 4, CONVERT(date, @krc_in_date)) <= CONVERT(date, @s_date) THEN 1 ELSE 0 END +
			CASE WHEN DATEADD(MONTH, 5, CONVERT(date, @krc_in_date)) <= CONVERT(date, @s_date) THEN 1 ELSE 0 END +
			CASE WHEN DATEADD(MONTH, 6, CONVERT(date, @krc_in_date)) <= CONVERT(date, @s_date) THEN 1 ELSE 0 END +
			CASE WHEN DATEADD(MONTH, 7, CONVERT(date, @krc_in_date)) <= CONVERT(date, @s_date) THEN 1 ELSE 0 END +
			CASE WHEN DATEADD(MONTH, 8, CONVERT(date, @krc_in_date)) <= CONVERT(date, @s_date) THEN 1 ELSE 0 END +
			CASE WHEN DATEADD(MONTH, 9, CONVERT(date, @krc_in_date)) <= CONVERT(date, @s_date) THEN 1 ELSE 0 END +
			CASE WHEN DATEADD(MONTH, 10, CONVERT(date, @krc_in_date)) <= CONVERT(date, @s_date) THEN 1 ELSE 0 END +
			CASE WHEN DATEADD(MONTH, 11, CONVERT(date, @krc_in_date)) <= CONVERT(date, @s_date) THEN 1 ELSE 0 END
		--1년차
		WHEN @gap_day BETWEEN 366 AND 730 THEN 
			15
		--2년차
		WHEN @gap_day > 730 AND @s_date < CONVERT(varchar(4), CONVERT(int, LEFT(@krc_in_date, 4)) + @tmp_plus) + (CASE WHEN @s_date < '2020-03-01' THEN '-03-01' ELSE '-04-01' END) THEN 
			CASE WHEN RIGHT(@krc_in_date, 5) >= (CASE WHEN @s_date < '2020-03-01' THEN '03-01' ELSE '04-01' END) THEN
				CEILING((DateDiff(DAY, CONVERT(date, @krc_in_date), CONVERT(date, CONVERT(varchar(4), (CONVERT(int, LEFT(@krc_in_date, 4)) + 1)) + (CASE WHEN @s_date < '2020-03-01' THEN '-03-01' ELSE '-04-01' END))) - 1) * 15 / 365.0 * 2) / 2
			ELSE
				CEILING((DateDiff(DAY, CONVERT(date, @krc_in_date), CONVERT(date, LEFT(@krc_in_date, 4) + (CASE WHEN @s_date < '2020-03-01' THEN '-03-01' ELSE '-04-01' END))) - 1) * 15 / 365.0 * 2) / 2
			END 
		ELSE 
			FLOOR((DateDiff(YEAR, 	CONVERT(date, LEFT(@krc_in_date, 4) + (CASE WHEN @krc_in_date < '2018-04-01' THEN '-03-01' ELSE '-04-01' END)), 
									CONVERT(date, @s_date)) +
			CASE WHEN RIGHT(@krc_in_date, 5) < (CASE WHEN @krc_in_date < '2018-04-01' THEN '03-01' ELSE '04-01' END) THEN 0 ELSE -1 END + 
			CASE WHEN RIGHT(@s_date, 5) < '04-01' THEN -1 ELSE 0 END) / 2.0) + 15
		END;
	
	IF (@vac_rem_cnt > 25) 
		SET @vac_rem_cnt = 25;
	
	SELECT @vac_rem_cnt = @vac_rem_cnt + CASE WHEN dbo.VAC_YEAR(@p_no, @s_date) = '2020-21' THEN 1.5 ELSE 0 END;
	
	RETURN @vac_rem_cnt;
END;

go

