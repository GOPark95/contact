CREATE VIEW dbo.V_EXPRES AS
SELECT 	문서번호, project2.dbo.SPLIT(rawdata, '^//^', 1) AS p_child_sn, project2.dbo.SPLIT(rawdata, '^//^', 5) AS contents, 
			pay_date, kind_price, 
			ltrim(replace(project2.dbo.SPLIT(rawdata, '^//^', 2), ',', '')) AS unit_price, ltrim(replace(project2.dbo.SPLIT(rawdata, '^//^', 3), ',', '')) AS vat_price,
			ltrim(replace(project2.dbo.SPLIT(rawdata, '^//^', 4), ',', '')) AS total_price, client,
			hangmok, sebu, cost_category, 발급일, login_p_no, login_이름, login_ip, gubun AS target
FROM 
( 
SELECT 문서번호, CONVERT(varchar(20), target3) AS pay_date, 
			CONVERT(varchar(100), target4) AS kind_price, CONVERT(varchar(500), target8) AS client, 
			CONVERT(varchar(5), target11) AS hangmok, CONVERT(varchar(5), target12) AS sebu, 
			CONVERT(varchar(50), target16) AS cost_category, 발급일, login_p_no, login_이름, login_ip,
			SUBSTRING(CONVERT(varchar(1000), target21), CHARINDEX('^^', CONVERT(varchar(1000), target21))+2, 2000) as target21, 
			SUBSTRING(CONVERT(varchar(1000), target22), CHARINDEX('^^', CONVERT(varchar(1000), target22))+2, 2000) as target22, 
			SUBSTRING(CONVERT(varchar(1000), target23), CHARINDEX('^^', CONVERT(varchar(1000), target23))+2, 2000) as target23,	
			SUBSTRING(CONVERT(varchar(1000), target24), CHARINDEX('^^', CONVERT(varchar(1000), target24))+2, 2000) as target24, 
			SUBSTRING(CONVERT(varchar(1000), target25), CHARINDEX('^^', CONVERT(varchar(1000), target25))+2, 2000) as target25, 
			SUBSTRING(CONVERT(varchar(1000), target26), CHARINDEX('^^', CONVERT(varchar(1000), target26))+2, 2000) as target26,	
			SUBSTRING(CONVERT(varchar(1000), target27), CHARINDEX('^^', CONVERT(varchar(1000), target27))+2, 2000) as target27, 
			SUBSTRING(CONVERT(varchar(1000), target28), CHARINDEX('^^', CONVERT(varchar(1000), target28))+2, 2000) as target28, 
			SUBSTRING(CONVERT(varchar(1000), target29), CHARINDEX('^^', CONVERT(varchar(1000), target29))+2, 2000) as target29,	
			SUBSTRING(CONVERT(varchar(1000), target30), CHARINDEX('^^', CONVERT(varchar(1000), target30))+2, 2000) as target30, 
			SUBSTRING(CONVERT(varchar(1000), target31), CHARINDEX('^^', CONVERT(varchar(1000), target31))+2, 2000) as target31, 
			SUBSTRING(CONVERT(varchar(1000), target32), CHARINDEX('^^', CONVERT(varchar(1000), target32))+2, 2000) as target32,	
			SUBSTRING(CONVERT(varchar(1000), target33), CHARINDEX('^^', CONVERT(varchar(1000), target33))+2, 2000) as target33, 
			SUBSTRING(CONVERT(varchar(1000), target34), CHARINDEX('^^', CONVERT(varchar(1000), target34))+2, 2000) as target34, 
			SUBSTRING(CONVERT(varchar(1000), target35), CHARINDEX('^^', CONVERT(varchar(1000), target35))+2, 2000) as target35,	
			SUBSTRING(CONVERT(varchar(1000), target36), CHARINDEX('^^', CONVERT(varchar(1000), target36))+2, 2000) as target36, 
			SUBSTRING(CONVERT(varchar(1000), target37), CHARINDEX('^^', CONVERT(varchar(1000), target37))+2, 2000) as target37, 
			SUBSTRING(CONVERT(varchar(1000), target38), CHARINDEX('^^', CONVERT(varchar(1000), target38))+2, 2000) as target38,	
			SUBSTRING(CONVERT(varchar(1000), target39), CHARINDEX('^^', CONVERT(varchar(1000), target39))+2, 2000) as target39, 
			SUBSTRING(CONVERT(varchar(1000), target40), CHARINDEX('^^', CONVERT(varchar(1000), target40))+2, 2000) as target40, 
			SUBSTRING(CONVERT(varchar(1000), target41), CHARINDEX('^^', CONVERT(varchar(1000), target41))+2, 2000) as target41,	
			SUBSTRING(CONVERT(varchar(1000), target42), CHARINDEX('^^', CONVERT(varchar(1000), target42))+2, 2000) as target42, 
			SUBSTRING(CONVERT(varchar(1000), target43), CHARINDEX('^^', CONVERT(varchar(1000), target43))+2, 2000) as target43, 
			SUBSTRING(CONVERT(varchar(1000), target44), CHARINDEX('^^', CONVERT(varchar(1000), target44))+2, 2000) as target44,	
			SUBSTRING(CONVERT(varchar(1000), target45), CHARINDEX('^^', CONVERT(varchar(1000), target45))+2, 2000) as target45, 
			SUBSTRING(CONVERT(varchar(1000), target46), CHARINDEX('^^', CONVERT(varchar(1000), target46))+2, 2000) as target46, 
			SUBSTRING(CONVERT(varchar(1000), target47), CHARINDEX('^^', CONVERT(varchar(1000), target47))+2, 2000) as target47,	
			SUBSTRING(CONVERT(varchar(1000), target48), CHARINDEX('^^', CONVERT(varchar(1000), target48))+2, 2000) as target48, 
			SUBSTRING(CONVERT(varchar(1000), target49), CHARINDEX('^^', CONVERT(varchar(1000), target49))+2, 2000) as target49, 
			SUBSTRING(CONVERT(varchar(1000), target50), CHARINDEX('^^', CONVERT(varchar(1000), target50))+2, 2000) as target50 
FROM project2.dbo.문서내용 M LEFT JOIN
project2.dbo.Document D ON M.문서번호 = D.d_no
WHERE 문서제목 = '지출결의서'	
AND CONVERT(varchar(10),target3) > '2016-01-00'	
AND del_yes_no = 'no'	
AND D.d_delok = 'N'
AND substring(문서번호, 10, 1) = 'A'	
) AS columnTable 
UNPIVOT 
(	
	rawdata FOR gubun IN (	
		target21, target22, target23, target24, target25, target26, target27, target28, target29, target30 ,	
		target31, target32, target33, target34, target35, target36, target37, target38, target39, target40 ,	
		target41, target42, target43, target44, target45, target46, target47, target48, target49, target50	
	)	
) AS rowTable 
WHERE rawdata <> ''
UNION ALL
SELECT 	문서번호, 
			CONVERT(varchar(500), target10) AS p_child_sn, CONVERT(varchar(2000), target2) AS contents, 
			CONVERT(varchar(20), target3) AS pay_date, CONVERT(varchar(100), target4) AS kind_price, 
			CONVERT(varchar(100), target5) AS unit_price, CONVERT(varchar(100), target6) AS vat_price, 
			CONVERT(varchar(100), target7) AS total_price, CONVERT(varchar(500), target8) AS client, 
			CONVERT(varchar(5), target11) AS hangmok, CONVERT(varchar(5), target12) AS sebu, 
			CONVERT(varchar(50), target16) AS cost_category, 발급일, login_p_no, login_이름, login_ip, 'target1' AS target
FROM project2.dbo.문서내용 M LEFT JOIN
project2.dbo.Document D ON M.문서번호 = D.d_no
WHERE 문서제목 = '지출결의서'  
AND CONVERT(varchar(10),target3) > '2016-01-00'	
AND del_yes_no = 'no'	
AND D.d_delok = 'N'
AND substring(문서번호, 10, 1) = 'i'
go

