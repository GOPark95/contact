CREATE VIEW V_BUSI_COST AS
SELECT * FROM
(
	SELECT 	CA.id, CA.job_date, CA.p_sn, CA.job_code, CA.cost_code, CA.cost_money, CA.cost_member, CA.cost_member_code, 
				CA.user_code AS p_no, CA.cost_remark, ISNULL(D.d_order_cnt, 0) AS d_order_cnt,
				ISNULL(d_order7, '') AS d_order7, ISNULL(d_order8, '') AS d_order8, ISNULL(d_order9, '') AS d_order9, ISNULL(d_order10, '') AS d_order10
	FROM cost_account CA LEFT JOIN V_Job_List JL ON CA.job_date = JL.j_date AND CA.user_code = JL.p_no
	AND CA.p_sn = JL.j_p_sn AND CA.job_code = JL.j_contents 
	LEFT JOIN Document D ON JL.j_approval = D.d_no
	WHERE CA.flag = '1' AND JL.p_no IS NOT NULL 
	UNION ALL
	SELECT 	CA.id, CA.job_date, CA.p_sn, CA.job_code, CA.cost_code, CA.cost_money, CA.cost_member, CA.cost_member_code, 
				CA.user_code AS p_no, CA.cost_remark, ISNULL(D.d_order_cnt, 0) AS d_order_cnt, 
				ISNULL(d_order7, '') AS d_order7, ISNULL(d_order8, '') AS d_order8, ISNULL(d_order9, '') AS d_order9, ISNULL(d_order10, '') AS d_order10
	FROM cost_account CA LEFT JOIN Document D ON CA.d_no = D.d_no
	WHERE cost_money > 0 AND job_code = '5' AND CA.job_date > '2018-01-01'
) T
go

