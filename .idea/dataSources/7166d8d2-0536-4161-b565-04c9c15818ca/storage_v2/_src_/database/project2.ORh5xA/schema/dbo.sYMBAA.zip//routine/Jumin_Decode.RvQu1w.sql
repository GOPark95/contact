
CREATE FUNCTION [dbo].[Jumin_Decode]
(
	@jumin VARCHAR(100)
)
RETURNS VARCHAR(100)
AS
BEGIN
	Declare @Ref VARCHAR(100)
	SET @Ref = 'D7EFGBCHL640MN598OIJKPQRSATWXVYZ123U'
	RETURN
	CONVERT(VARCHAR(MAX), CONVERT(VARBINARY(MAX), '0x'+
	SUBSTRING(@Ref, ((CHARINDEX(SUBSTRING(@jumin, 1, 1), @Ref) - 1) ^ 3) + 1, 1) + 
	SUBSTRING(@Ref, ((CHARINDEX(SUBSTRING(@jumin, 2, 1), @Ref) - 1) ^ 3) + 1, 1) + 
	SUBSTRING(@Ref, ((CHARINDEX(SUBSTRING(@jumin, 3, 1), @Ref) - 1) ^ 3) + 1, 1) + 
	SUBSTRING(@Ref, ((CHARINDEX(SUBSTRING(@jumin, 4, 1), @Ref) - 1) ^ 3) + 1, 1) + 
	SUBSTRING(@Ref, ((CHARINDEX(SUBSTRING(@jumin, 5, 1), @Ref) - 1) ^ 3) + 1, 1) + 
	SUBSTRING(@Ref, ((CHARINDEX(SUBSTRING(@jumin, 6, 1), @Ref) - 1) ^ 3) + 1, 1) + 
	SUBSTRING(@Ref, ((CHARINDEX(SUBSTRING(@jumin, 7, 1), @Ref) - 1) ^ 3) + 1, 1) + 
	SUBSTRING(@Ref, ((CHARINDEX(SUBSTRING(@jumin, 8, 1), @Ref) - 1) ^ 3) + 1, 1) + 
	SUBSTRING(@Ref, ((CHARINDEX(SUBSTRING(@jumin, 9, 1), @Ref) - 1) ^ 3) + 1, 1) + 
	SUBSTRING(@Ref, ((CHARINDEX(SUBSTRING(@jumin, 10, 1), @Ref) - 1) ^ 3) + 1, 1) + 
	SUBSTRING(@Ref, ((CHARINDEX(SUBSTRING(@jumin, 11, 1), @Ref) - 1) ^ 3) + 1, 1) + 
	SUBSTRING(@Ref, ((CHARINDEX(SUBSTRING(@jumin, 12, 1), @Ref) - 1) ^ 3) + 1, 1) + 
	SUBSTRING(@Ref, ((CHARINDEX(SUBSTRING(@jumin, 13, 1), @Ref) - 1) ^ 3) + 1, 1) + 
	SUBSTRING(@Ref, ((CHARINDEX(SUBSTRING(@jumin, 14, 1), @Ref) - 1) ^ 3) + 1, 1) + 
	SUBSTRING(@Ref, ((CHARINDEX(SUBSTRING(@jumin, 15, 1), @Ref) - 1) ^ 3) + 1, 1) + 
	SUBSTRING(@Ref, ((CHARINDEX(SUBSTRING(@jumin, 16, 1), @Ref) - 1) ^ 3) + 1, 1) + 
	SUBSTRING(@Ref, ((CHARINDEX(SUBSTRING(@jumin, 17, 1), @Ref) - 1) ^ 3) + 1, 1) + 
	SUBSTRING(@Ref, ((CHARINDEX(SUBSTRING(@jumin, 18, 1), @Ref) - 1) ^ 3) + 1, 1) + 
	SUBSTRING(@Ref, ((CHARINDEX(SUBSTRING(@jumin, 19, 1), @Ref) - 1) ^ 3) + 1, 1) + 
	SUBSTRING(@Ref, ((CHARINDEX(SUBSTRING(@jumin, 20, 1), @Ref) - 1) ^ 3) + 1, 1) + 
	SUBSTRING(@Ref, ((CHARINDEX(SUBSTRING(@jumin, 21, 1), @Ref) - 1) ^ 3) + 1, 1) + 
	SUBSTRING(@Ref, ((CHARINDEX(SUBSTRING(@jumin, 22, 1), @Ref) - 1) ^ 3) + 1, 1) + 
	SUBSTRING(@Ref, ((CHARINDEX(SUBSTRING(@jumin, 23, 1), @Ref) - 1) ^ 3) + 1, 1) + 
	SUBSTRING(@Ref, ((CHARINDEX(SUBSTRING(@jumin, 24, 1), @Ref) - 1) ^ 3) + 1, 1) + 
	SUBSTRING(@Ref, ((CHARINDEX(SUBSTRING(@jumin, 25, 1), @Ref) - 1) ^ 3) + 1, 1) + 
	SUBSTRING(@Ref, ((CHARINDEX(SUBSTRING(@jumin, 26, 1), @Ref) - 1) ^ 3) + 1, 1) + 
	SUBSTRING(@Ref, ((CHARINDEX(SUBSTRING(@jumin, 27, 1), @Ref) - 1) ^ 3) + 1, 1) + 
	SUBSTRING(@Ref, ((CHARINDEX(SUBSTRING(@jumin, 28, 1), @Ref) - 1) ^ 3) + 1, 1) + 
	SUBSTRING(@Ref, ((CHARINDEX(SUBSTRING(@jumin, 29, 1), @Ref) - 1) ^ 3) + 1, 1) + 
	SUBSTRING(@Ref, ((CHARINDEX(SUBSTRING(@jumin, 30, 1), @Ref) - 1) ^ 3) + 1, 1) , 1))
END

go

