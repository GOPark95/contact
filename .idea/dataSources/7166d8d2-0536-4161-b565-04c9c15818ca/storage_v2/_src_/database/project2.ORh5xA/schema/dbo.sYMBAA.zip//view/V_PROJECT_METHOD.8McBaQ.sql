CREATE VIEW [dbo].[V_PROJECT_METHOD]
AS
SELECT     TPM.p_method_cd, p_sn, p_cli_company_cd, p_client_type_cd, p_index, p_sub_type, p_child_sn, p_subject, p_con_date_st, p_con_date_end, p_decide_date, 
                      p_cont_cost, p_export_range, p_category, p_sur_area, p_sur_target, p_sample, p_research_date_st, p_research_date_end, p_sur_part, p_field_process, p_rsch_dept, 
                      p_field_dept, p_is_dept, p_supp_dept, p_rsch_1_a, p_rsch_2_a, p_rsch_3_a, p_rsch_4_a, p_rsch_1_b, p_rsch_2_b, p_rsch_3_b, p_rsch_4_b, p_rsch_1_c, 
                      p_rsch_2_c, p_rsch_3_c, p_rsch_4_c, p_sv_1, p_sv_2, p_sv_3, p_sv_4, p_code_1, p_code_2, p_code_3, p_code_4, p_verify_1, p_verify_2, p_verify_3, p_verify_4,
					  p_punch_1, p_punch_2, p_punch_3, p_punch_4, 
                      p_dp_1, p_dp_2, p_dp_3, p_dp_4, p_it_1, p_it_2, p_it_3, p_it_4, p_supp_1, p_supp_2, p_supp_3, p_supp_4, p_rsch_date_st, p_rsch_date_end, p_field_date_st, 
                      p_field_date_end, p_code_date_st, p_code_date_end, p_verify_date_st, p_verify_date_end, p_punch_date_st, p_punch_date_end, p_dp_date_st, p_dp_date_end, p_it_date_st, p_it_date_end, 
                      p_premeet_date, p_premeet_time, p_premeet_place, p_ot_date, p_ot_time, p_ot_place, p_sur_memo, p_memo, p_progress_status, TPM.p_input_dt, 
                      p_input_complete, TPMC.p_method_nm, TPM.p_intention, p_research_complete, p_field_complete, p_dp_complete, p_support_complete, tpm.p_statistics, '' AS p_content
FROM         T_PROJECT_METHOD TPM LEFT OUTER JOIN
                      T_PROJECT_METHOD_CD TPMC ON TPM.p_method_cd = TPMC.p_method_cd
WHERE     p_sub_type = 'C'
UNION ALL
SELECT     TPM.p_method_cd, TPM.p_sn, TPM.p_cli_company_cd, TPM.p_client_type_cd, p_index, p_sub_type, p_child_sn, TPB.p_subject, TPM.p_con_date_st, 
                      TPM.p_con_date_end, TPM.p_decide_date, TPM.p_cont_cost, TPM.p_export_range, TPM.p_category, p_sur_area, p_sur_target, TPM.p_sample, p_research_date_st, 
                      p_research_date_end, p_sur_part, TPM.p_field_process, p_rsch_dept, p_field_dept, p_is_dept, p_supp_dept, p_rsch_1_a, p_rsch_2_a, p_rsch_3_a, p_rsch_4_a, 
                      p_rsch_1_b, p_rsch_2_b, p_rsch_3_b, p_rsch_4_b, p_rsch_1_c, p_rsch_2_c, p_rsch_3_c, p_rsch_4_c, p_sv_1, p_sv_2, p_sv_3, p_sv_4, p_code_1, p_code_2, 
                      p_code_3, p_code_4, p_verify_1, p_verify_2, p_verify_3, p_verify_4, p_punch_1, p_punch_2, p_punch_3, p_punch_4,
					  p_dp_1, p_dp_2, p_dp_3, p_dp_4, p_it_1, p_it_2, p_it_3, p_it_4, p_supp_1, p_supp_2, p_supp_3, 
                      p_supp_4, p_rsch_date_st, p_rsch_date_end, p_field_date_st, p_field_date_end, p_code_date_st, p_code_date_end, p_verify_date_st, p_verify_date_end,
					  p_punch_date_st, p_punch_date_end, 
                      p_dp_date_st, p_dp_date_end, p_it_date_st, p_it_date_end, TPM.p_premeet_date, p_premeet_time, p_premeet_place, TPM.p_ot_date, p_ot_time, p_ot_place, 
                      p_sur_memo, TPM.p_memo, p_progress_status, TPM.p_input_dt, p_input_complete, TPMC.p_method_nm, TPM.p_intention, p_research_complete, p_field_complete, 
                      p_dp_complete, p_support_complete, tpb.p_statistics, '' AS p_content
FROM         T_PROJECT_METHOD TPM LEFT OUTER JOIN
                      T_PROJECT_METHOD_CD TPMC ON TPM.p_method_cd = TPMC.p_method_cd LEFT OUTER JOIN
                      T_PROJECT_BASE TPB ON TPM.p_sn = TPB.p_sn
WHERE     p_sub_type != 'C' OR
                      p_sub_type IS NULL
UNION ALL
SELECT     p_method AS p_method_cd, p_sn AS p_sn, p_cli_company AS p_cli_company_cd, p_cli_type AS p_client_type_cd, sn AS p_index, 'C' AS p_sub_type, '' AS p_child_sn, 
                      p_subject AS p_subject, p_convdate_st AS p_con_date_st, p_convdate_end AS p_con_date_end, p_conv_date AS p_decide_date, p_budget AS p_cont_cost, 
                      '' AS p_export_range, CONVERT(VARCHAR(50), p_category) AS p_category, p_area AS p_sur_area, p_target_part AS p_sur_target, p_sample AS p_sample, 
                      p_field_st AS p_research_date_st, p_field_end AS p_research_date_end, p_survey_part AS p_sur_part, p_field_process AS p_field_process, 
                      p_depart_dep AS p_rsch_dept, '' AS p_field_dept, '' AS p_is_dept, '' AS p_supp_dept, p_rsch_1 AS p_rsch_1_a, p_rsch_2 AS p_rsch_2_a, p_rsch_3 AS p_rsch_3_a, 
                      p_rsch_4 AS p_rsch_4_a, '' AS p_rsch_1_b, '' AS p_rsch_2_b, '' AS p_rsch_3_b, '' AS p_rsch_4_b, '' AS p_rsch_1_c, '' AS p_rsch_2_c, '' AS p_rsch_3_c, 
                      '' AS p_rsch_4_c, p_sv AS p_sv_1, p_sv2 AS p_sv_2, '' AS p_sv_3, '' AS p_sv_4, p_coder AS p_code_1, '' AS p_code_2, '' AS p_code_3, '' AS p_code_4, 
                      p_verify AS p_verify_1, '' AS p_verify_2, '' AS p_verify_3, '' AS p_verify_4, p_puncher AS p_punch_1, '' AS p_punch_2, '' AS p_punch_3, '' AS p_punch_4,
					   p_dper AS p_dp_1, '' AS p_dp_2, '' AS p_dp_3, '' AS p_dp_4, p_it AS p_it_1, '' AS p_it_2, 
                      '' AS p_it_3, '' AS p_it_4, '' AS p_supp_1, '' AS p_supp_2, '' AS p_supp_3, '' AS p_supp_4, p_report_st AS p_rsch_date_st, p_report_end AS p_rsch_date_end, 
                      p_field_st2 AS p_field_date_st, p_field_end2 AS p_field_date_end, p_code_st as p_code_date_st, p_code_end as p_code_date_end,
                      p_survey_date AS p_verify_date_st, '' AS p_verify_date_end, p_punch_st AS p_punch_date_st, p_punch_end AS p_punch_date_end, 
					  p_dp_st AS p_dp_date_st, p_dp_end AS p_dp_date_end, '' AS p_it_date_st, '' AS p_it_date_end, 
                      p_premeet_date AS p_premeet_date, '' AS p_premeet_time, '' AS p_premeet_place, p_ot_date AS p_ot_date, '' AS p_ot_time, '' AS p_ot_place, '' AS p_sur_memo, 
                      p_memo AS p_memo, '999' AS p_progress_status, p_reg_date AS p_input_dt, '' AS p_input_complete, PM.name1 AS p_method_nm, p_intention, p_research_complete, 
                      p_field_complete, p_dp_complete, p_support_complete, '' AS p_statistics, p_content
FROM         project P LEFT OUTER JOIN
                      p_method PM ON P.p_method = PM.code1
go

