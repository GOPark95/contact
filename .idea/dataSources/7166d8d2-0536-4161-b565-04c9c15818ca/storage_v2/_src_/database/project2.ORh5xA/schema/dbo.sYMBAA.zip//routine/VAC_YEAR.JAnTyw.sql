
CREATE FUNCTION dbo.VAC_YEAR (@p_no varchar(8), @s_date varchar(10))
RETURNS varchar(10)
AS 
BEGIN
	DECLARE @krc_in_date AS varchar(10);
	DECLARE @s_year AS int;
	DECLARE @gap_day AS int;
	DECLARE @tmp_plus AS int;
	DECLARE @season AS varchar(10);
		
	SELECT @s_date = CONVERT(varchar(10), CONVERT(date, @s_date), 120);	

	SELECT @krc_in_date = krc_in_date FROM project2.dbo.person WHERE p_no = @p_no;
	SET @s_year = CONVERT(int, LEFT(@s_date, 4));
	SELECT @s_year = CASE WHEN CONVERT(varchar(4), @s_year) + '-04-01' <= @s_date THEN @s_year + 1 ELSE @s_year END;
	SET @gap_day = DateDiff(DAY, CONVERT(date, @krc_in_date), CONVERT(date, @s_date));
	SELECT @tmp_plus = CASE WHEN RIGHT(@krc_in_date, 5) < (CASE WHEN LEFT(@s_date, 4) <= '2020' THEN '03-01' ELSE '04-01' END) THEN 2 ELSE 3 END  	

	SELECT 	@season =
		CASE
		--입사전
		WHEN @gap_day < 0 THEN 'X'
		--0년차
		WHEN @gap_day <= 365 THEN '0'
		--1년차
		WHEN @gap_day BETWEEN 366 AND 730 THEN '1'
		--2년차
		WHEN @gap_day > 730 AND @s_date < CONVERT(varchar(4), CONVERT(int, LEFT(@krc_in_date, 4)) + @tmp_plus) + '-04-01' THEN '2'
		ELSE 
			CONVERT(varchar(4), @s_year-1) + '-' + RIGHT(CONVERT(varchar(4), @s_year), 2)
		END
	RETURN @season;
END;
go

