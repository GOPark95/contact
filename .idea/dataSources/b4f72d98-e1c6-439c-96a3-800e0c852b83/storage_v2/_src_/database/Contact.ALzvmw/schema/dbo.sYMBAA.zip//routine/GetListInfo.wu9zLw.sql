CREATE PROCEDURE GetListInfo (
	@PKEY NVARCHAR(MAX)
)
AS
BEGIN
DECLARE @COLUMNS NVARCHAR(MAX)
DECLARE @SQL     NVARCHAR(MAX)

SET @COLUMNS = ''
SET @PKEY='38'
 
SELECT @COLUMNS = @COLUMNS+', STRING_AGG(case when list_type = '''+name+''' then list_data else '''' end,'''') as ['+name+']'
FROM LIST_TYPE_IX
WHERE project_code = @PKEY
ORDER BY list_order

--SELECT @COLUMNS

SET @SQL = ' 
	SELECT list_id'+@COLUMNS+'
	FROM LIST
	WHERE project_code = '''+@PKEY+'''
	group by list_id
	ORDER BY list_id
	FOR JSON PATH
'
--SELECT @SQL
EXEC(@SQL)
END
go

